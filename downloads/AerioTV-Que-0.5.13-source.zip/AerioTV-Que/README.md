# AerioTV Que edition

AerioTV Android **0.5.13** with the screenshot-inspired Que Blue TV interface
and contrast fixes. The Android TV screens use a cobalt sidebar, separate Live
TV and Guide entries, blue programme cards, media grids and theme previews.

Version: `0.5.13-que.1` (`6901`); package: `com.aeriotv.blue`.
Android 8.0+; ARM64, ARMv7 and x86_64.

The signed APK can update the earlier personal AerioTV Blue build and installs
alongside the original AerioTV. The original app's data is separate. The upstream
self-updater is omitted; Google Drive/Cast require personal registrations.

Source base: [AerioTV v0.5.13](https://github.com/jonzey231/AerioTV-Android/tree/v0.5.13),
commit `8b2d935a307d99203a0fd91e44a83c9f2ae430fd`.

See [build notes](BLUE_EDITION.md) and [validation](VALIDATION.md).
The original [GPL licence](LICENSE), [exceptions](LICENSE-EXCEPTIONS.md),
[third-party notices](THIRD_PARTY_LICENSES.md), and [upstream README](UPSTREAM_README.md)
are retained. Private signing material, credentials and playlists are excluded.
