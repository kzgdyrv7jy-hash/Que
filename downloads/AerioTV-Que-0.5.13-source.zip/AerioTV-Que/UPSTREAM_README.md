# AerioTV for Android

AerioTV for Android is a native IPTV streaming app for Android phones, tablets, and Google TV / Android TV, built from a single Jetpack Compose codebase. It connects to Dispatcharr (admin login or API key), Xtream Codes, and M3U playlist servers to deliver live TV, movies, and series with a full electronic program guide (EPG) when supplied by the user.

**Google Play**
- AerioTV is in closed testing on Google Play (invite only).

**Sideload**
- Download the latest `.apk` from [Releases](https://github.com/jonzey231/AerioTV-Android/releases) and install it (enable install from unknown sources for your browser or file manager, or run `adb install`). The sideload build is occasionally ahead of the Play track.

## The AerioTV Family

| App | Devices | Repository |
| --- | --- | --- |
| **AerioTV for Android** (this repo) | Phones, tablets, Google TV, and Android TV | [jonzey231/AerioTV-Android](https://github.com/jonzey231/AerioTV-Android) |
| **AerioTV for Apple** | iPhone, iPad, Apple TV, and Mac (iPad app) | [jonzey231/AerioTV](https://github.com/jonzey231/AerioTV) |
| **AerioTV for Roku** | Roku players and Roku TVs (community port) | [EndofLineTech/AerioTV-Roku](https://github.com/EndofLineTech/AerioTV-Roku) |

The Apple and Android apps share one design and feature set. They also work together: cast from an iPhone to AerioTV on Android TV, or AirPlay to an Apple TV.

## Screenshots

Screenshots are coming soon.

<details>
<summary><strong>Phone</strong></summary>
<br>
<em>Coming soon.</em>
<!-- <img src="docs/screenshots/phone/01.png" width="200" /> -->
</details>

<details>
<summary><strong>Tablet</strong></summary>
<br>
<em>Coming soon.</em>
<!-- <img src="docs/screenshots/tablet/01.png" width="320" /> -->
</details>

<details>
<summary><strong>Android TV</strong></summary>
<br>
<em>Coming soon.</em>
<!-- <img src="docs/screenshots/androidtv/01.png" width="420" /> -->
</details>

## Features

A native Android IPTV client. Stream live TV with a full EPG, browse on-demand movies and series, schedule recordings to a Dispatcharr server or to your device, and watch up to 9 channels at once with Multiview, across phone, tablet, and Google TV / Android TV, with optional Google Drive sync stitching it together.

Click each section for the full list:

<details>
<summary><strong>Live TV & Guide</strong> (Media3 / ExoPlayer playback, list + grid views, EPG, reminders)</summary>

- Hardware-accelerated playback on Media3 / ExoPlayer (HLS, DASH, and progressive streams; hardware decode including HEVC HDR)
- List view plus a full EPG guide (grid on TV and tablet, a List / Guide toggle on phone)
- Program titles, descriptions, and time slots
- Channel info card identifies the channel and program when a stream starts
- Sort channels by number, name, or favorites; reorder favorites by drag
- Tap to play; manage favorites and per-group visibility from the channel menu
- Long-press an upcoming program to set a reminder or schedule a recording
- EPG reminders fire before the program starts, as an in-app banner and a notification
- EPG window configurable from 6 hours up to the full available window (Settings, Network)
- Guide zoom (pinch or a discrete scale selector) and a jump-to-now control
- Channels without guide data are still selectable from the grid
- Pull to refresh the channel list; per-playlist Refresh EPG

</details>

<details>
<summary><strong>Multiview</strong> up to 9 streams at once.</summary>

- Watch up to 9 live channels at once in a dynamically sized grid
- Enter from any playing channel, or stage channels from the guide and launch into Multiview
- Layouts adapt to tile count, from 1 up to a full 3x3
- Only the most recently added stream plays audio; tap a tile (or press Select on the remote) to move audio focus
- Per-tile menu: Make Audio, Full-Screen tile, Audio Track, Subtitle Track, Remove
- Drag to reorder tiles; double-tap a tile for fullscreen
- Resource guards: a thermal watchdog, a soft tile limit, and low-memory handling stop new tiles before the device is overwhelmed

</details>

<details>
<summary><strong>DVR Recording</strong> server-side on Dispatcharr, local on every server type.</summary>

- Schedule live or upcoming programs from the Live TV guide
- **Dispatcharr server-side recording** continues even when AerioTV is closed (the server runs the recording), ideal for unattended recordings
- **Local recording on this device**, available for Dispatcharr, Xtream Codes, and M3U
- Per-recording pre-roll (start early) and post-roll (end late) buffers: None / 5 / 10 / 15 / 30 / 60 min or custom
- **Remove Commercials (Comskip)** runs server-side on Dispatcharr; toggle it at schedule time or run it after recording
- DVR tab appears automatically when there is at least one recording, split into Scheduled / Recording / Completed
- Auto-discovery of recordings scheduled outside the app (Dispatcharr web UI)
- Play completed recordings in the app, and save server-side recordings to the device
- A Clear All action for completed recordings
- Keep-device-awake toggle so a local recording is not interrupted by display sleep

</details>

<details>
<summary><strong>Movies & TV Shows</strong> (Dispatcharr & Xtream Codes) VOD library, Continue Watching, TMDB-rich metadata.</summary>

- Browse and filter on-demand content by category
- TMDB-rich metadata on Dispatcharr (backdrop, plot, cast, director, year, rating, runtime; per-episode air dates, ratings, IMDB IDs, and per-episode artwork)
- Provider-supplied metadata on Xtream Codes (poster, title, one-line plot)
- Continue Watching resumes movies and episodes, and advances automatically to the next episode in a series
- Watch progress syncs across devices when Google Drive sync is on
- Per-playlist VOD toggle in Settings, Edit Playlist
- Full-library pagination walks past the first page on large libraries
- Movie and series detail caches make second-opens instant

</details>

<details>
<summary><strong>Player</strong> chrome, Stream Info, Sleep Timer, PiP, refresh-rate matching, channel-flip.</summary>

- Tap to summon chrome; it auto-fades after a few seconds of inactivity
- Overflow menu (phone) or Options pills (Android TV) for all secondary controls
- Audio track and subtitle track selection
- Playback speed (0.5x to 2x) for on-demand content; not available on live streams
- Sleep Timer with a countdown
- Audio Only mode
- Picture-in-Picture, including auto-PiP when you leave the app during playback
- Aspect-ratio control
- **Stream Info overlay** reads codec, resolution, frame rate, decoder (hardware or software), dropped frames, and audio details live from the player, so you see what the device is actually decoding rather than what the upstream server reports
- **Channel-flip** by swiping up or down (phone) or pressing D-pad up or down (Android TV) during single-stream live playback
- MediaStyle media notification with the channel logo for lock-screen and Bluetooth controls, plus background audio
- Display refresh-rate matching for smooth live playback (for example, 50fps content on a 60Hz panel)

</details>

<details>
<summary><strong>Casting</strong> Google Cast from the phone, with native hand-off to AerioTV on Android TV.</summary>

- Cast live channels from the phone to Google Cast receivers on your network
- **Android TV / Google TV with AerioTV installed**: the cast hands off to the AerioTV app on the TV, which tunes the channel itself. No phone-side processing, original audio (including AC-3 surround) passes through, full frame rate
- **Other Cast receivers** (Chromecast, Chromecast Ultra, Cast-enabled TVs without the app): the phone serves the live stream to AerioTV's web receiver, repackaged as HLS with separate video and audio renditions
- Audio is never transcoded: AAC passes through, and AC-3 or E-AC-3 pass through when the receiver reports it can decode them. If it cannot, AerioTV declines to cast that channel and tells you why. Video is passed through as-is (H.264 is what Cast receivers decode)
- No Dispatcharr output profile or other server-side configuration is needed. Earlier guidance about a dedicated cast profile is obsolete
- When casting to the web receiver the phone is the media source, so it has to stay on the same network as the receiver. Weak Wi-Fi on the receiver (for example 2.4 GHz on a Chromecast Ultra) can cause buffering on high-bitrate channels; 5 GHz is recommended
- The cast card at the bottom of the app controls playback; the X stops the TV and closes the card. On Android TV, pressing stop or exit on the remote ends the cast session and returns to Live TV

</details>

<details>
<summary><strong>Google Drive Sync</strong> opt-in, set-up-once, no account required to use the app.</summary>

- Server configurations, preferences, VOD watch progress, EPG reminders, favorites and their order, hidden groups, and accent color sync through a private Google Drive AppData folder
- One-tap Google sign-in
- Opt-in: AerioTV is fully functional without a Google account
- Set up once on one device and your other devices pick up the same data on launch

</details>

<details>
<summary><strong>Android TV</strong> D-pad focus model, mini-player, LAN/WAN switching.</summary>

- Full D-pad navigation with a tvOS-style focus model (focus cards and focus scaling)
- Options pills for audio, subtitles, speed, sleep timer, and stream info
- D-pad up or down changes channels during single-stream live playback
- A mini-player keeps the current stream alive in a corner while you browse the guide or settings
- Channels and logos sized for living-room viewing
- LAN / WAN switching: save your home Wi-Fi and a per-playlist LAN URL, and AerioTV routes to the local address at home and the remote address away

</details>

<details>
<summary><strong>Phone, tablet & foldable</strong> mini-player, gestures, adaptive layouts.</summary>

- A mini-player keeps the stream alive while you browse the guide, settings, or on-demand library
- Picture-in-Picture and swipe-to-dismiss on the phone player
- A portrait List / Guide toggle on phones
- Runs across phones, tablets, and foldables (tested on the Galaxy Z Fold 5)

</details>

## Supported Server Types

AerioTV connects to three different playlist types. Each unlocks a different set of features. If you are choosing between them, the short version is below.

Click each type for the full breakdown:

<details>
<summary><strong>Dispatcharr Direct Connect</strong> <em>(Recommended)</em> admin username and password, or an API key. <em>Most full-featured option.</em></summary>

[Dispatcharr](https://github.com/Dispatcharr/Dispatcharr) is a self-hosted IPTV middleware that gives users control over their IPTV services. See the linked GitHub.

**What Dispatcharr is uniquely good at**

- **Server-side DVR**: schedule recordings that keep running even when AerioTV is closed or the device is asleep. (Local recording to the device works on every server type, but Dispatcharr is the only one where the server itself runs the recording.)
- **Comskip (commercial-skip)**: toggle it when scheduling a server-side recording, or run it after the fact from the DVR tab. Comskip runs on the Dispatcharr server, so it is only available for server-side recordings.
- **Server-side recording playback**: stream completed server recordings directly, no auth headers needed.
- **Server-side stream failover via channel UUID**: when a primary stream dies mid-playback, Dispatcharr swaps to a backup provider transparently.
- **TMDB-enriched VOD metadata**: backdrops, plots, cast, director, year, rating, runtime, plus per-episode air dates, TMDB ratings, IMDB IDs, and per-episode artwork, pulled in by Dispatcharr's TMDB scraper. (Xtream Codes also has VOD, but its metadata is whatever the provider supplies, usually poster, title, and a one-line plot.)
- **Bulk EPG fetch**: one network call returns the grid for every channel via `/api/epg/grid/`. Xtream Codes uses per-stream EPG calls; M3U pulls XMLTV from a separate URL.
- **Per-server custom User-Agent override**: set it in Settings, Edit Playlist. It is sent on Dispatcharr API requests and on playback, so the value shows up in Dispatcharr's admin Stats panel. Not currently exposed for Xtream Codes or M3U.
- **External XMLTV URL override** <em>(advanced)</em>: point the EPG at a third-party XMLTV source while keeping channels from Dispatcharr's API.
- **Auto-discovery of recordings scheduled outside the app**: recordings you scheduled from the Dispatcharr web UI appear in AerioTV's DVR tab within a couple of minutes. Xtream Codes and M3U have no server-side scheduler to discover from.

</details>

<details>
<summary><strong>Xtream Codes</strong> source URL plus username and password. <em>No self-hosting required.</em></summary>

The Xtream Codes API is what most IPTV providers natively expose. You log in with the username and password your provider gave you, and AerioTV pulls live TV, movies, and series.

**Benefits**

- **No self-hosting.** Most IPTV providers expose an Xtream Codes endpoint by default. Paste the URL, type your credentials, done.
- **Live TV plus a VOD library.** Movies and series come from the same login as live channels, with no separate EPG or VOD URLs to manage.
- **Per-playlist VOD toggle.** Settings, Edit Playlist exposes the same "fetch VOD from this playlist" switch Dispatcharr has, so you can keep a secondary playlist's Live TV without loading its VOD library every launch.
- **Local DVR with pre-roll and post-roll.** Recordings on this device, with the same buffer pickers (None / 5 / 10 / 15 / 30 / 60 min or custom) Dispatcharr server-side recordings get. Recordings continue while the app stays running.
- **EPG via TVG ID matching.** Most provider EPGs key to Xtream's `tvg_id` field automatically. You can also point an external XMLTV URL at it.
- **Familiar auth model.** A single username and password.

**Drawbacks**

- **VOD metadata is provider-supplied, not TMDB-enriched.** You typically get the poster, title, and a one-line plot. Per-episode air dates, TMDB ratings, and per-episode artwork are not available.
- **No server-side DVR.** Recordings are local only, so AerioTV has to keep running for the recording duration. No comskip (Dispatcharr only).
- **EPG depth varies by provider.** Some give you a few days, some give you a few hours.

</details>

<details>
<summary><strong>M3U Playlist</strong> direct URL plus an optional XMLTV EPG. <em>Universal compatibility, simplest setup.</em></summary>

A plain M3U playlist is just a list of stream URLs in a text file. It works with any IPTV provider that gives you a playlist URL, including providers that do not support the Xtream Codes API.

**Benefits**

- **Universal compatibility.** If a provider hands you any URL ending in `.m3u` or `.m3u8`, AerioTV can play it.
- **Fastest setup.** Paste the URL and you are done. No credentials, no server, no scrape time.
- **No self-hosting.**
- **Local DVR with pre-roll and post-roll.** Recordings on this device, with the same buffer pickers Xtream Codes and Dispatcharr recordings get. Recordings continue while the app stays running.
- **Optional separate XMLTV URL** for EPG. Bring your own EPG source if your provider does not include one.

**Drawbacks**

- **No VOD library.** M3U is live TV only, no movies or series. If your provider has VOD, you will need their Xtream Codes endpoint (or a Dispatcharr instance pointed at them) to access it.
- **No server-side DVR.** Recordings are local only, so AerioTV has to be running for the recording to capture. No comskip (Dispatcharr only).
- **EPG depends on a separate XMLTV source.** You set the URL yourself, and EPG quality is whatever that source provides.
- **No stream failover.** When a stream URL stops working, the provider has to fix the playlist. There is no server-side swap like Dispatcharr has.
- **Large M3U files can be slow to parse** on first launch. A playlist with tens of thousands of channels takes a noticeable beat to ingest.

</details>

## Networking

AerioTV talks to your server directly from the device. If the server sits
behind a reverse proxy with single sign-on (SSO), the app's requests have no
browser session, so the paths it uses need to pass through to the server's
own authentication instead. Each bypassed path is still guarded by the
server: the Dispatcharr API by an API key or token, the Xtream Codes paths
by the account's username and password, and the stream proxy by the stream
UUID in the URL.

<details>
<summary><strong>Pangolin access rules for Dispatcharr</strong> (click to expand)</summary>

Add these rules to the Dispatcharr resource in this order. The three
"Pass to Auth" rules keep the API documentation behind SSO; the rest let
AerioTV reach the server. Rules 6 through 11 are only needed when a
Dispatcharr user connects through an Xtream Codes playlist instead of
Direct Connect. Direct Connect never touches `/output/`, so there is no
rule for it; see the note below the table.

| # | Action | Match | Path | Needed for |
|---|--------|-------|------|------------|
| 1 | Pass to Auth | Path | `/api/swagger/*` | keeps the API docs behind SSO |
| 2 | Pass to Auth | Path | `/api/redoc/*` | keeps the API docs behind SSO |
| 3 | Pass to Auth | Path | `/api/schema/*` | keeps the API docs behind SSO |
| 4 | Bypass Auth | Path | `/api/*` | channels, EPG, VOD, recordings, logos, native Catch-Up sessions, Mark as Radio Channel (admin only: `PATCH /api/channels/channels/<id>/`) |
| 5 | Bypass Auth | Path | `/proxy/*` | live streams, VOD streams, Catch-Up playback, stream switching |
| 6 | Bypass Auth | Path | `/player_api.php` | Xtream Codes only |
| 7 | Bypass Auth | Path | `/xmltv.php` | Xtream Codes only |
| 8 | Bypass Auth | Path | `/get.php` | Xtream Codes only |
| 9 | Bypass Auth | Path | `/live/*` | Xtream Codes only |
| 10 | Bypass Auth | Path | `/movie/*` | Xtream Codes only |
| 11 | Bypass Auth | Path | `/series/*` | Xtream Codes only |
| 12 | Bypass Auth | Path | `/timeshift/*` | Xtream Codes Catch-Up; also the Direct Connect Catch-Up fallback on Dispatcharr builds without native catch-up sessions |

Anyone who knows a stream UUID can play that stream through rule 5, which
is how Dispatcharr's proxy works with or without a reverse proxy. A geo or
IP rule on the resource narrows that further if you want it.

`/output/*` (the M3U playlist and XMLTV export) is deliberately not in the
list. Direct Connect reads channels and the guide through `/api/*`, so
bypassing SSO there would only publish an unauthenticated playlist. Add a
`/output/*` bypass only if you point an M3U playlist at Dispatcharr, and
then limit it with Dispatcharr's own network access settings.

</details>

<details>
<summary><strong>Every Dispatcharr API path AerioTV uses</strong> (for a narrower set of rules than <code>/api/*</code>)</summary>

If you would rather not bypass SSO for all of `/api/*`, these are the paths
the app requests, taken from the code of both platforms. `<id>` is a
numeric id or session token; reverse proxies usually need a wildcard there.

| # | Area | Path | Used for |
|---|------|------|----------|
| 1 | Login and account | `/api/accounts/token/` | username and password login, returns the JWT pair |
| 2 | Login and account | `/api/accounts/token/refresh/` | renews the access token so you stay signed in |
| 3 | Login and account | `/api/accounts/users/me/` | your user record, including the API key and the Catch-Up (XC) password |
| 4 | Login and account | `/api/accounts/users/` | admin check; a 2xx here proves the account is an admin (unlocks Switch Stream and server-side features) |
| 5 | Server | `/api/core/version/` | server version, also the connectivity and auth test at setup |
| 6 | Server | `/api/core/settings/` | server-wide switches such as whether Catch-Up is enabled |
| 7 | Channels and guide | `/api/channels/channels/` | the channel list for the playlist |
| 8 | Channels and guide | `/api/channels/channels/<id>/` | one channel's details and stream order (Switch Stream reorder); `PATCH` with `is_radio` for Mark as Radio Channel and Unmark Radio Channel (admin only) |
| 9 | Channels and guide | `/api/channels/channels/<id>/streams/` | a channel's member streams for Switch Stream |
| 10 | Channels and guide | `/api/channels/groups/` | channel groups for the group pills and sidebar |
| 11 | Channels and guide | `/api/channels/profiles/` | channel profiles for the Edit Playlist picker |
| 12 | Channels and guide | `/api/channels/profiles/<id>/` | the channels inside the chosen profile |
| 13 | Channels and guide | `/api/channels/logos/<id>/cache/` | channel logo images |
| 14 | Channels and guide | `/api/channels/summary/` | lightweight counts used to verify the connection |
| 15 | Channels and guide | `/api/epg/grid/` | the bulk EPG window (about -1 h to +24 h) that fills the guide |
| 16 | Channels and guide | `/api/epg/programs/` | program search and per-channel program lists beyond the grid window |
| 17 | Channels and guide | `/api/epg/programs/<id>/` | one program's full detail (categories, rating) for tinted cards and the info sheet |
| 18 | Channels and guide | `/api/epg/current-programs/` | what is airing now on a set of channels (Live TV cards, Top Shelf) |
| 19 | Channels and guide | `/api/epg/epgdata/` | the EPG channel rows that map tvg ids to EPG sources |
| 20 | Channels and guide | `/api/epg/sources/` | the server's EPG sources, layered onto the guide |
| 21 | Channels and guide | `/api/m3u/accounts/` | source account names shown next to streams and in the VOD version picker |
| 22 | DVR | `/api/channels/recordings/` | list and schedule recordings |
| 23 | DVR | `/api/channels/recordings/<id>/` | one recording's details, edit and delete |
| 24 | DVR | `/api/channels/recordings/<id>/file/` | plays a completed recording |
| 25 | DVR | `/api/channels/recordings/<id>/stop/` | stops a recording in progress |
| 26 | DVR | `/api/channels/recordings/<id>/comskip/` | runs commercial removal on a recording |
| 27 | DVR | `/api/channels/series-rules/` | series recording rules |
| 28 | DVR | `/api/channels/series-rules/evaluate/` | schedules the episodes a new series rule matches |
| 29 | VOD | `/api/vod/categories/` | movie and series categories |
| 30 | VOD | `/api/vod/movies/` | movie library pages, search and Recently Added |
| 31 | VOD | `/api/vod/movies/<id>/providers/` | the copies of a movie across source accounts (version picker) |
| 32 | VOD | `/api/vod/movies/<id>/provider-info/` | TMDB-enriched detail for a movie |
| 33 | VOD | `/api/vod/series/` | series library pages, search and Recently Added |
| 34 | VOD | `/api/vod/series/<id>/` | one series by id, for Continue Watching and Watchlist rows |
| 35 | VOD | `/api/vod/series/<id>/providers/` | the copies of a series across source accounts |
| 36 | VOD | `/api/vod/series/<id>/provider-info/` | TMDB-enriched detail for a series |
| 37 | VOD | `/api/vod/episodes/` | the episodes of a series |
| 38 | Playback sessions | `/api/proxy/hls/sessions/` | opens a Force HLS session for a channel |
| 39 | Playback sessions | `/api/proxy/hls/sessions/<token>/` | closes that session when playback stops |
| 40 | Playback sessions | `/api/catchup/sessions/` | opens a native Catch-Up session for a past program |
| 41 | Playback sessions | `/api/catchup/sessions/<id>/` | closes the Catch-Up session |
| 42 | Playback sessions | `/api/catchup/sessions/<id>/position/` | reports the playback position so the session can be resumed |

**Collapsed to prefixes (10 rules cover all 42 paths):**
`/api/accounts/*`, `/api/core/*`, `/api/channels/*`, `/api/epg/*`, `/api/m3u/*`,
`/api/vod/*`, `/api/proxy/*`, `/api/catchup/*`, plus `/proxy/*` and
`/timeshift/*`.

New Dispatcharr features will add paths over time, which is the trade against
the single `/api/*` rule.

</details>

## OTA / HDHomeRun Channels (MPEG-2)

Over-the-air broadcast channels (ATSC tuners such as HDHomeRun) carry
MPEG-2 video. Android TV boxes generally include an MPEG-2 hardware
decoder, but many phones and tablets do not, so these channels may fail
to play on handheld devices.

For Dispatcharr users the fix is a one-time server-side transcode:
create an ffmpeg [Stream Profile](https://dispatcharr.github.io/Dispatcharr-Docs/system/?h=stream+profiles#stream-profiles)
and assign it to your OTA channels. Command: `ffmpeg`. Parameters
(paste exactly this, and do NOT include the word `ffmpeg` at the start
of the parameters field):

```
-fflags +discardcorrupt+genpts -user_agent {userAgent} -i {streamUrl} -map 0:v:0 -map 0:a? -vf yadif -c:v libx264 -preset veryfast -tune zerolatency -crf 21 -maxrate 12M -bufsize 24M -g 60 -keyint_min 60 -sc_threshold 0 -c:a ac3 -mpegts_flags +pat_pmt_at_frames+resend_headers+initial_discontinuity -f mpegts pipe:1
```

This deinterlaces the broadcast and re-encodes it to H.264 with AC-3
audio, which every device plays natively. Expect roughly one CPU core
per concurrently watched OTA channel; if your server has a hardware
encoder, substitute `-c:v h264_qsv` or `-c:v h264_nvenc` for
`-c:v libx264 -crf 21`. Remember to assign the profile to the OTA
channels themselves: editing a profile does not move any channel onto
it.

If your HDHomeRun is a transcode-capable model (EXTEND class), enabling
its built-in H.264 transcoder is an alternative that needs no server
CPU at all.

## Tech Stack

- Kotlin 2.3 + Jetpack Compose (Material 3)
- Compose for TV (`androidx.tv`) for Google TV / Android TV form factors
- Media3 / ExoPlayer for playback (HLS, DASH, progressive; hardware decode including HEVC HDR)
- Room (relational data) + DataStore (preferences)
- Ktor + kotlinx.serialization (Dispatcharr, Xtream Codes, M3U, XMLTV)
- Hilt (DI), Coroutines + Flow (async), Navigation Compose (routing)
- Coil (image loading), Google Drive AppData (optional settings and progress sync)

## Requirements for Development

- Android Studio (latest stable)
- JDK 17 or newer (the JDK bundled with Android Studio works)
- Android SDK 36 (compile and target), minSdk 26 (Android 8.0)

## Getting Started

Clone the repository and build the debug app:

```
git clone https://github.com/jonzey231/AerioTV-Android.git
cd AerioTV-Android
./gradlew :app:assembleDebug
```

Or open the project root in Android Studio and run the `app` configuration on a device or emulator.

Optional: Google Drive sync needs your own Google Cloud OAuth Web Client ID in `local.properties` as `GOOGLE_DRIVE_WEB_CLIENT_ID`. The app is fully functional without it; only Drive sync is disabled.

## Project Structure

```
app/src/main/java/com/aeriotv/android/
    MainActivity.kt, Navigation.kt, AerioTVApplication.kt
    core/
        network/        Ktor clients (Dispatcharr, Xtream Codes, M3U)
        parser/         M3U + XMLTV parsing
        playback/       ExoPlayer holder, tuning, refresh-rate matching
        data/           Room database + DAOs
        preferences/    DataStore settings
        sync/           Google Drive AppData sync
        pip/            Picture-in-Picture
        wifi/           LAN / WAN home-network detection
        security/       log sanitization, safe image URLs
        category/  debug/  di/  system/  tv/
    feature/
        livetv/  player/  multiview/  dvr/  ondemand/  channels/
        onboarding/  settings/  miniplayer/  splash/  favorites/
        reminders/  watchprogress/  whatsnew/  playlist/  main/
    ui/
        adaptive/  scale/  theme/  tv/  textfield/
```

## Configuration

- On first launch the app presents an onboarding flow where you add your server
- Server configurations can be carried to another device with Google Drive sync
- EPG data is cached locally (Room) for instant now-playing on relaunch
- The EPG window is configurable from 6 hours to the full window in Settings, Network
- A "Setting Up" screen shows during a slow first sync

## Sideloading

- Download the latest `.apk` from the [Releases](https://github.com/jonzey231/AerioTV-Android/releases) page
- Install it through your file manager (enable install from unknown sources) or with `adb install path/to/AerioTV.apk`
- Works on phones, tablets, and Google TV / Android TV

## Building for Release

- App bundle for Google Play: `./gradlew :app:bundleRelease` (requires a `keystore.properties` with your signing config; an absent keystore produces an unsigned release)
- Standalone APK: `./gradlew :app:assembleRelease`

## License

Copyright (C) 2026 Logan Jones

AerioTV for Android is free software: you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the Free
Software Foundation, either version 3 of the License, or (at your option) any
later version. See [LICENSE](LICENSE).

This program is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
PARTICULAR PURPOSE. See the GNU General Public License for more details.

An additional permission under GPL section 7 covers linking with the proprietary
Google Play services client libraries. See [LICENSE-EXCEPTIONS.md](LICENSE-EXCEPTIONS.md).

Releases up to and including v0.4.20 were published under the MIT License. That
grant is not revoked: any copy obtained under MIT keeps its MIT rights to that
snapshot in perpetuity. Everything from the relicensing commit forward is
GPL-3.0-or-later.

### Third-party components

AerioTV bundles an FFmpeg build (LGPL-2.1-or-later) and depends on a number of
Apache-2.0 libraries. The FFmpeg build is configured without `--enable-gpl` and
enables exactly ten audio decoders: `aac`, `ac3`, `eac3`, `dca`, `truehd`,
`mlp`, `mp2`, `mp3`, `flac` and `alac`. Anything outside that set relies on the
device's own hardware decoder. See
[THIRD_PARTY_LICENSES.md](THIRD_PARTY_LICENSES.md) for the full list, the exact
FFmpeg build configuration, and where to obtain the corresponding source. The
same information is in the app under Settings > About > Open Source Licenses.

The Apache-2.0 components include AndroidX and Jetpack Compose, Media3 /
ExoPlayer, Kotlin with kotlinx.coroutines and kotlinx.serialization, Ktor,
Dagger and Hilt, OkHttp, Okio (Square), Coil, ZXing Core and Reorderable. They
are used under the Apache License, Version 2.0, whose full text is at
https://www.apache.org/licenses/LICENSE-2.0 and is also bundled in the app.

FFmpeg is loaded as a dynamically linked JNI shared object (`libffmpegJNI.so`)
inside `app/libs/media3-decoder-ffmpeg.aar`, and can be replaced with a modified
build, as section 6 of the LGPL requires. Build steps are in
[app/libs/README.md](app/libs/README.md). To receive the corresponding FFmpeg
source directly, open an issue at
[github.com/jonzey231/AerioTV-Android/issues](https://github.com/jonzey231/AerioTV-Android/issues).

The Google Play services client libraries (Cast sender, Cast Connect receiver,
Play services Auth, Google Identity) are proprietary and are used under the
Android Software Development Kit License Agreement and the Google APIs Terms of
Service. Linking them with this GPL-licensed program is permitted by an
additional permission under GPL section 7; see
[LICENSE-EXCEPTIONS.md](LICENSE-EXCEPTIONS.md).

The four-color Google "G" on the Sign in with Google button
(`res/drawable/ic_google_g.xml`) is a trademark of Google LLC, used per the
Google Sign-In branding guidelines.

### Patents

AerioTV includes independent implementations of audio and video codecs, supplied
by FFmpeg, that may be covered by patents in some countries. AerioTV is free
software under GPL-3.0-or-later and grants no patent license of any kind; users
and redistributors are responsible for compliance with the patent law that
applies where they live.

AerioTV also encodes video on the device for casting, in H.264/AVC (High
profile) and HEVC/H.265 (Main profile). This encoding, like hardware and
platform decoding of these formats, uses only the codecs provided by the
operating system: VideoToolbox on Apple devices and MediaCodec on Android
devices. AerioTV does not bundle any third-party video encoder. These operating
system codecs are licensed by Apple, and by Google or the device manufacturer, respectively for use on those
devices; AerioTV grants no additional patent license for H.264/AVC or HEVC/H.265
encoding or decoding.

Dolby, DTS and other names that appear in this project are trademarks of their
respective owners, used only to identify the audio formats concerned. AerioTV is
not affiliated with, endorsed by, or certified by any of them.

### TMDB attribution

This product uses the TMDB API but is not endorsed or certified by TMDB.

TMDB data and images are used only after a TMDB API key is configured in
Settings > App Behaviors.

## Support

To report bugs or request features, open an issue at [github.com/jonzey231/AerioTV-Android/issues](https://github.com/jonzey231/AerioTV-Android/issues).
