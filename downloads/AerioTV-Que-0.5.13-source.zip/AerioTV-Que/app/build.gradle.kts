import org.jetbrains.kotlin.gradle.dsl.JvmTarget
import java.util.Properties

plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.kotlin.serialization)
    alias(libs.plugins.ksp)
    alias(libs.plugins.hilt)
}

// Read the OAuth Web Client ID from local.properties (never checked in) so
// Drive Sync can do a real Sign-in with Google flow without leaking the
// project credentials into git. Each contributor pastes their own once.
val localProps = Properties().apply {
    val f = rootProject.file("local.properties")
    if (f.exists()) f.inputStream().use { load(it) }
}
val googleDriveWebClientId: String =
    localProps.getProperty("GOOGLE_DRIVE_WEB_CLIENT_ID")
        ?: System.getenv("GOOGLE_DRIVE_WEB_CLIENT_ID")
        ?: ""

// Google Cast receiver application ID (registered in the Cast SDK Developer
// Console; ties the Cast App ID to this app's package for Cast Connect). Read
// from local.properties / env like the Drive client id so it's never checked
// in. Left EMPTY by default: the Cast button and CastContext init are gated on
// this being non-blank (see AerioCastOptionsProvider + MainActivity), so a
// build without a registered id simply ships Cast disabled rather than crashing
// on an invalid application id.
val castReceiverAppId: String =
    localProps.getProperty("CAST_RECEIVER_APP_ID")
        ?: System.getenv("CAST_RECEIVER_APP_ID")
        ?: ""

// Release signing for Play uploads. Reads from keystore.properties (gitignored,
// never committed). When absent (e.g. a contributor without the upload key),
// the release signingConfig is simply not created and release builds stay
// unsigned -- debug builds are unaffected. Play App Signing holds the real
// app signing key; this is only the upload key (resettable via Play Console).
val keystoreProps = Properties().apply {
    val f = rootProject.file("keystore.properties")
    if (f.exists()) f.inputStream().use { load(it) }
}
val hasReleaseSigning = keystoreProps.getProperty("storeFile") != null

android {
    namespace = "com.aeriotv.android"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.aeriotv.blue"
        minSdk = 26
        targetSdk = 36
        versionCode = 6901
        versionName = "0.5.13-que.1"
        vectorDrawables { useSupportLibrary = true }
        ndk {
            abiFilters += listOf("arm64-v8a", "armeabi-v7a", "x86_64")
        }
        buildConfigField(
            "String",
            "GOOGLE_DRIVE_WEB_CLIENT_ID",
            "\"$googleDriveWebClientId\"",
        )
        buildConfigField(
            "String",
            "CAST_RECEIVER_APP_ID",
            "\"$castReceiverAppId\"",
        )
    }

    if (hasReleaseSigning) {
        signingConfigs {
            create("release") {
                storeFile = rootProject.file(keystoreProps.getProperty("storeFile"))
                storePassword = keystoreProps.getProperty("storePassword")
                keyAlias = keystoreProps.getProperty("keyAlias")
                keyPassword = keystoreProps.getProperty("keyPassword")
            }
        }
    }

    buildTypes {
        // LOCAL PERF BUILD (not for distribution): release settings but signed
        // with the DEBUG key, so it installs over an existing debug install
        // without wiping app data. Debug builds run non-optimized with Compose
        // debug instrumentation, which inflates frame timings enough to swamp
        // the differences a perf change makes; this variant is what device
        // measurements should use. Build: :app:assembleGithubPerf
        create("perf") {
            initWith(getByName("release"))
            isDebuggable = false
            signingConfig = signingConfigs.getByName("debug")
            matchingFallbacks += "release"
        }
        release {
            // R8 on (Play Console 2026-09-09: "App optimization is below our
            // threshold, Obfuscation 1%"). Keep rules in proguard-rules.pro;
            // line numbers are kept and the source file renamed so crash
            // traces still resolve through the uploaded mapping.
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            if (hasReleaseSigning) {
                signingConfig = signingConfigs.getByName("release")
            }
        }
    }

    // Distribution split (in-app updater). The GitHub/sideload channel carries
    // the self-updater + REQUEST_INSTALL_PACKAGES (github manifest overlay);
    // the Play channel must contain NEITHER -- Play policy forbids self-update
    // of Play-distributed builds and the manifest permission alone triggers a
    // declaration review. Build the GitHub release APK with
    // :app:assembleGithubRelease and the Play AAB with :app:bundlePlayRelease.
    flavorDimensions += "distribution"
    productFlavors {
        create("github") {
            dimension = "distribution"
            buildConfigField("boolean", "UPDATER_ENABLED", "true")
        }
        create("play") {
            dimension = "distribution"
            buildConfigField("boolean", "UPDATER_ENABLED", "false")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
        jniLibs {
            useLegacyPackaging = false
        }
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(JvmTarget.JVM_17)
    }
}

composeCompiler {
    // Task #190 perf audit: `./gradlew assembleGithubRelease -PcomposeReports`
    // drops skippability + stability reports under
    // app/build/compose_reports/. Opt-in only; normal builds unaffected.
    if (project.hasProperty("composeReports")) {
        reportsDestination = layout.buildDirectory.dir("compose_reports")
        metricsDestination = layout.buildDirectory.dir("compose_reports")
    }
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.lifecycle.viewmodel.compose)
    implementation(libs.androidx.lifecycle.process)
    implementation(libs.androidx.activity.compose)

    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.ui)
    implementation(libs.androidx.ui.graphics)
    implementation(libs.androidx.ui.tooling.preview)
    implementation(libs.androidx.material3)
    implementation(libs.androidx.material3.windowsizeclass)
    // Fold awareness for two-pane Settings (phase 2): WindowLayoutInfo gives the
    // hinge bounds so the sidebar / detail boundary can sit on the crease.
    implementation(libs.androidx.window)
    implementation(libs.androidx.material.icons.extended)
    implementation(libs.androidx.navigation.compose)

    implementation(libs.androidx.tv.material)
    implementation(libs.androidx.tvprovider)

    implementation(libs.androidx.media3.exoplayer)
    implementation(libs.androidx.media3.exoplayer.hls)
    implementation(libs.androidx.media3.exoplayer.dash)
    implementation(libs.androidx.media3.datasource.okhttp)
    implementation(libs.androidx.media3.extractor)
    implementation(libs.androidx.media3.session)
    implementation(libs.androidx.media3.ui)
    // FFmpeg software audio decoder (built from the media3 1.4.1 decoder_ffmpeg
    // extension). Google ships no prebuilt, so this AAR is built from source; it
    // restores AC-3 broadcast audio on devices with no hardware AC-3 decoder
    // (e.g. Chromecast with Google TV), wired in as the fallback renderer by
    // aerioRenderersFactory. Consumed via files() so its base media3 classes
    // resolve against the maven deps above.
    //
    // Enabled decoders: aac, ac3, eac3, dca, truehd, mlp, mp2, mp3, flac, alac.
    // eac3/dca/truehd/mlp were dropped 2026-09-11 and RESTORED 2026-09-14 to
    // match the decoder set VLC and Kodi ship: with surround passthrough off the
    // sink is forced to PCM, and a platform decoder that exposes E-AC-3 for
    // bitstream only (Shield TV) then declines the track, so without a software
    // fallback the track got no renderer at all and played silent. aac was
    // dropped 2026-09-12 and RESTORED 2026-09-14 as well, which brings back the
    // original GH #45 fix: on the on-demand path the FFmpeg renderer claims
    // HE-AAC ahead of the hardware AAC decoders that throw on it. See
    // app/libs/README.md for the rationale and the reproducible build steps,
    // and the Patents section of README.md.
    implementation(files("libs/media3-decoder-ffmpeg.aar"))

    // Google Cast (GH #33). SENDER: cast-framework gives the phone/tablet the
    // Cast button, SessionManager, and RemoteMediaClient; mediarouter backs the
    // route discovery/selection we drive from a custom Compose chooser (avoids
    // the AppCompat Theme.MediaRouter dependency the stock MediaRouteButton
    // needs). RECEIVER: cast-tv is the Cast Connect library (CastReceiverContext
    // + MediaManager) so the AerioTV Android-TV build plays a cast load with its
    // OWN ExoPlayer (raw MPEG-TS via TsExtractor + the ffmpeg AC-3 AAR) instead
    // of the web receiver, which cannot play raw TS. All flavors: on a device
    // without Google Play services Cast simply finds no routes and stays hidden.
    implementation(libs.play.services.cast.framework)
    implementation(libs.play.services.cast.tv)
    implementation(libs.androidx.mediarouter)

    // Pure-JVM unit tests for the cast HLS proxy remuxer (test scope only).
    testImplementation(libs.junit)

    implementation(libs.kotlinx.coroutines.android)
    implementation(libs.ktor.client.core)
    implementation(libs.ktor.client.okhttp)
    implementation(libs.ktor.client.logging)
    implementation(libs.ktor.client.content.negotiation)
    implementation(libs.ktor.serialization.kotlinx.json)
    // Companion remote (GH #33 second-screen): TV-side embedded WS server + phone-side WS client.
    implementation(libs.ktor.server.core)
    implementation(libs.ktor.server.cio)
    implementation(libs.ktor.server.websockets)
    implementation(libs.ktor.client.websockets)
    implementation(libs.kotlinx.serialization.json)

    implementation(libs.hilt.android)
    ksp(libs.hilt.compiler)
    implementation(libs.hilt.navigation.compose)

    implementation(libs.androidx.room.runtime)
    implementation(libs.androidx.room.ktx)
    ksp(libs.androidx.room.compiler)

    implementation(libs.coil.compose)
    implementation(libs.coil.network.okhttp)
    implementation(libs.coil.svg)

    implementation(libs.androidx.datastore.preferences)
    implementation(libs.androidx.documentfile)
    implementation(libs.play.services.auth)
    implementation(libs.androidx.credentials)
    implementation(libs.androidx.credentials.playservices)
    implementation(libs.google.identity.googleid)
    implementation(libs.androidx.work.runtime.ktx)
    implementation(libs.androidx.hilt.work)
    ksp(libs.androidx.hilt.compiler)
    implementation(libs.sh.calvin.reorderable)
    implementation(libs.androidx.media)
    // QR encoding for the TV log-share dialog (zxing CORE only: the
    // android-embedded wrapper drags in camera/legacy deps we don't need).
    implementation(libs.zxing.core)

    // ProfileInstaller: hooks into androidx.startup to AOT-compile the methods
    // listed in src/main/baseline-prof.txt at install time. Without this the
    // first paint of every Compose screen (GuideScreen, OnDemandTabContent,
    // MoviesSubScreen ...) is interpreted -> JIT-warmup -> AOT, which on a
    // slow TV device costs hundreds of ms per screen on cold launch and shows
    // up in logcat as `Compiler allocated 8141KB to compile GuideScreen`. With
    // a baseline profile those methods are AOT'd at install and run native
    // from the first frame.
    implementation(libs.androidx.profileinstaller)

    debugImplementation(libs.androidx.ui.tooling)
}
