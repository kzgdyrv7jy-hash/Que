package com.aeriotv.android

import android.net.Uri
import com.aeriotv.android.core.data.M3UChannel
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.zIndex
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import androidx.navigation.navigation
import com.aeriotv.android.core.data.SourceType
import com.aeriotv.android.core.data.db.entity.canRecordToServer
import com.aeriotv.android.core.data.db.entity.dispatcharrEffectiveDvrAccess
import com.aeriotv.android.ui.LocalDvrAccess
import com.aeriotv.android.core.data.db.entity.canSwitchStream
import com.aeriotv.android.core.data.db.entity.capabilities
import com.aeriotv.android.core.data.capability.CapabilitySet
import com.aeriotv.android.ui.LocalCapabilities
import com.aeriotv.android.core.data.guideMatchKey
import com.aeriotv.android.core.pip.findActivity
import com.aeriotv.android.core.preferences.AppPreferences
import com.aeriotv.android.feature.main.MainScaffold
import com.aeriotv.android.feature.main.MainScaffoldEntryPoint
import com.aeriotv.android.feature.miniplayer.MiniPlayerSession
import com.aeriotv.android.feature.miniplayer.MiniPlayerViewModel
import com.aeriotv.android.feature.miniplayer.TvMiniPlayerOverlay
import com.aeriotv.android.feature.multiview.MultiviewScreen
import com.aeriotv.android.feature.onboarding.ChooseSourceTypeScreen
import com.aeriotv.android.feature.onboarding.ConfigureSourceScreen
import com.aeriotv.android.feature.onboarding.SettingUpScreen
import com.aeriotv.android.feature.onboarding.WelcomeScreen
import com.aeriotv.android.feature.ondemand.OnDemandViewModel
import com.aeriotv.android.feature.ondemand.SeriesDetailScreen
import com.aeriotv.android.core.network.PlaybackHeaders
import com.aeriotv.android.feature.player.PlayerScreen
import com.aeriotv.android.feature.player.VODPlayerScreen
import com.aeriotv.android.feature.playlist.PlaylistViewModel
import com.aeriotv.android.feature.playlist.nowPlaying
import com.aeriotv.android.feature.reminders.ReminderBannerHost
import com.aeriotv.android.feature.update.UpdateGate
import com.aeriotv.android.feature.whatsnew.WhatsNewGate
import com.aeriotv.android.ui.LocalCanRecordToServer
import com.aeriotv.android.ui.LocalIsDispatcharrAdmin
import com.aeriotv.android.ui.settings.rememberIsTvDevice
import dagger.hilt.EntryPoint
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.launch

/**
 * EntryPoint accessor so the bootstrap composable can read DataStore-backed
 * preferences without forcing every screen to depend on AppPreferences via a
 * hiltViewModel. Used once at cold-boot to decide whether to auto-resume the
 * last-played channel.
 */
@EntryPoint
@InstallIn(SingletonComponent::class)
interface NavEntryPoint {
    fun appPreferences(): AppPreferences
    fun castReceiver(): com.aeriotv.android.core.cast.AerioCastReceiverController
}

object Routes {
    const val PLAYLIST_GRAPH = "playlist_graph"
    const val BOOTSTRAP = "bootstrap"
    const val WELCOME = "welcome"
    const val CHOOSE_TYPE = "choose_type"
    const val CONFIGURE = "configure/{type}"
    const val MAIN = "main"
    // Task #148 milestone B: optional cs* args put the LIVE player into
    // catch-up mode on TV (phone keeps the recording player, mirroring
    // iPhone vs the tvOS unified player). csEnd <= csStart = not catch-up.
    const val PLAYER = "player/{channelId}?csUrl={csUrl}&csTitle={csTitle}" +
        "&csStart={csStart}&csEnd={csEnd}&csTz={csTz}&csUuid={csUuid}&mini={mini}"
    const val VOD_PLAYER = "vod_player/{movieUuid}?fromStart={fromStart}"
    const val MOVIE_DETAIL = "movie_detail/{movieUuid}"
    const val SERIES_DETAIL = "series_detail/{seriesId}"
    const val VOD_EPISODE_PLAYER = "vod_episode_player/{episodeUuid}?fromStart={fromStart}"
    const val MULTIVIEW = "multiview"
    // fromPlayer marks a search opened from the fullscreen player (Remote
    // Control hold-Down): its Back then resumes the player instead of
    // landing on the tabs. Plain navigate(SEARCH) keeps the default false.
    const val SEARCH = "search?fromPlayer={fromPlayer}"
    fun search(fromPlayer: Boolean) = "search?fromPlayer=$fromPlayer"
    const val RECORDING_PLAYER = "recording_player/{playbackUrl}/{title}?isDvr={isDvr}&fromStart={fromStart}&autoResume={autoResume}&recEnd={recEnd}&recChannelId={recChannelId}&recId={recId}&csStart={csStart}&csEnd={csEnd}&csTz={csTz}&csUuid={csUuid}&csChannel={csChannel}"

    fun configure(type: SourceType) = "configure/${type.name}"
    // mini=true (Remote Control, Logan spec): the player mounts, primes
    // playback as usual, then immediately drops to the corner mini - the
    // optional "start channels in the mini player" tune mode. Only the
    // Live TV tab's tune path passes it; resume/deep-link/cast callers
    // keep the fullscreen default.
    fun player(channelId: String, mini: Boolean = false) =
        "player/${Uri.encode(channelId)}" + if (mini) "?mini=true" else ""
    /** Task #148 milestone B: the unified TV path - catch-up plays inside
     *  the live PlayerScreen with its shared d-pad scrub. */
    fun playerCatchup(
        channelId: String,
        playbackUrl: String,
        title: String,
        csStart: Long,
        csEnd: Long,
        csTz: String,
        csUuid: String,
    ) = "player/${Uri.encode(channelId)}" +
        "?csUrl=${Uri.encode(playbackUrl)}&csTitle=${Uri.encode(title)}" +
        "&csStart=$csStart&csEnd=$csEnd&csTz=${Uri.encode(csTz)}&csUuid=${Uri.encode(csUuid)}"
    // fromStart (tvOS MoviesView "Play from Beginning"): start at 0 and
    // LEAVE the WatchProgress row alone, so Continue Watching survives.
    fun vodPlayer(movieUuid: String, fromStart: Boolean = false) =
        "vod_player/${Uri.encode(movieUuid)}?fromStart=$fromStart"
    fun movieDetail(movieUuid: String) = "movie_detail/${Uri.encode(movieUuid)}"
    fun seriesDetail(seriesId: Int) = "series_detail/$seriesId"
    fun vodEpisodePlayer(episodeUuid: String, fromStart: Boolean = false) =
        "vod_episode_player/${Uri.encode(episodeUuid)}?fromStart=$fromStart"
    fun recordingPlayer(
        playbackUrl: String,
        title: String,
        isDvr: Boolean = false,
        fromStart: Boolean = false,
        // Row tap (iOS parity): resume saved progress, else beginning.
        autoResume: Boolean = false,
        // Scheduled end + recorded channel, for the Recording Ending
        // prompt and its Continue on Live TV hand-off. 0/-1 = unknown.
        recEnd: Long = 0L,
        recChannelId: Int = -1,
        // GH #75 (Apple repo): the Dispatcharr recording id gives the
        // progress row a stable, host-independent identity (dvr-<id>) so
        // resume syncs across devices. -1 = unknown (local file, catch-up).
        recId: Int = -1,
        // Catch-up (task #136): programme window + panel timezone enable the
        // player's re-tune scrubbing. csEnd <= csStart (defaults) = not catch-up.
        csStart: Long = 0L,
        csEnd: Long = 0L,
        csTz: String = "",
        // Task #149: Dispatcharr channel uuid, non-blank only for NATIVE
        // catch-up sessions - seeks re-mint a session instead of
        // rebuilding an XC wall-clock URL, and close revokes the session.
        csUuid: String = "",
        // GH #116: catch-up channel id, keys the resume position.
        csChannel: String = "",
    ) =
        "recording_player/${Uri.encode(playbackUrl)}/${Uri.encode(title)}" +
            "?isDvr=$isDvr&fromStart=$fromStart&autoResume=$autoResume&recEnd=$recEnd&recChannelId=$recChannelId" +
            "&recId=$recId&csStart=$csStart&csEnd=$csEnd&csTz=${Uri.encode(csTz)}&csUuid=${Uri.encode(csUuid)}" +
            "&csChannel=${Uri.encode(csChannel)}"
}

/**
 * Stable watch-progress identity for a recording (GH #75, iOS parity):
 * "dvr-<Dispatcharr recording id>" when the id is known from the recording
 * model or can be read off a /recordings/<id>/ URL; otherwise the URL itself
 * (local file:// / content:// captures, which never leave the device: the
 * Drive sync builder filters URL-shaped keys).
 */
internal fun recordingProgressId(playbackUrl: String, recId: Int): String {
    if (recId > 0) return "dvr-$recId"
    val fromUrl = Regex("/recordings/(\\d+)/").find(playbackUrl)?.groupValues?.get(1)
    return if (fromUrl != null) "dvr-$fromUrl" else playbackUrl
}

/**
 * Silence any LIVE session (persistent exo window + mini player + media service)
 * before a VOD/recording player mounts. Extracted from the RECORDING_PLAYER route
 * so the two VOD routes get the same teardown -- required once companion VodPlay
 * can navigate player/... -> vod_player/... directly with live still running
 * (adversarial review 2026-07-15).
 */
@Composable
private fun tearDownLiveForVod(navController: androidx.navigation.NavController) {
    val vm: MiniPlayerViewModel = hiltViewModel()
    val context = androidx.compose.ui.platform.LocalContext.current
    LaunchedEffect(Unit) {
        val entry = dagger.hilt.android.EntryPointAccessors.fromApplication(
            context.applicationContext,
            MainScaffoldEntryPoint::class.java,
        )
        // Phone: new on-demand content replaces an on-demand mini (saved and
        // released first). No-op on TV and for the mini's own expand.
        com.aeriotv.android.feature.player.PhoneVodMini.closeForNewContent()
        vm.dismiss()
        entry.exoWindowState().hide()
        entry.exoPlayerHolder().stop()
        com.aeriotv.android.core.playback.AerioMediaPlaybackService.stop(context.applicationContext)
    }
}

@Composable
fun AerioTVNavHost(
    initialUrl: String? = null,
    initialEpgUrl: String? = null,
    initialApiKey: String? = null,
    deepLinkTarget: DeepLinkTarget? = null,
    onDeepLinkConsumed: () -> Unit = {},
) {
    val navController = rememberNavController()

    // GH #33 companion VOD/DVR: while this phone is connected to an AerioTV TV,
    // the VOD/recording PLAY actions below send the item to the TV instead of
    // playing locally (live channels already do this inside PlayerScreen's
    // companion mode). Hoisted here so every route's play lambda can share it.
    val navHostContext = androidx.compose.ui.platform.LocalContext.current
    val companionRemoteNav = remember {
        dagger.hilt.android.EntryPointAccessors.fromApplication(
            navHostContext.applicationContext,
            com.aeriotv.android.feature.player.PlayerScreenEntryPoint::class.java,
        ).companionRemote()
    }
    val companionConnNav by companionRemoteNav.connection.collectAsStateWithLifecycle()
    /** Non-null TV name while companion-connected; null otherwise. */
    val companionTvName: String? =
        (companionConnNav as? com.aeriotv.android.core.cast.companion.CompanionRemoteController.Conn.Connected)
            ?.name
    // Cast play-where prompt (PlayWhereRouter) for on-demand content:
    // catch-up, movies, episodes and recordings. The Google Cast sender has
    // no load path for these (AerioCastSender only casts LIVE channels:
    // tuneLiveChannel feeds the HLS proxy or the Android TV app's channel
    // tune, and the receiver's on-demand kind is only ever produced by the
    // Android TV app itself), so the receiver button is hidden and the
    // prompt offers Play Here or Cancel. No prompt without a session.
    val playWhereEntry = remember {
        dagger.hilt.android.EntryPointAccessors.fromApplication(
            navHostContext.applicationContext,
            com.aeriotv.android.feature.main.MainScaffoldEntryPoint::class.java,
        )
    }
    val playWhereSender = remember { playWhereEntry.castSender() }
    val playWhereScope = androidx.compose.runtime.rememberCoroutineScope()
    com.aeriotv.android.feature.main.PlayWhereDialogHost(playWhereSender)
    fun playOnDemandWhere(title: String, playHere: () -> Unit) {
        com.aeriotv.android.feature.main.PlayWhereRouter.route(
            sender = playWhereSender,
            title = title.ifBlank { "Play" },
            playHere = playHere,
            playOnReceiver = null,
        )
    }
    /** Same, for a movie or episode known only by its video id: the title
     *  comes from the catalog, else from its watch-progress row. */
    fun playVodWhere(
        videoId: String,
        onDemand: com.aeriotv.android.feature.ondemand.OnDemandViewModel?,
        playHere: () -> Unit,
    ) {
        if (playWhereSender.state.value !is com.aeriotv.android.core.cast.AerioCastSender.State.Connected) {
            playHere()
            return
        }
        playWhereScope.launch {
            val movie = onDemand?.movieByUuid(videoId)
            val title = movie?.title?.takeIf { it.isNotBlank() }
                ?: movie?.name?.takeIf { it.isNotBlank() }
                ?: runCatching { playWhereEntry.watchProgressDao().getOnce(videoId)?.title }
                    .getOrNull().orEmpty()
            playOnDemandWhere(title, playHere)
        }
    }
    fun toastPlayingOnTv() {
        android.widget.Toast.makeText(
            navHostContext,
            "Playing on ${companionTvName ?: "TV"}",
            android.widget.Toast.LENGTH_SHORT,
        ).show()
    }

    // Audit task #47 + GH #33: resolve any pending aeriotvblue:// / cast / companion
    // deep link once channels are ready. HOISTED to NavHost scope (2026-07-15
    // Streamer device test): this consumer used to live inside composable(MAIN),
    // which is NOT composed while the player / VOD routes are on top -- so a
    // companion or cast channel flip arriving while the TV sat on the live
    // player QUEUED in deepLinkTarget until the user pressed Back (phone flipped
    // ESPN2/ESPNU, TV stayed put). Here it runs no matter which screen is up.
    // We still wait for the playlist graph + loaded channels before acting.
    val dlCurrentEntry by navController.currentBackStackEntryAsState()
    // Leaving the tabs for a fullscreen player cancels any search a tab left
    // open. Without this the keyboard came back when the user minimized to the
    // mini player or PiP: the MAIN route is disposed while a player route is on
    // top, so popping back re-mounted the tab with its search still open and the
    // field's focus effect ran again. One observer here covers every player
    // route (live, catch-up, recording, on demand) and every tab.
    val dlRoute = dlCurrentEntry?.destination?.route
    LaunchedEffect(dlRoute) {
        if (dlRoute != null && dlRoute != Routes.MAIN) {
            com.aeriotv.android.ui.search.SearchDismissSignal.dismissAll()
        }
    }
    val dlGraphEntry = remember(dlCurrentEntry) {
        runCatching { navController.getBackStackEntry(Routes.PLAYLIST_GRAPH) }.getOrNull()
    }
    val dlCastReceiver = remember {
        dagger.hilt.android.EntryPointAccessors.fromApplication(
            navHostContext.applicationContext, NavEntryPoint::class.java,
        ).castReceiver()
    }
    if (dlGraphEntry != null) {
        val dlVm: PlaylistViewModel = hiltViewModel(dlGraphEntry)
        val dlState by dlVm.state.collectAsStateWithLifecycle()
        LaunchedEffect(deepLinkTarget, dlState.channels.size, dlCurrentEntry?.destination?.route) {
            val target = deepLinkTarget ?: return@LaunchedEffect
            when (target) {
                is DeepLinkTarget.Channel -> {
                    val exists = dlState.channels.any {
                        it.id == target.channelId && it.url.isNotBlank()
                    }
                    if (exists) {
                        // If this TV is already on the LIVE player, re-tune in
                        // place (PlayerScreen observes castChannelRequest); a
                        // catch-up replay shares the player/ route but its prime
                        // effect early-returns, so those navigate a fresh live
                        // player instead. First open (on the guide) navigates.
                        val onPlayer = navController.currentDestination
                            ?.route?.startsWith("player/") == true
                        val onCatchup = navController.currentBackStackEntry
                            ?.arguments?.getString("csUrl").orEmpty().isNotBlank()
                        val controllingTv = companionRemoteNav.connection.value is
                            com.aeriotv.android.core.cast.companion.CompanionRemoteController.Conn.Connected
                        if (onPlayer && !onCatchup) {
                            // While controlling a TV the player IS the remote
                            // screen; a notification tap just brings it forward.
                            // requestCastChannel would start LOCAL playback.
                            if (!controllingTv) dlCastReceiver.requestCastChannel(target.channelId)
                        } else {
                            navController.navigate(Routes.player(target.channelId))
                        }
                        onDeepLinkConsumed()
                    } else if (dlState.phase == PlaylistViewModel.Phase.ChannelsReady) {
                        onDeepLinkConsumed() // channels loaded, id gone => drop
                    }
                }
                is DeepLinkTarget.Vod -> {
                    navController.navigate(Routes.movieDetail(target.movieUuid))
                    onDeepLinkConsumed()
                }
                // GH #33 companion remote: AUTOPLAY targets -- straight into
                // the player (the VOD players resolve by uuid themselves).
                is DeepLinkTarget.VodPlay -> {
                    navController.navigate(
                        if (target.isEpisode) Routes.vodEpisodePlayer(target.videoId)
                        else Routes.vodPlayer(target.videoId),
                    ) { launchSingleTop = true }
                    onDeepLinkConsumed()
                }
                is DeepLinkTarget.RecordingPlay -> {
                    // Non-blank title: an empty {title} path segment makes
                    // Routes.recordingPlayer build "recording_player/<url>//"
                    // which throws in navigate() (review 2026-07-15).
                    navController.navigate(
                        Routes.recordingPlayer(
                            target.playbackUrl,
                            target.title.ifBlank { "Recording" },
                        ),
                    ) { launchSingleTop = true }
                    onDeepLinkConsumed()
                }
                is DeepLinkTarget.Settings -> {
                    // Screenshot deep link. Hand the page to the view model:
                    // MainScaffold selects the Settings tab, and SettingsTabContent
                    // (which is not composed until then) applies the route. Pop any
                    // player / detail route off first so the tab shell is on top.
                    if (navController.currentDestination?.route != Routes.MAIN) {
                        runCatching { navController.popBackStack(Routes.MAIN, false) }
                    }
                    dlVm.requestSettingsPage(target.page)
                    onDeepLinkConsumed()
                }
                is DeepLinkTarget.OpenMultiview -> {
                    // Same end state as TV Play on the staging banner, with any
                    // live player popped first (the receiver stopped it).
                    if (navController.currentDestination?.route != Routes.MAIN) {
                        runCatching { navController.popBackStack(Routes.MAIN, false) }
                    }
                    navController.navigate(Routes.MULTIVIEW) { launchSingleTop = true }
                    onDeepLinkConsumed()
                }
                is DeepLinkTarget.ExitPlayer -> {
                    // Companion X: pop the live / VOD / recording player (and
                    // any detail pushed under it) so the tab shell is on top
                    // again, AND put that shell on Live TV.
                    //
                    // Popping alone was not enough (Logan 2026-09-12, Streamer:
                    // "X did not return the TV to Live TV guide on the first
                    // attempt. It worked correctly on the 2nd attempt"). MAIN
                    // keeps its own selected tab, so an X pressed while the
                    // shell sat on Movies / TV Shows came back to that page:
                    // gtvlogs/session7.txt has "companion stop: playback
                    // stopped, exiting to Live TV" at 14:25:23.138 followed at
                    // 14:25:24.016 by "[PROGRESS] target series=277738", the
                    // media page hero recomputing. The second attempt "worked"
                    // only because Live TV was the selected tab by then.
                    //
                    // Request the tab BEFORE popping so the shell is already on
                    // Live TV when it becomes visible, rather than flashing the
                    // page the user left.
                    dlVm.requestLiveTvTab()
                    // navController's OWN current destination, not the
                    // composition snapshot dlCurrentEntry, which can still hold
                    // the pre-pop entry on the frame this effect runs.
                    if (navController.currentDestination?.route != Routes.MAIN) {
                        runCatching { navController.popBackStack(Routes.MAIN, false) }
                    }
                    onDeepLinkConsumed()
                }
                is DeepLinkTarget.GuideProgram -> {
                    // Resolve by guideMatchKey (search results carry that key,
                    // NOT M3UChannel.id); re-emit through the VM so MainScaffold
                    // + GuideScreen both react.
                    val exists = dlState.channels.any {
                        it.guideMatchKey == target.channelId && it.url.isNotBlank()
                    }
                    if (exists) {
                        dlVm.requestGuideJump(target.channelId, target.startMillis)
                        onDeepLinkConsumed()
                    } else if (dlState.phase == PlaylistViewModel.Phase.ChannelsReady) {
                        onDeepLinkConsumed() // channels loaded, key gone => drop
                    }
                    // else: channels still loading; leave the target pending.
                }
            }
        }
    }

    // Is MAIN (the tab shell) the TOP destination? A detail or player route
    // pushed over it leaves the tab composed and still flagged active
    // (LocalTabIsActive), so the TV media pages' focus watchdog used to
    // "recover" focus 200 ms into the push and yank it off the hero button
    // that had just been pressed (Logan 2026-09-11, Streamer: TV Shows hero
    // Details -> hero:Play S1 E1 by=focus-watchdog). Pages gate the watchdog
    // on this instead of guessing.
    val mainIsTopState = remember { mutableStateOf(true) }
    val mainIsTopNow = dlCurrentEntry?.destination?.route == Routes.MAIN
    androidx.compose.runtime.SideEffect {
        if (mainIsTopState.value != mainIsTopNow) mainIsTopState.value = mainIsTopNow
    }
    CompositionLocalProvider(LocalMainIsTopDestination provides mainIsTopState) {
    Box(modifier = Modifier.fillMaxSize()) {
    NavHost(navController = navController, startDestination = Routes.PLAYLIST_GRAPH) {
        navigation(startDestination = Routes.BOOTSTRAP, route = Routes.PLAYLIST_GRAPH) {

            composable(Routes.BOOTSTRAP) { entry ->
                val parent = remember(entry) {
                    navController.getBackStackEntry(Routes.PLAYLIST_GRAPH)
                }
                val vm: PlaylistViewModel = hiltViewModel(parent)
                val state by vm.state.collectAsStateWithLifecycle()
                val context = androidx.compose.ui.platform.LocalContext.current

                // Clean-end session check (StreamEndVerifier), installed once
                // for the whole app and never cleared: the player, the mini
                // player, multiview tiles and the cast ingest all consult it
                // after a live stream ends cleanly, and none of them has a
                // Dispatcharr client of its own. The graph-scoped view model
                // outlives every one of those surfaces; if it ever does not,
                // the call fails and the caller keeps reconnecting.
                LaunchedEffect(vm) {
                    com.aeriotv.android.core.playback.StreamEndVerifier.hook =
                        { channelUuid, connectedAt ->
                            vm.verifyStreamEndedByLimit(channelUuid, connectedAt)
                        }
                }

                // Debug-only auto-load. --es url + --es apikey => Dispatcharr API-key flow.
                // --es url + optional --es epg => M3U flow. Gated in MainActivity via
                // BuildConfig.DEBUG so release builds always ignore intent extras.
                LaunchedEffect(initialUrl, initialEpgUrl, initialApiKey) {
                    if (!initialUrl.isNullOrBlank() && state.url.isBlank()) {
                        if (!initialApiKey.isNullOrBlank()) {
                            vm.loadFromDispatcharr(initialUrl, initialApiKey)
                        } else {
                            vm.loadFromUrl(initialUrl, initialEpgUrl)
                        }
                    }
                }

                LaunchedEffect(state.phase) {
                    when (state.phase) {
                        PlaylistViewModel.Phase.Bootstrapping -> Unit
                        PlaylistViewModel.Phase.NeedsUrl -> navController.navigate(Routes.WELCOME) {
                            // popUpTo the graph (NOT the BOOTSTRAP entry
                            // inclusively): if BOOTSTRAP is the last child of
                            // PLAYLIST_GRAPH the inclusive pop collapses the
                            // whole graph, and the subsequent navigate creates
                            // a FRESH PLAYLIST_GRAPH entry -- new VM store, the
                            // PlaylistViewModel inits a second time, and every
                            // disk read + EPG cache paint runs twice (~700ms +
                            // 70MB of GC churn on cold launch). Popping up to
                            // the graph with inclusive=false leaves the graph
                            // entry intact, so the VM scoped to it survives.
                            popUpTo(Routes.PLAYLIST_GRAPH) { inclusive = false }
                        }
                        PlaylistViewModel.Phase.ChannelsReady -> {
                            // Resume Last Channel (App Behaviors). When the toggle is on
                            // and we have a stored channel id that still exists in the
                            // current playlist, navigate straight into the player. Falls
                            // back to MAIN when the toggle is off or the saved channel is
                            // missing (e.g. user switched playlists since last launch).
                            val prefs = dagger.hilt.android.EntryPointAccessors
                                .fromApplication(context.applicationContext, NavEntryPoint::class.java)
                                .appPreferences()
                            val resume = prefs.autoResumeLastChannelOnce()
                            val resumeId = if (resume) prefs.lastWatchedChannelIdOnce() else ""
                            val hasResumeTarget = resumeId.isNotBlank() &&
                                state.channels.any { it.id == resumeId && it.url.isNotBlank() }
                            if (hasResumeTarget) {
                                navController.navigate(Routes.MAIN) {
                                    popUpTo(Routes.PLAYLIST_GRAPH) { inclusive = false }
                                }
                                navController.navigate(Routes.player(resumeId))
                            } else {
                                navController.navigate(Routes.MAIN) {
                                    popUpTo(Routes.PLAYLIST_GRAPH) { inclusive = false }
                                }
                            }
                        }
                    }
                }

                SettingUpScreen(
                    onSkip = {
                        navController.navigate(Routes.MAIN) {
                            popUpTo(Routes.PLAYLIST_GRAPH) { inclusive = false }
                        }
                    },
                )
            }

            composable(Routes.WELCOME) { entry ->
                val parent = remember(entry) {
                    navController.getBackStackEntry(Routes.PLAYLIST_GRAPH)
                }
                val vm: PlaylistViewModel = hiltViewModel(parent)
                val state by vm.state.collectAsStateWithLifecycle()
                // Sync sub-viewmodel handles the Google sign-in flow here so
                // the Welcome screen stays stateless. Reusing the same VM
                // means a successful sign-in shows up in Settings > Sync
                // without a second sign-in round-trip later.
                val syncVm: com.aeriotv.android.feature.settings.SyncSettingsViewModel = hiltViewModel(parent)
                val syncBuildConfigured = remember { com.aeriotv.android.core.sync.SyncConfig.isConfigured() }
                val context = androidx.compose.ui.platform.LocalContext.current
                val scope = androidx.compose.runtime.rememberCoroutineScope()
                var googleSignInInFlight by remember { mutableStateOf(false) }
                var welcomeNotConfiguredDialog by remember { mutableStateOf(false) }
                // Sync-category chooser shown before the first Drive pull.
                var welcomeSyncChooser by remember { mutableStateOf(false) }
                var welcomeSyncChoicesMade by remember { mutableStateOf(false) }
                var pendingSignIn by remember { mutableStateOf(false) }
                // Restore-progress screen state (replaces the old silent
                // wait between sign-in success and the auto-advance to MAIN).
                // While visible it REPLACES WelcomeScreen entirely -- an
                // overlay would leave Welcome's buttons focusable underneath
                // on TV. BACK is swallowed inside the progress screen.
                var restoreOverlayVisible by remember { mutableStateOf(false) }
                var restoreActivatedPlaylist by remember { mutableStateOf(false) }
                val restoreSteps by syncVm.restoreSteps.collectAsStateWithLifecycle()
                // Shared restore closure: pulls all categories from Drive,
                // then asks PlaylistViewModel to re-bootstrap from whatever
                // playlists just landed in the DB. The existing
                // LaunchedEffect that watches `state.phase == ChannelsReady`
                // will trip and navigate to MAIN on its own, so the Welcome
                // screen never has to ask the navController itself. Called
                // from BOTH the immediate Authorized branch and the
                // post-consent launcher result so the flow is identical
                // regardless of whether the user had granted Drive scope
                // on a previous session.
                val tryRestoreAndAdvance: suspend (String?) -> Unit = { signedInEmail ->
                    // Logan 2026-08-10: signing in here IS the opt-in, so turn
                    // sync on for good rather than treating this as a one-shot
                    // import.
                    //
                    // syncMasterEnabled defaults to FALSE and nothing in this
                    // flow ever set it, while DriveSyncWorker.enqueuePeriodic
                    // is only ever called from setMasterEnabled. So a new user
                    // who signed into Drive during setup got their restore and
                    // then never synced again: Settings showed the master
                    // toggle off and the periodic worker had never been
                    // scheduled. Worst for the exact case Logan raised - a
                    // brand-new account with nothing to restore, where the
                    // import is a no-op and the ONLY thing that mattered was
                    // being switched on from here forward.
                    //
                    // Set before the pull, not after, so an import that throws
                    // still leaves the user syncing. Idempotent, and it runs on
                    // both entry paths (already-Authorized and post-consent)
                    // because both funnel through here.
                    syncVm.setMasterEnabled(true)

                    // Surface the restore-progress screen for the whole pull
                    // + bootstrap stretch. Clear any stale steps first so a
                    // second sign-in attempt doesn't flash the previous run's
                    // settled rows before pullAllTracked resets the list.
                    syncVm.clearRestoreProgress()
                    restoreActivatedPlaylist = false
                    restoreOverlayVisible = true
                    val pulled = runCatching { syncVm.restoreFromDrive() }
                        .getOrDefault(emptyMap())
                    val playlistsRestored = pulled[com.aeriotv.android.core.sync.SyncCategory.Playlists] == true
                    val activated = if (playlistsRestored) {
                        runCatching { vm.loadActivePlaylistIfAvailable() }.getOrDefault(false)
                    } else false
                    if (activated) {
                        // Keep the progress screen up; its Channels & Guide
                        // line now runs until Phase.ChannelsReady trips the
                        // existing auto-advance to MAIN.
                        restoreActivatedPlaylist = true
                    } else {
                        // Nothing to hydrate -- drop back to Welcome, exactly
                        // where the old silent flow left the user.
                        restoreOverlayVisible = false
                        syncVm.clearRestoreProgress()
                    }
                    val message = when {
                        activated -> "Signed in as ${signedInEmail.orEmpty()}. Restoring your data..."
                        signedInEmail != null -> "Signed in as $signedInEmail. No playlists in Drive yet -- set one up below."
                        else -> "Signed in. No playlists in Drive yet."
                    }
                    android.widget.Toast.makeText(
                        context,
                        message,
                        if (activated) android.widget.Toast.LENGTH_SHORT else android.widget.Toast.LENGTH_LONG,
                    ).show()
                }

                val consentLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
                    contract = androidx.activity.result.contract.ActivityResultContracts.StartIntentSenderForResult(),
                ) { result ->
                    scope.launch {
                        // Task #256: AWAIT the consent grant before restoring.
                        // The fire-and-forget form raced tryRestoreAndAdvance:
                        // applying the consent suspends on the encrypted token
                        // save before status flips to SignedIn, so the pull on
                        // a fresh install saw "not signed in", returned
                        // nothing, and the user was told "No playlists in
                        // Drive yet" while the background worker restored them
                        // minutes later with nobody watching.
                        syncVm.acceptConsentResultNow(result.data)
                        tryRestoreAndAdvance(null)
                        googleSignInInFlight = false
                    }
                }

                LaunchedEffect(state.phase) {
                    if (state.phase == PlaylistViewModel.Phase.ChannelsReady) {
                        navController.navigate(Routes.MAIN) {
                            popUpTo(Routes.PLAYLIST_GRAPH) { inclusive = false }
                        }
                    }
                }

                // Backstop: if the restored playlist's channel load FAILS
                // (switchToPlaylist surfaces state.error and never reaches
                // ChannelsReady), don't trap the user on a progress screen
                // whose BACK is disabled -- fall back to Welcome, matching
                // where the old silent flow stranded them.
                LaunchedEffect(restoreActivatedPlaylist, state.error, state.phase) {
                    if (restoreOverlayVisible && restoreActivatedPlaylist &&
                        state.phase != PlaylistViewModel.Phase.ChannelsReady &&
                        state.error != null
                    ) {
                        restoreOverlayVisible = false
                        restoreActivatedPlaylist = false
                        syncVm.clearRestoreProgress()
                    }
                }

                // Task #256 safety net: playlists can land in the DB from the
                // periodic DriveSyncWorker (armed by setMasterEnabled in the
                // restore closure) AFTER a restore attempt came up empty.
                // Historically nothing observed the table from onboarding, so
                // the data was silently restored while the user stayed parked
                // on Welcome until an app restart. If rows appear while we sit
                // at NeedsUrl with no restore or sign-in in flight, activate
                // them; the phase watcher above advances to MAIN. One-shot so
                // a failing channel load can't retrigger in a loop.
                var autoActivatedFromDb by remember { mutableStateOf(false) }
                LaunchedEffect(Unit) {
                    vm.allPlaylists.collect { rows ->
                        if (rows.isNotEmpty() && !autoActivatedFromDb &&
                            state.phase == PlaylistViewModel.Phase.NeedsUrl &&
                            !restoreOverlayVisible && !googleSignInInFlight
                        ) {
                            autoActivatedFromDb = true
                            vm.loadActivePlaylistIfAvailable()
                        }
                    }
                }

                // Sign-in body, hoisted so both the button tap AND the
                // resume-after-chooser path run exactly the same flow.
                val startGoogleSignIn: () -> Unit = start@{
                    val activity = context.findActivity()
                    if (activity == null) {
                        android.widget.Toast.makeText(
                            context,
                            "Sign-in needs a foreground activity. Try again.",
                            android.widget.Toast.LENGTH_SHORT,
                        ).show()
                        return@start
                    }
                    googleSignInInFlight = true
                    scope.launch {
                        val email = syncVm.signInWithGoogle(activity)
                        if (email == null) {
                            googleSignInInFlight = false
                            android.widget.Toast.makeText(
                                context,
                                "Sign-in cancelled or failed.",
                                android.widget.Toast.LENGTH_SHORT,
                            ).show()
                            return@launch
                        }
                        when (val driveResult = syncVm.requestDriveScope()) {
                            is com.aeriotv.android.core.sync.DriveSyncManager.RequestResult.Authorized -> {
                                tryRestoreAndAdvance(email)
                                googleSignInInFlight = false
                            }
                            is com.aeriotv.android.core.sync.DriveSyncManager.RequestResult.NeedsConsent -> {
                                consentLauncher.launch(
                                    androidx.activity.result.IntentSenderRequest.Builder(driveResult.intentSender).build(),
                                )
                            }
                            com.aeriotv.android.core.sync.DriveSyncManager.RequestResult.Failed, null -> {
                                googleSignInInFlight = false
                                android.widget.Toast.makeText(
                                    context,
                                    "Drive authorization failed.",
                                    android.widget.Toast.LENGTH_SHORT,
                                ).show()
                            }
                        }
                    }
                }

                // Chooser confirmed -> continue into the sign-in the user
                // already asked for.
                androidx.compose.runtime.LaunchedEffect(pendingSignIn) {
                    if (pendingSignIn) {
                        pendingSignIn = false
                        startGoogleSignIn()
                    }
                }

                if (restoreOverlayVisible) {
                    com.aeriotv.android.feature.onboarding.OnboardingSyncProgressScreen(
                        steps = restoreSteps,
                        channelsState = when {
                            !restoreActivatedPlaylist ->
                                com.aeriotv.android.core.sync.DriveSyncManager.RestoreStepState.Pending
                            state.phase == PlaylistViewModel.Phase.ChannelsReady ->
                                com.aeriotv.android.core.sync.DriveSyncManager.RestoreStepState.Done
                            else ->
                                com.aeriotv.android.core.sync.DriveSyncManager.RestoreStepState.Running
                        },
                    )
                } else WelcomeScreen(
                    onConnectServer = { navController.navigate(Routes.CHOOSE_TYPE) },
                    // "Skip for now" is iOS parity. With no playlist saved the channel
                    // list is empty; user can reach Settings -> Change playlist later.
                    // The flag stops MAIN's NeedsUrl guard from bouncing right back.
                    onSkip = {
                        vm.onboardingSkipped = true
                        navController.navigate(Routes.MAIN) {
                            popUpTo(Routes.PLAYLIST_GRAPH) { inclusive = false }
                        }
                    },
                    googleSignInInProgress = googleSignInInFlight,
                    onSignInWithGoogle = {
                        if (!syncBuildConfigured) {
                            welcomeNotConfiguredDialog = true
                            return@WelcomeScreen
                        }
                        // Logan 2026-08-10: ask what should come in BEFORE any
                        // of it does. Apple's onboarding chooser, same idea:
                        // the per-category toggles already existed in Settings,
                        // but by the time a user goes looking for them the
                        // restore has already landed (Discord: Glitzbr, whose
                        // second Apple TV inherited a remote map meant for a
                        // different remote). Deferring sign-in behind the sheet
                        // means a declined category is never fetched at all.
                        if (!welcomeSyncChoicesMade) {
                            welcomeSyncChooser = true
                            return@WelcomeScreen
                        }
                        startGoogleSignIn()
                    },
                )

                if (welcomeSyncChooser) {
                    com.aeriotv.android.feature.onboarding.OnboardingSyncCategoryChooser(
                        onConfirm = { choices ->
                            scope.launch {
                                choices.forEach { (category, enabled) ->
                                    syncVm.setCategoryEnabled(category, enabled)
                                }
                                welcomeSyncChoicesMade = true
                                welcomeSyncChooser = false
                                // Re-enter the sign-in path the user already
                                // asked for, now that the choices are stored.
                                pendingSignIn = true
                            }
                        },
                        onDismiss = { welcomeSyncChooser = false },
                    )
                }

                if (welcomeNotConfiguredDialog) {
                    com.aeriotv.android.ui.scale.AlertDialog(
                        onDismissRequest = { welcomeNotConfiguredDialog = false },
                        title = { androidx.compose.material3.Text("Drive Sync isn't set up yet") },
                        text = {
                            androidx.compose.material3.Text(
                                "This AerioTV build doesn't have a Google Cloud OAuth Web " +
                                    "Client ID baked in. Add GOOGLE_DRIVE_WEB_CLIENT_ID to " +
                                    "local.properties (and register this APK's signing-cert " +
                                    "SHA-1 in the same Cloud project) before Sign in with " +
                                    "Google can load.",
                            )
                        },
                        confirmButton = {
                            com.aeriotv.android.ui.AerioTextButton(
                                onClick = { welcomeNotConfiguredDialog = false },
                            ) { androidx.compose.material3.Text("Got it") }
                        },
                        containerColor = MaterialTheme.colorScheme.surface,
                    )
                }
            }

            composable(Routes.CHOOSE_TYPE) { entry ->
                val parent = remember(entry) {
                    navController.getBackStackEntry(Routes.PLAYLIST_GRAPH)
                }
                val vm: PlaylistViewModel = hiltViewModel(parent)
                ChooseSourceTypeScreen(
                    onBack = { navController.popBackStack() },
                    onChoose = { type ->
                        // Start a FRESH draft so the add creates a NEW row and
                        // never edits the active playlist (and so the form can't
                        // carry over the active server's API key).
                        vm.startNewSource(type)
                        navController.navigate(Routes.configure(type))
                    },
                )
            }

            composable(
                route = Routes.CONFIGURE,
                arguments = listOf(navArgument("type") { type = NavType.StringType }),
            ) { entry ->
                val parent = remember(entry) {
                    navController.getBackStackEntry(Routes.PLAYLIST_GRAPH)
                }
                val vm: PlaylistViewModel = hiltViewModel(parent)
                val state by vm.state.collectAsStateWithLifecycle()
                val typeName = entry.arguments?.getString("type") ?: SourceType.M3uUrl.name
                val resolvedType = runCatching { SourceType.valueOf(typeName) }
                    .getOrElse { SourceType.M3uUrl }

                LaunchedEffect(Unit) {
                    // Navigate on a one-shot "configured" EVENT, not on
                    // phase == ChannelsReady: when adding a second playlist the
                    // phase is already ChannelsReady, so a phase-watcher never
                    // re-fires and the add silently succeeds with no advance.
                    vm.sourceConfigured.collect {
                        navController.navigate(Routes.MAIN) {
                            popUpTo(Routes.PLAYLIST_GRAPH) { inclusive = false }
                        }
                    }
                }

                ConfigureSourceScreen(
                    sourceType = resolvedType,
                    onBack = { navController.popBackStack() },
                    viewModel = vm,
                )
            }

            composable(Routes.MAIN) { entry ->
                val parent = remember(entry) {
                    navController.getBackStackEntry(Routes.PLAYLIST_GRAPH)
                }
                val vm: PlaylistViewModel = hiltViewModel(parent)
                val state by vm.state.collectAsStateWithLifecycle()
                // Capability gates read the LIVE active row: the UiState snapshot
                // predates the probe that writes the permissions (2026-10-05).
                val livePlaylist by vm.activePlaylistLive.collectAsStateWithLifecycle(initialValue = null)
                val gatePlaylist = livePlaylist ?: state.playlist
                val context = androidx.compose.ui.platform.LocalContext.current
                // Remote Control: optional start-in-mini tune target for the
                // Live TV tab's channel taps (Settings > Remote Control).
                val tuneSettingsVm: com.aeriotv.android.feature.settings.SettingsViewModel =
                    hiltViewModel()
                val tuneStartsInMini by tuneSettingsVm.guideTuneInMini
                    .collectAsStateWithLifecycle(initialValue = false)
                // Settings > Player > Radio Mode by Default, mirrored for the
                // synchronous pick decision in RadioSelect.maybeOpen.
                LaunchedEffect(tuneSettingsVm) {
                    tuneSettingsVm.radioModeByDefault.collect {
                        com.aeriotv.android.feature.player.RadioSelect.byDefault = it
                    }
                }
                val playerEntryNav = remember {
                    dagger.hilt.android.EntryPointAccessors.fromApplication(
                        context.applicationContext,
                        com.aeriotv.android.feature.player.PlayerScreenEntryPoint::class.java,
                    )
                }
                val castSenderNav = remember { playerEntryNav.castSender() }
                val castStateNav by castSenderNav.state.collectAsStateWithLifecycle()
                // Task #226: direct-to-mini tune needs the app-scoped player
                // singletons + the mini session right here at the tap site.
                val exoHolderNav = remember { playerEntryNav.exoPlayerHolder() }
                val exoWindowNav = remember { playerEntryNav.exoWindowState() }
                val miniVmNav: MiniPlayerViewModel = hiltViewModel()
                // Catalog lookup for the play-where prompt's movie title.
                val onDemandWhereVm: com.aeriotv.android.feature.ondemand.OnDemandViewModel =
                    hiltViewModel(parent)

                LaunchedEffect(state.phase) {
                    // Skipped onboarding stays in the (empty) app; see
                    // PlaylistViewModel.onboardingSkipped.
                    if (state.phase == PlaylistViewModel.Phase.NeedsUrl && !vm.onboardingSkipped) {
                        navController.navigate(Routes.WELCOME) {
                            popUpTo(Routes.MAIN) { inclusive = true }
                        }
                    }
                }

                // Deep-link consumption moved to AerioTVNavHost scope (see the
                // hoisted block above MainScaffold's NavHost): inside this MAIN
                // composable it was NOT running while the player / VOD routes
                // were on top, so companion/cast channel flips queued until the
                // user pressed Back (Streamer device test 2026-07-15).

                // Task #148 milestone B: routing decision for catch-up
                // (TV = unified live player, phone = recording player).
                val isTvDevice = com.aeriotv.android.ui.settings.rememberIsTvDevice()
                // Per-user capabilities from the active playlist's Dispatcharr
                // snapshot. `?: true` / PERMISSIVE on a null playlist is
                // deliberate: the row simply has not loaded yet, and an
                // unmeasured account must never have affordances hidden.
                CompositionLocalProvider(
                    LocalCapabilities provides
                        (gatePlaylist?.capabilities() ?: CapabilitySet.UNKNOWN),
                    LocalCanRecordToServer provides (gatePlaylist?.canRecordToServer() ?: true),
                    LocalDvrAccess provides (gatePlaylist?.dispatcharrEffectiveDvrAccess() ?: "manage"),
                    // One ViewModel set for the whole main destination (Streamer
                    // 2026-09-03): the tabs' default hiltViewModel() resolved
                    // against THIS entry while the scaffold and the player use the
                    // graph entry, so the app ran TWO PlaylistViewModels, each
                    // parsing the EPG and rebuilding the guide catalog (two
                    // "bootstrap" lines per launch, minutes of EpgWork CPU).
                    androidx.lifecycle.viewmodel.compose.LocalViewModelStoreOwner provides parent,
                ) {
                // One channel play path. forceLocal=false is the original
                // behavior (companion, then cast, then local); true is
                // PlayWhereRouter's Play Here.
                com.aeriotv.android.feature.player.RadioMode.headersProvider =
                    { PlaybackHeaders.forPlaylist(state.playlist) }
                com.aeriotv.android.feature.player.RadioMode.neighborProvider = { cur, delta ->
                    val list = state.channels.filter { it.url.isNotBlank() }
                    val i = list.indexOfFirst { it.id == cur.id }
                    if (i < 0 || list.isEmpty()) null else list[(i + delta).mod(list.size)]
                }
                val channelPlay: (M3UChannel, Boolean) -> Unit = channelPlay@{ channel, forceLocal ->
                    // Radio Mode (Android#127): a channel pick switches the
                    // audio and never opens the video player.
                    if (com.aeriotv.android.feature.player.RadioMode.isActive && channel.url.isNotBlank() &&
                        castSenderNav.state.value !is com.aeriotv.android.core.cast.AerioCastSender.State.Connected
                    ) {
                        com.aeriotv.android.feature.player.RadioMode.switchTo(
                            navHostContext,
                            channel,
                            PlaybackHeaders.forPlaylist(state.playlist),
                            state.epgByChannel[channel.guideMatchKey]?.nowPlaying()?.title.orEmpty(),
                        )
                        tuneSettingsVm.setLastWatchedChannelId(channel.id)
                        tuneSettingsVm.recordRecentChannel(channel.id)
                        return@channelPlay
                    }
                    // Cast card UX rule 5 (Logan 2026-09-12): while a session
                    // is active a channel tap CASTS it and stays on the page.
                    // No player, no controls screen; the cast card above the
                    // tab bar is the one control surface (tap it for the
                    // remote sheet).
                    // forceLocal = Play Here from PlayWhereRouter: play on
                    // this device exactly as if no session existed.
                    val castDevice = if (forceLocal) null else (castSenderNav.state.value as? com.aeriotv.android.core.cast.AerioCastSender.State.Connected)
                        ?.let { it.deviceName?.takeIf { n -> n.isNotBlank() } ?: "TV" }
                    // Casting rework P1: the URL now feeds the phone-local
                    // HLS proxy's ingest, which must present the same
                    // Dispatcharr identity headers the player would (same
                    // header recipe as the mini-tune block below).
                    val castTuneHeaders = PlaybackHeaders.forPlaylist(state.playlist)
                    // Same rule for the companion transport (this phone
                    // driving an AerioTV TV over the LAN).
                    if (!forceLocal && companionTvName != null) {
                        companionRemoteNav.setRemoteChannel(channel.id, channel.name)
                        toastPlayingOnTv()
                        return@channelPlay
                    }
                    if (castDevice != null &&
                        castSenderNav.tuneLiveChannel(
                            channelId = channel.id,
                            title = channel.name,
                            artUri = channel.tvgLogo.takeIf { it.isNotBlank() },
                            localUrl = channel.url,
                            headers = castTuneHeaders,
                        )
                    ) {
                        android.widget.Toast.makeText(
                            navHostContext,
                            "Playing on $castDevice",
                            android.widget.Toast.LENGTH_SHORT,
                        ).show()
                        return@channelPlay
                    }
                    // Task #226 (TiviMate flow, Logan 2026-08-06): with
                    // "Play Channels In: Mini player" on TV, the first OK
                    // tunes DIRECTLY into the corner mini. Routing through
                    // the PLAYER destination just to demote it composed the
                    // fullscreen player for ~400ms (black frame + info-card
                    // flash over the vanished guide) and then a black mini
                    // while the pop settled. The app-scoped holder + the
                    // persistent window need no screen at all: prime the
                    // stream, flip the window to Mini, activate the session
                    // -- the guide never leaves composition and grid focus
                    // stays put. Remote sessions (cast/companion) and
                    // blank-URL event channels still take the route below
                    // (PlayerScreen owns their messaging). Second OK on the
                    // same program promotes via the guide's requestResume.
                    // Phone floating mini (iPhone parity, Logan 2026-09-14):
                    // while the mini window is up, a channel tap anywhere
                    // (guide, list, favorites, home rows, Keep Recent
                    // Channels Live dialog) re-tunes the SAME window through
                    // this block and stays minimized; tapping the mini
                    // expands. TV keeps its Remote Control setting gate.
                    // An on-demand mini (PhoneVodMini.kt) counts too: the
                    // channel replaces it in the same window.
                    val phoneMiniUp = !isTvDevice &&
                        exoWindowNav.mode.value ==
                        com.aeriotv.android.feature.player.ExoWindowState.Mode.Mini &&
                        (miniVmNav.state.value is MiniPlayerSession.State.Active ||
                            com.aeriotv.android.feature.player.PhoneVodMini.isActive)
                    if (((tuneStartsInMini && isTvDevice) || phoneMiniUp) &&
                        castDevice == null && (forceLocal || companionTvName == null) &&
                        channel.url.isNotBlank()
                    ) {
                        if (!isTvDevice) {
                            com.aeriotv.android.feature.player.PhoneVodMini.close()
                        }
                        exoHolderNav.httpHeaders = PlaybackHeaders.forPlaylist(state.playlist)
                        // Same fresh-tune guard as PlayerScreen's prime
                        // effect (GH #22): re-prime on a genuine channel
                        // change OR a holder that went idle; a tap on the
                        // channel already decoding in the mini only
                        // re-activates the session.
                        if (exoHolderNav.currentChannelId != channel.id ||
                            exoHolderNav.isIdle()
                        ) {
                            // Trace: the guide's select press is the
                            // start of this tune's press->firstFrame.
                            exoHolderNav.markTunePress(channel.name)
                            exoHolderNav.playUrl(
                                url = channel.url,
                                title = channel.name,
                                subtitle = state.epgByChannel[channel.guideMatchKey]
                                    ?.nowPlaying()?.title.orEmpty(),
                                artworkUri = channel.tvgLogo
                                    .takeIf { it.isNotBlank() }
                                    ?.let {
                                        runCatching { Uri.parse(it) }.getOrNull()
                                    },
                                drmLicenseType = channel.drmLicenseType,
                                drmLicenseKey = channel.drmLicenseKey,
                                channelId = channel.id,
                            )
                            exoHolderNav.currentChannelId = channel.id
                            exoWindowNav.recordTune(channel.id)
                        }
                        exoWindowNav.requestMini()
                        com.aeriotv.android.core.playback.AerioMediaPlaybackService
                            .startBackground(context)
                        tuneSettingsVm.setLastWatchedChannelId(channel.id)
                        tuneSettingsVm.recordRecentChannel(channel.id)
                        miniVmNav.setCurrentChannel(channel)
                        miniVmNav.showMiniPlayer()
                        return@channelPlay
                    }
                    // No remote session: play it here. (A session connecting
                    // while this player is open mirrors the channel to the
                    // other screen and then closes the player.)
                    // launchSingleTop: a rapid double-tap (e.g. of a mini
                    // controller card) can't stack two identical player
                    // destinations on the back stack.
                    navController.navigate(
                        Routes.player(channel.id, mini = tuneStartsInMini),
                    ) {
                        launchSingleTop = true
                    }
                }
                MainScaffold(
                    onChannelClick = { channel ->
                        // Cast play-where prompt: with a Google Cast session
                        // active, ask Play Here / Play on <receiver>. The
                        // companion link keeps its direct behavior.
                        // Read the session LIVE at tap time, not the
                        // composition-time castNameNav: a row's memoized tap
                        // lambda could hold a pre-session (or null-name)
                        // value, so a plain tap went straight to the local
                        // path, which closes itself while casting, while the
                        // freshly built menu Watch prompted (device pass
                        // cc2c37c7). A Connected session with no device name
                        // still prompts (the router names it "TV").
                        val liveCast = castSenderNav.state.value as?
                            com.aeriotv.android.core.cast.AerioCastSender.State.Connected
                        // A server-declared radio channel opens Radio Mode
                        // (same entry as the long-press item). Casting, the
                        // companion link, a Multiview, and the menu's Watch
                        // keep today's path.
                        if (liveCast == null && companionTvName == null &&
                            com.aeriotv.android.feature.player.RadioSelect.maybeOpen(
                                navHostContext,
                                channel,
                                state.epgByChannel[channel.guideMatchKey]?.nowPlaying()?.title.orEmpty(),
                            ) { miniVmNav.dismiss() }
                        ) {
                            tuneSettingsVm.setLastWatchedChannelId(channel.id)
                            tuneSettingsVm.recordRecentChannel(channel.id)
                            return@MainScaffold
                        }
                        android.util.Log.i(
                            "AerioCast",
                            "CastPlayWhere: channel tap ${channel.name} session=${liveCast != null} companion=${companionTvName != null}",
                        )
                        if (companionTvName != null || liveCast == null) {
                            channelPlay(channel, false)
                        } else {
                            com.aeriotv.android.feature.main.PlayWhereRouter.route(
                                sender = castSenderNav,
                                title = channel.name,
                                playHere = { channelPlay(channel, true) },
                                playOnReceiver = { channelPlay(channel, false) },
                            )
                        }
                    },
                    // Cast card flips / Switch and the Change Cast Device
                    // handoff already target the receiver: no prompt.
                    onCastChannel = { channel -> channelPlay(channel, false) },
                    // Expanding the local mini stays local.
                    onChannelResumeLocal = { channel -> channelPlay(channel, true) },
                    onMovieClick = { movieUuid ->
                        navController.navigate(Routes.movieDetail(movieUuid))
                    },
                    onSeriesClick = { seriesId ->
                        navController.navigate(Routes.seriesDetail(seriesId))
                    },
                    onEpisodeResume = { videoId ->
                        if (companionTvName != null) {
                            companionRemoteNav.playVod(videoId, isEpisode = true)
                            toastPlayingOnTv()
                        } else {
                            playVodWhere(videoId, null) {
                                navController.navigate(Routes.vodEpisodePlayer(videoId))
                            }
                        }
                    },
                    // Hero "Play from Beginning": start at 0 without deleting
                    // the Continue Watching row. The companion-TV branch has no
                    // start-at flag on the wire and plays as usual.
                    onEpisodeResumeFromStart = { videoId ->
                        if (companionTvName != null) {
                            companionRemoteNav.playVod(videoId, isEpisode = true)
                            toastPlayingOnTv()
                        } else {
                            playVodWhere(videoId, null) {
                                navController.navigate(Routes.vodEpisodePlayer(videoId, fromStart = true))
                            }
                        }
                    },
                    // #9: resume an in-progress movie from Continue Watching by
                    // opening its detail (which offers the Resume button).
                    onResumeMovie = { videoId ->
                        navController.navigate(Routes.movieDetail(videoId))
                    },
                    // Media center hero: Resume / Play go straight to the player
                    // (Apple parity); the player seeks to the saved position.
                    onPlayMovie = { videoId ->
                        if (companionTvName != null) {
                            companionRemoteNav.playVod(videoId, isEpisode = false)
                            toastPlayingOnTv()
                        } else {
                            playVodWhere(videoId, onDemandWhereVm) {
                                navController.navigate(Routes.vodPlayer(videoId))
                            }
                        }
                    },
                    // See onEpisodeResumeFromStart above.
                    onPlayMovieFromStart = { videoId ->
                        if (companionTvName != null) {
                            companionRemoteNav.playVod(videoId, isEpisode = false)
                            toastPlayingOnTv()
                        } else {
                            playVodWhere(videoId, onDemandWhereVm) {
                                navController.navigate(Routes.vodPlayer(videoId, fromStart = true))
                            }
                        }
                    },
                    onPlayRecording = { playbackUrl, title, recId ->
                        // Only http(s) recordings can play on the TV; a LOCAL
                        // recording (file://, content://) lives on THIS phone and
                        // the TV can't resolve it -- play those locally even when
                        // companion-connected (review 2026-07-15).
                        if (companionTvName != null && playbackUrl.startsWith("http")) {
                            companionRemoteNav.playRecording(playbackUrl, title)
                            toastPlayingOnTv()
                        } else {
                            playOnDemandWhere(title) {
                                navController.navigate(
                                    Routes.recordingPlayer(playbackUrl, title, recId = recId),
                                )
                            }
                        }
                    },
                    onPlayCatchup = { catchupChannelId, playbackUrl, title, progStart, progEnd, panelTz, channelUuid ->
                        // Task #148 milestone B: TV plays catch-up INSIDE the
                        // live PlayerScreen (unified transport + shared d-pad
                        // scrub, tvOS parity); phone keeps the seekable
                        // recording player (iPhone parity).
                        if (isTvDevice) {
                            navController.navigate(
                                Routes.playerCatchup(
                                    catchupChannelId, playbackUrl, title,
                                    csStart = progStart, csEnd = progEnd,
                                    csTz = panelTz, csUuid = channelUuid,
                                ),
                            )
                        } else {
                            playOnDemandWhere(title) {
                                navController.navigate(
                                    Routes.recordingPlayer(
                                        playbackUrl, title,
                                        csStart = progStart, csEnd = progEnd, csTz = panelTz,
                                        csUuid = channelUuid, csChannel = catchupChannelId,
                                    ),
                                )
                            }
                        }
                    },
                    onLaunchMultiview = {
                        // Tile spin-up takes seconds on real hardware, inviting
                        // a second OK press; singleTop keeps a double-activation
                        // from stacking two MULTIVIEW entries (first BACK would
                        // then pop the duplicate and "do nothing").
                        navController.navigate(Routes.MULTIVIEW) {
                            launchSingleTop = true
                        }
                    },
                    onWatchLive = { recordingUrl, recTitle, recIsDvr, recEnd, recChannelId ->
                        // Audit #50 / iOS v1.6.22: watch the in-progress server
                        // recording at the LIVE EDGE via the recording player
                        // (X-API-Key headers).
                        if (recordingUrl.isNotBlank()) playOnDemandWhere(recTitle) {
                            navController.navigate(
                                Routes.recordingPlayer(
                                    recordingUrl, recTitle, isDvr = recIsDvr, fromStart = false,
                                    recEnd = recEnd, recChannelId = recChannelId ?: -1,
                                )
                            )
                        }
                    },
                    onWatchFromBeginning = { recordingUrl, recTitle, recIsDvr, recEnd, recChannelId, autoResume ->
                        // iOS Issue #29 'Watch from Beginning' - and, with
                        // autoResume (row tap), iOS 2026-08-28 tap semantics:
                        // resume saved progress, else beginning.
                        if (recordingUrl.isNotBlank()) playOnDemandWhere(recTitle) {
                            navController.navigate(
                                Routes.recordingPlayer(
                                    recordingUrl, recTitle, isDvr = recIsDvr,
                                    fromStart = !autoResume, autoResume = autoResume,
                                    recEnd = recEnd, recChannelId = recChannelId ?: -1,
                                )
                            )
                        }
                    },
                    // Cold-launch perf fix (2026-06-05): pass the
                    // PLAYLIST_GRAPH-scoped vm so MainScaffold's default
                    // `hiltViewModel()` doesn't create a SECOND
                    // PlaylistViewModel instance scoped to the MAIN entry.
                    // Two instances each ran init -> bootstrap -> EPG
                    // cache paint + a duplicate xmltv.php fetch, costing
                    // ~700MB of GC churn and ~7 seconds of duplicated
                    // work on cold launch (seen in the method trace).
                    viewModel = vm,
                    onOpenSearch = { navController.navigate(Routes.search(fromPlayer = false)) },
                )
                }
            }

            composable(
                route = Routes.PLAYER,
                arguments = listOf(
                    navArgument("channelId") { type = NavType.StringType },
                    // Task #148 milestone B: optional catch-up context (TV).
                    navArgument("csUrl") { type = NavType.StringType; defaultValue = "" },
                    navArgument("csTitle") { type = NavType.StringType; defaultValue = "" },
                    navArgument("csStart") { type = NavType.LongType; defaultValue = 0L },
                    navArgument("csEnd") { type = NavType.LongType; defaultValue = 0L },
                    navArgument("csTz") { type = NavType.StringType; defaultValue = "" },
                    navArgument("csUuid") { type = NavType.StringType; defaultValue = "" },
                    // Remote Control: start-in-mini tune target (see Routes.player).
                    navArgument("mini") { type = NavType.BoolType; defaultValue = false },
                ),
            ) { entry ->
                // Another player takes over: a Multiview in the background ends.
                remember { com.aeriotv.android.feature.multiview.MultiviewBackground.stop() }
                val parent = remember(entry) {
                    navController.getBackStackEntry(Routes.PLAYLIST_GRAPH)
                }
                val vm: PlaylistViewModel = hiltViewModel(parent)
                val state by vm.state.collectAsStateWithLifecycle()
                // Capability gates read the LIVE active row: the UiState snapshot
                // predates the probe that writes the permissions (2026-10-05).
                val livePlaylist by vm.activePlaylistLive.collectAsStateWithLifecycle(initialValue = null)
                val gatePlaylist = livePlaylist ?: state.playlist
                val channelId = Uri.decode(entry.arguments?.getString("channelId").orEmpty())
                // Task #148 milestone B: catch-up context (blank/0 = live).
                val csUrl = Uri.decode(entry.arguments?.getString("csUrl").orEmpty())
                val csTitle = Uri.decode(entry.arguments?.getString("csTitle").orEmpty())
                val csStart = entry.arguments?.getLong("csStart") ?: 0L
                val csEnd = entry.arguments?.getLong("csEnd") ?: 0L
                val csTz = Uri.decode(entry.arguments?.getString("csTz").orEmpty())
                val csUuid = Uri.decode(entry.arguments?.getString("csUuid").orEmpty())
                val headers = remember(
                    state.playlist?.apiKey,
                    state.playlist?.sourceType,
                    state.playlist?.customUserAgent,
                ) { PlaybackHeaders.forPlaylist(state.playlist) }
                // UNFILTERED on purpose: dropping blank-url channels here made the
                // id lookup miss for event channels whose stream is not assigned
                // yet, and the old coerce-to-0 then played channels[0]. PlayerScreen
                // resolves by id against the same list the guide shows; its playUrl
                // effect already no-ops on a blank url.
                val playableChannels = state.channels
                CompositionLocalProvider(
                    LocalCapabilities provides
                        (gatePlaylist?.capabilities() ?: CapabilitySet.UNKNOWN),
                    LocalCanRecordToServer provides (gatePlaylist?.canRecordToServer() ?: true),
                    // Switch Stream: change_stream is still IsAdmin server-side,
                    // but the gate now runs through Capability.CanSwitchStream.
                    LocalIsDispatcharrAdmin provides (gatePlaylist?.canSwitchStream() ?: false),
                ) {
                PlayerScreen(
                    channels = playableChannels,
                    initialChannelId = channelId,
                    isLive = true,
                    httpHeaders = headers,
                    epgByChannel = state.epgByChannel,
                    catchupUrl = csUrl,
                    catchupTitle = csTitle,
                    catchupStartMillis = csStart,
                    catchupEndMillis = csEnd,
                    catchupTz = csTz,
                    catchupChannelUuid = csUuid,
                    onRemintCatchup = { uuid, currentUrl, absStartMillis ->
                        // Task #183: csEnd rides along so the re-mint asks the
                        // provider for only the REMAINING programme length.
                        vm.remintCatchupSession(uuid, currentUrl, absStartMillis, csEnd)
                    },
                    onRevokeCatchup = { url -> vm.revokeCatchupSession(url) },
                    onReportCatchupPosition = { url, secs, paused ->
                        vm.reportCatchupPosition(url, secs, paused)
                    },
                    onClose = { navController.popBackStack() },
                    onLaunchMultiview = {
                        // The now-playing stream is being absorbed into the
                        // multiview grid (PlayerScreen already stopped it), so
                        // pop PLAYER off the stack -- no dead single-stream
                        // route to return to. Back from multiview lands on MAIN.
                        navController.navigate(Routes.MULTIVIEW) {
                            popUpTo(Routes.PLAYER) { inclusive = true }
                            launchSingleTop = true
                        }
                    },
                    // Remote Control hold-Down: the player has already minimized
                    // itself to the corner mini (and popped via onClose), so the
                    // search route lands over MAIN with live video still playing.
                    onOpenSearch = {
                        navController.navigate(Routes.search(fromPlayer = true)) {
                            launchSingleTop = true
                        }
                    },
                    // Left-press Channels overlay seeds from the guide's active
                    // group ("previously selected group").
                    initialGroup = state.selectedGroup,
                    startInMini = entry.arguments?.getBoolean("mini") == true,
                    // Player Options > Switch Stream (Dispatcharr Direct Connect):
                    // list the channel's member streams + their quality, then ask
                    // Dispatcharr to switch the active upstream.
                    onLoadChannelStreams = { channelIntPk ->
                        // Resolve each stream's m3u_account id -> source name so the
                        // sheet shows which M3U each alternate comes from (most users
                        // keep several). One small accounts fetch per sheet open.
                        val m3uNames = vm.loadM3uAccountNames()
                        vm.loadChannelStreams(channelIntPk).map { s ->
                            com.aeriotv.android.feature.player.StreamOption(
                                id = s.id,
                                name = s.name.orEmpty(),
                                resolution = s.resolution,
                                fps = s.sourceFps,
                                bitrateKbps = s.outputBitrateKbps,
                                videoCodec = s.videoCodec,
                                audioCodec = s.audioCodec,
                                sourceName = s.m3uAccount?.let { m3uNames[it] },
                            )
                        }
                    },
                    onSwitchChannelStream = { channelUuid, streamId ->
                        vm.switchChannelStream(channelUuid, streamId).getOrThrow()
                    },
                    onSaveChannelStreamOrder = { channelIntPk, streamIds ->
                        vm.saveChannelStreamOrder(channelIntPk, streamIds).getOrThrow()
                    },
                    onRecheckSwitchStreamAllowed = { trigger ->
                        vm.recheckSwitchStreamAllowed(trigger)
                    },
                    onLoadCurrentStreamId = { channelUuid ->
                        vm.loadCurrentStreamId(channelUuid)
                    },
                    onLoadCurrentStreamUrl = { channelUuid ->
                        vm.loadCurrentStreamUrl(channelUuid)
                    },
                    onVerdictFlips = vm.lanVerdictFlips,
                    onRebuildLiveUrl = { channelUuid -> vm.rebuildLiveStreamUrl(channelUuid) },
                )
                }
            }

            composable(
                route = Routes.SERIES_DETAIL,
                arguments = listOf(navArgument("seriesId") { type = NavType.IntType }),
            ) { entry ->
                // Scope OnDemandViewModel to the PLAYLIST_GRAPH entry: the MAIN
                // destination provides that entry as the tabs' ViewModelStoreOwner
                // (Streamer 2026-09-03, one PlaylistViewModel for the whole main
                // screen), so it is where the Movies / TV Shows / On Demand tabs
                // populated the library. Resolving against MAIN (the old choice,
                // from before that change) handed back a SECOND, empty instance
                // and the detail opened to "not found" until that instance's
                // deferred snapshot restore caught up (phone 2026-09-09).
                val mainEntry = remember(entry) {
                    navController.getBackStackEntry(Routes.PLAYLIST_GRAPH)
                }
                val onDemandVm: OnDemandViewModel = hiltViewModel(mainEntry)
                val seriesId = entry.arguments?.getInt("seriesId") ?: 0
                SeriesDetailScreen(
                    seriesId = seriesId,
                    onBack = { navController.popBackStack() },
                    // fromStart comes from the detail page's "Play from
                    // Beginning" and rides the existing route arg; the
                    // Continue Watching row is left intact.
                    onEpisodeClick = { episode, fromStart ->
                        if (companionTvName != null) {
                            companionRemoteNav.playVod(episode.uuid, isEpisode = true, title = episode.title)
                            toastPlayingOnTv()
                        } else {
                            playOnDemandWhere(episode.title.orEmpty()) {
                                navController.navigate(Routes.vodEpisodePlayer(episode.uuid, fromStart = fromStart))
                            }
                        }
                    },
                    // Known For tile in the cast bio dialog: a PLAIN push (no
                    // popUpTo / singleTop) so remote BACK pops the new detail
                    // entry and lands back on this title.
                    onOpenMovie = { uuid -> navController.navigate(Routes.movieDetail(uuid)) },
                    onOpenSeries = { id -> navController.navigate(Routes.seriesDetail(id)) },
                    viewModel = onDemandVm,
                )
            }

            composable(
                route = Routes.MOVIE_DETAIL,
                arguments = listOf(navArgument("movieUuid") { type = NavType.StringType }),
            ) { entry ->
                // Same owner as SERIES_DETAIL above: the graph entry the tabs use.
                val mainEntry = remember(entry) {
                    navController.getBackStackEntry(Routes.PLAYLIST_GRAPH)
                }
                val onDemandVm: OnDemandViewModel = hiltViewModel(mainEntry)
                val movieUuid = Uri.decode(entry.arguments?.getString("movieUuid").orEmpty())
                com.aeriotv.android.feature.ondemand.MovieDetailScreen(
                    movieUuid = movieUuid,
                    onBack = { navController.popBackStack() },
                    onPlay = { fromStart ->
                        if (companionTvName != null) {
                            companionRemoteNav.playVod(movieUuid, isEpisode = false)
                            toastPlayingOnTv()
                        } else {
                            playVodWhere(movieUuid, onDemandVm) {
                                navController.navigate(Routes.vodPlayer(movieUuid, fromStart = fromStart))
                            }
                        }
                    },
                    // Same plain Known For push as SERIES_DETAIL above.
                    onOpenMovie = { uuid -> navController.navigate(Routes.movieDetail(uuid)) },
                    onOpenSeries = { id -> navController.navigate(Routes.seriesDetail(id)) },
                    viewModel = onDemandVm,
                )
            }

            composable(
                route = Routes.VOD_EPISODE_PLAYER,
                arguments = listOf(
                    navArgument("episodeUuid") { type = NavType.StringType },
                    navArgument("fromStart") { type = NavType.BoolType; defaultValue = false },
                ),
            ) { entry ->
                // Another player takes over: a Multiview in the background ends.
                remember { com.aeriotv.android.feature.multiview.MultiviewBackground.stop() }
                val parent = remember(entry) {
                    navController.getBackStackEntry(Routes.PLAYLIST_GRAPH)
                }
                val playlistVm: PlaylistViewModel = hiltViewModel(parent)
                val playlistState by playlistVm.state.collectAsStateWithLifecycle()
                // Share the MAIN-scoped OnDemand VM when it is on the stack so
                // the episode cache AND the series' pinned Version selection
                // carry into this route (see the VOD_PLAYER route below).
                val vodMainEntry = remember(entry) {
                    runCatching { navController.getBackStackEntry(Routes.PLAYLIST_GRAPH) }.getOrNull()
                }
                val onDemandVm: OnDemandViewModel = if (vodMainEntry != null) {
                    hiltViewModel(vodMainEntry)
                } else {
                    hiltViewModel()
                }

                // Silence any LIVE session before VOD starts. A companion VodPlay
                // deep link navigates player/... -> vod_episode_player/... directly
                // while the shared holder + persistent exo window are still live;
                // without this the live channel keeps streaming (and sounding)
                // under the movie (review 2026-07-15). Same teardown the
                // RECORDING_PLAYER route already does.
                tearDownLiveForVod(navController)

                val episodeUuid = Uri.decode(entry.arguments?.getString("episodeUuid").orEmpty())
                // Hero "Play from Beginning": skip the resume seek, keep the
                // saved WatchProgress row (tvOS MoviesView:1507-1511).
                val epFromStart = entry.arguments?.getBoolean("fromStart") ?: false

                val apiKey = playlistState.playlist?.apiKey
                val headers = remember(
                    playlistState.playlist?.apiKey,
                    playlistState.playlist?.sourceType,
                    playlistState.playlist?.customUserAgent,
                ) { PlaybackHeaders.forPlaylist(playlistState.playlist) }

                // Look up the episode across all cached series for stream-id +
                // title. Cache miss falls back to an untitled play.
                val episode = onDemandVm.state.collectAsStateWithLifecycle().value
                    .episodesBySeries.values
                    .asSequence()
                    .flatten()
                    .firstOrNull { it.uuid == episodeUuid }

                // Phone mini expand reuses the URL already playing (no new
                // session); null everywhere else, TV included.
                var resolved by remember(episodeUuid) {
                    mutableStateOf<OnDemandViewModel.ResolvedVod?>(
                        com.aeriotv.android.feature.player.PhoneVodMini.expandUrlFor(episodeUuid)
                            ?.let { OnDemandViewModel.ResolvedVod(it, authSafe = true) },
                    )
                }
                var resolveError by remember(episodeUuid) { mutableStateOf<String?>(null) }
                LaunchedEffect(episodeUuid) {
                    if (resolved != null) return@LaunchedEffect
                    onDemandVm.resolveEpisodeUrl(episodeUuid, episode?.firstStreamId).fold(
                        onSuccess = { resolved = it },
                        onFailure = { resolveError = it.message ?: it::class.simpleName },
                    )
                }

                // Series poster fallback for the episode (episodes don't carry
                // their own poster on the wire). Look up which series contains
                // this episode and reuse that show's poster. The same series id
                // keys the Version selection the player's Switch Version uses.
                val epOnDemandState = onDemandVm.state.collectAsStateWithLifecycle().value
                val parentSeriesId = epOnDemandState.episodesBySeries.entries
                    .firstOrNull { (_, list) -> list.any { it.uuid == episodeUuid } }
                    ?.key
                val parentSeriesPoster = parentSeriesId?.let { id ->
                    onDemandVm.seriesById(id)?.posterUrl
                }
                LaunchedEffect(parentSeriesId) {
                    parentSeriesId?.let { onDemandVm.loadSeriesProviders(it) }
                }
                // An in-player Switch Version persists its own choice; re-read
                // it when the player goes away so the series detail pill shows
                // the copy that actually played (movie route parity).
                DisposableEffect(parentSeriesId) {
                    val versionSeriesId = parentSeriesId
                    onDispose {
                        versionSeriesId?.let { onDemandVm.refreshSelectedSeriesVersion(it) }
                    }
                }
                val versionOptions = parentSeriesId
                    ?.let { epOnDemandState.seriesProviders[it] }.orEmpty()
                val selectedVersion = parentSeriesId
                    ?.let { epOnDemandState.selectedSeriesVersion[it] }

                // Progress identity for this episode (2026-09-11). The route
                // used to hand the player nothing but the uuid, so the saved
                // row was vodType "movie" with seriesId null: the hero label,
                // seriesTarget and Continue Watching all query by
                // vodType = 'episode' AND seriesId, and therefore never saw
                // it. Same up-next queue the series detail page builds (rest
                // of the series by season then episode, capped at 50).
                val epUpNextQueue = remember(parentSeriesId, episodeUuid, epOnDemandState.episodesBySeries) {
                    val ordered = parentSeriesId
                        ?.let { epOnDemandState.episodesBySeries[it] }
                        .orEmpty()
                        .sortedWith(compareBy({ it.seasonNumber ?: 0 }, { it.episodeNumber ?: Int.MAX_VALUE }))
                    val idx = ordered.indexOfFirst { it.uuid == episodeUuid }
                    if (idx < 0) {
                        null
                    } else {
                        com.aeriotv.android.feature.watchprogress.WatchProgressViewModel.encodeQueue(
                            ordered.drop(idx + 1).take(50).map {
                                com.aeriotv.android.feature.watchprogress.UpNextEntry(
                                    vodId = it.uuid,
                                    title = it.displayName,
                                    posterUrl = it.stillImageUrl,
                                    streamUrl = null, // re-resolved by uuid at play time
                                    seasonNumber = it.seasonNumber ?: 0,
                                    episodeNumber = it.episodeNumber ?: 0,
                                )
                            },
                        )
                    }
                }

                val epProgressMeta = remember(parentSeriesId, episode, epUpNextQueue) {
                    com.aeriotv.android.feature.player.VodProgressMeta(
                        vodType = "episode",
                        seriesId = parentSeriesId?.toString(),
                        seasonNumber = episode?.seasonNumber ?: 0,
                        episodeNumber = episode?.episodeNumber ?: 0,
                        upNextQueue = epUpNextQueue,
                    )
                }

                // Phone: Back / top swipe minimize to the floating mini.
                val epMiniToken = remember { com.aeriotv.android.feature.player.PhoneVodMiniRouteToken() }
                com.aeriotv.android.feature.player.PhoneVodMiniRoute(
                    info = resolved?.url?.let { url ->
                        com.aeriotv.android.feature.player.PhoneVodMini.Info(
                            key = url,
                            videoId = episodeUuid,
                            title = episode?.displayName ?: "Episode",
                            posterUrl = parentSeriesPoster,
                            meta = epProgressMeta,
                            isDvr = false,
                            reopenRoute = Routes.vodEpisodePlayer(episodeUuid, fromStart = false),
                        )
                    },
                    token = epMiniToken,
                    onPop = { navController.popBackStack() },
                )
                VODPlayerScreen(
                    streamUrl = resolved?.url.orEmpty(),
                    title = episode?.displayName ?: "Episode",
                    startFromBeginning = epFromStart,
                    progressMeta = epProgressMeta,
                    // Audit #53/#38: never replay the API key to a session URL
                    // that resolved OFF the server's origin.
                    httpHeaders = if (resolved?.authSafe == false) emptyMap() else headers,
                    onClose = { if (!epMiniToken.minimized) navController.popBackStack() },
                    loadingMessage = resolveError ?: if (resolved == null) "Loading…" else null,
                    videoId = episodeUuid,
                    posterUrl = parentSeriesPoster,
                    versionOptions = versionOptions,
                    selectedVersion = selectedVersion,
                    onSelectVersion = { option ->
                        // Episodes pin by m3u_account_id only (no per-copy
                        // stream id); resolveEpisodeUrl reads the selection.
                        parentSeriesId?.let { onDemandVm.selectSeriesVersion(it, option) }
                        onDemandVm.resolveEpisodeUrl(episodeUuid, episode?.firstStreamId)
                            .getOrNull()?.url
                    },
                )
            }

            composable(Routes.MULTIVIEW) { entry ->
                val parent = remember(entry) {
                    navController.getBackStackEntry(Routes.PLAYLIST_GRAPH)
                }
                val playlistVm: PlaylistViewModel = hiltViewModel(parent)
                val playlistState by playlistVm.state.collectAsStateWithLifecycle()
                val headers = remember(
                    playlistState.playlist?.apiKey,
                    playlistState.playlist?.sourceType,
                    playlistState.playlist?.customUserAgent,
                ) { PlaybackHeaders.forPlaylist(playlistState.playlist) }
                // Guide-banner entry skips PlayerScreen's launch teardown
                // (PlayerScreen.kt onLaunch), leaving the persistent mini
                // window + its decoder running on top of the tile grid.
                // Dismiss the mini here with the same teardown order.
                val mvMiniPlayerVm: MiniPlayerViewModel = hiltViewModel()
                val mvStoreVm: com.aeriotv.android.feature.multiview.MultiviewStoreHandleVm = hiltViewModel()
                val mvContext = androidx.compose.ui.platform.LocalContext.current
                // Apple parity (Logan 2026-10-11): a pile staged on the mini
                // player opens with that channel's player kept as tile 1, no
                // re-tune; the composition below must see the held id on its
                // first frame, so this runs in remember, not an effect.
                val mvHeld = remember(entry) {
                    val held = com.aeriotv.android.feature.multiview.MultiviewHeld
                        .begin(mvContext, mvStoreVm.takePlayingSeedForLaunch())
                    if (held) mvMiniPlayerVm.dismiss()
                    held
                }
                LaunchedEffect(Unit) {
                    if (mvHeld) return@LaunchedEffect
                    val mvEntry = dagger.hilt.android.EntryPointAccessors.fromApplication(
                        mvContext.applicationContext,
                        MainScaffoldEntryPoint::class.java,
                    )
                    mvMiniPlayerVm.dismiss()
                    mvEntry.exoWindowState().hide()
                    mvEntry.exoPlayerHolder().stop()
                    com.aeriotv.android.core.playback.AerioMediaPlaybackService
                        .stop(mvContext.applicationContext)
                }
                MultiviewScreen(
                    // Desktop repro 2026-08-05: multiview entered from the
                    // PLAYER used to pop back onto a player whose stream
                    // multiview had deliberately taken over - a black, dead
                    // screen. Both exit-dialog actions promise the guide, so
                    // land on the main scaffold no matter what pushed
                    // multiview (guide-staged entries pop the same way).
                    onClose = {
                        if (!navController.popBackStack(Routes.MAIN, false)) {
                            navController.popBackStack()
                        }
                    },
                    onPlaySingleChannel = { channelId ->
                        navController.navigate(Routes.player(channelId)) {
                            popUpTo(Routes.MULTIVIEW) { inclusive = true }
                        }
                    },
                    httpHeaders = headers,
                    // Pass the PLAYLIST_GRAPH-scoped VM so the re-entrant
                    // "Add streams" picker reuses this single instance.
                    playlistVm = playlistVm,
                )
            }

            // Global Search (parity task #41). Resolve the PLAYLIST_GRAPH-scoped
            // PlaylistViewModel so an EPG result reuses the same requestGuideJump
            // SharedFlow that MainScaffold + GuideScreen already collect (switch
            // to Live TV + guide mode + scroll/focus the cell); movie/series
            // results reuse the existing detail routes.
            composable(
                route = Routes.SEARCH,
                arguments = listOf(
                    navArgument("fromPlayer") {
                        type = NavType.BoolType
                        defaultValue = false
                    },
                ),
            ) { entry ->
                val parent = remember(entry) {
                    navController.getBackStackEntry(Routes.PLAYLIST_GRAPH)
                }
                val playlistVm: PlaylistViewModel = hiltViewModel(parent)
                val fromPlayer = entry.arguments?.getBoolean("fromPlayer") == true
                // Session singleton via a local VM handle: the NavHost-scoped
                // miniPlayerVm is declared after this builder, out of scope here.
                val miniVm: com.aeriotv.android.feature.miniplayer.MiniPlayerViewModel =
                    hiltViewModel()
                com.aeriotv.android.feature.search.SearchScreen(
                    onBack = {
                        navController.popBackStack()
                        // Hold-Down search came from the fullscreen player, which
                        // minimized itself to the corner mini on the way out. Back
                        // = return to watching: reuse the proven mini-resume flow
                        // (the NavController-scoped collector re-pushes PLAYER
                        // with the session's CURRENT channel). No-op if the mini
                        // was somehow dismissed - then Back lands on the tabs.
                        if (fromPlayer) miniVm.session.requestResume()
                    },
                    onEpgResult = { channelKey, startMillis ->
                        playlistVm.requestGuideJump(channelKey, startMillis)
                        navController.popBackStack()
                    },
                    onMovieClick = { uuid -> navController.navigate(Routes.movieDetail(uuid)) },
                    onSeriesClick = { id -> navController.navigate(Routes.seriesDetail(id)) },
                )
            }

            composable(
                route = Routes.VOD_PLAYER,
                arguments = listOf(
                    navArgument("movieUuid") { type = NavType.StringType },
                    navArgument("fromStart") { type = NavType.BoolType; defaultValue = false },
                ),
            ) { entry ->
                // Another player takes over: a Multiview in the background ends.
                remember { com.aeriotv.android.feature.multiview.MultiviewBackground.stop() }
                val parent = remember(entry) {
                    navController.getBackStackEntry(Routes.PLAYLIST_GRAPH)
                }
                val playlistVm: PlaylistViewModel = hiltViewModel(parent)
                val playlistState by playlistVm.state.collectAsStateWithLifecycle()
                // Share the MAIN-scoped OnDemand VM when it is on the stack
                // (normal detail -> player push) so the movie cache AND the
                // user's pinned Version selection carry into this route; a
                // deep-link entry without MAIN falls back to a fresh instance.
                val vodMainEntry = remember(entry) {
                    runCatching { navController.getBackStackEntry(Routes.PLAYLIST_GRAPH) }.getOrNull()
                }
                val onDemandVm: OnDemandViewModel = if (vodMainEntry != null) {
                    hiltViewModel(vodMainEntry)
                } else {
                    hiltViewModel()
                }
                val onDemandState by onDemandVm.state.collectAsStateWithLifecycle()

                // Silence any live session first (see the episode route above).
                tearDownLiveForVod(navController)

                val movieUuid = Uri.decode(entry.arguments?.getString("movieUuid").orEmpty())
                // See the episode route above.
                val movieFromStart = entry.arguments?.getBoolean("fromStart") ?: false
                // Catalog-backed lookup (GH #109); recomposes when the row lands.
                val movie = onDemandVm.movieByUuid(movieUuid)

                // Version switching: make sure the provider copies are loaded
                // for the in-player "Switch Version" sheet (idempotent; the
                // detail screen usually primed this already).
                LaunchedEffect(movie?.id) {
                    movie?.id?.let { onDemandVm.loadMovieProviders(it) }
                }
                val versionOptions = movie?.id?.let { onDemandState.movieProviders[it] }.orEmpty()
                val selectedVersion = movie?.id?.let { onDemandState.selectedMovieVersion[it] }
                // Pick up whatever this session measured when the player goes
                // away, so the detail screen's picker describes the copy that
                // just played even if this route ran on its own VM instance.
                // Same reason for the remembered pin: an in-player Switch
                // Version is re-read off disk so the detail pill agrees with
                // what actually played (iOS VODDetailView .onDisappear).
                DisposableEffect(movie?.id) {
                    val learnedMovieId = movie?.id
                    onDispose {
                        learnedMovieId?.let {
                            onDemandVm.refreshLearnedStreams(it)
                            onDemandVm.refreshSelectedMovieVersion(it)
                        }
                    }
                }

                val baseUrl = playlistState.playlist?.urlString.orEmpty()
                val apiKey = playlistState.playlist?.apiKey
                val headers = remember(
                    playlistState.playlist?.apiKey,
                    playlistState.playlist?.sourceType,
                    playlistState.playlist?.customUserAgent,
                ) { PlaybackHeaders.forPlaylist(playlistState.playlist) }

                // See the episode route: a phone mini expand reuses its URL.
                var resolved by remember(movieUuid) {
                    mutableStateOf<OnDemandViewModel.ResolvedVod?>(
                        com.aeriotv.android.feature.player.PhoneVodMini.expandUrlFor(movieUuid)
                            ?.let { OnDemandViewModel.ResolvedVod(it, authSafe = true) },
                    )
                }
                var resolveError by remember(movieUuid) { mutableStateOf<String?>(null) }
                LaunchedEffect(movieUuid) {
                    if (resolved != null) return@LaunchedEffect
                    onDemandVm.resolveMovieUrl(movieUuid).fold(
                        onSuccess = { resolved = it },
                        onFailure = { resolveError = it.message ?: it::class.simpleName },
                    )
                }

                // Phone: Back / top swipe minimize to the floating mini.
                val movieMiniToken = remember { com.aeriotv.android.feature.player.PhoneVodMiniRouteToken() }
                com.aeriotv.android.feature.player.PhoneVodMiniRoute(
                    info = resolved?.url?.let { url ->
                        com.aeriotv.android.feature.player.PhoneVodMini.Info(
                            key = url,
                            videoId = movieUuid,
                            title = movie?.displayName ?: "On Demand",
                            posterUrl = movie?.posterUrl,
                            meta = null,
                            isDvr = false,
                            reopenRoute = Routes.vodPlayer(movieUuid, fromStart = false),
                        )
                    },
                    token = movieMiniToken,
                    onPop = { navController.popBackStack() },
                )
                VODPlayerScreen(
                    streamUrl = resolved?.url.orEmpty(),
                    title = movie?.displayName ?: "On Demand",
                    startFromBeginning = movieFromStart,
                    // Audit #53/#38: never replay the API key to a session URL
                    // that resolved OFF the server's origin.
                    httpHeaders = if (resolved?.authSafe == false) emptyMap() else headers,
                    onClose = { if (!movieMiniToken.minimized) navController.popBackStack() },
                    loadingMessage = resolveError ?: if (resolved == null) "Loading…" else null,
                    videoId = movieUuid,
                    posterUrl = movie?.posterUrl,
                    versionOptions = versionOptions,
                    selectedVersion = selectedVersion,
                    onSelectVersion = { option ->
                        // Record the pin, then re-resolve: the proxy URL now
                        // carries the chosen relation's stream_id +
                        // m3u_account_id (or neither, for Auto).
                        movie?.id?.let { onDemandVm.selectMovieVersion(it, option) }
                        onDemandVm.resolveMovieUrl(movieUuid).getOrNull()?.url
                    },
                    // MOVIES ONLY (see the parameter's KDoc): the picker's
                    // option id is a provider RELATION pk here, which names one
                    // specific file. The episode route leaves this unwired.
                    onLearnStream = { relationId, stream ->
                        onDemandVm.recordLearnedStream(relationId, stream)
                    },
                )
            }

            // Audit task #43: local DVR recording playback. Takes a raw
            // file:// URL (from LocalRecordingEntity.filePath, encoded in
            // DvrViewModel.Recording.playbackUrl) + a display title.
            // VODPlayerScreen handles the file source natively via mpv;
            // no HTTP headers, no live cache window, no resolveMovieUrl.
            // Server-side recording playback is a follow-up phase.
            composable(
                route = Routes.RECORDING_PLAYER,
                arguments = listOf(
                    navArgument("playbackUrl") { type = NavType.StringType },
                    navArgument("title") { type = NavType.StringType },
                    navArgument("isDvr") { type = NavType.BoolType; defaultValue = false },
                    navArgument("fromStart") { type = NavType.BoolType; defaultValue = false },
                    navArgument("autoResume") { type = NavType.BoolType; defaultValue = false },
                    navArgument("recEnd") { type = NavType.LongType; defaultValue = 0L },
                    navArgument("recChannelId") { type = NavType.IntType; defaultValue = -1 },
                    navArgument("recId") { type = NavType.IntType; defaultValue = -1 },
                    navArgument("csStart") { type = NavType.LongType; defaultValue = 0L },
                    navArgument("csEnd") { type = NavType.LongType; defaultValue = 0L },
                    navArgument("csTz") { type = NavType.StringType; defaultValue = "" },
                    navArgument("csUuid") { type = NavType.StringType; defaultValue = "" },
                    navArgument("csChannel") { type = NavType.StringType; defaultValue = "" },
                ),
            ) { entry ->
                // Another player takes over: a Multiview in the background ends.
                remember { com.aeriotv.android.feature.multiview.MultiviewBackground.stop() }
                val playbackUrl = Uri.decode(entry.arguments?.getString("playbackUrl").orEmpty())
                val title = Uri.decode(entry.arguments?.getString("title").orEmpty())
                val isDvr = entry.arguments?.getBoolean("isDvr") ?: false
                val fromStart = entry.arguments?.getBoolean("fromStart") ?: false
                val autoResume = entry.arguments?.getBoolean("autoResume") ?: false
                val recEnd = entry.arguments?.getLong("recEnd") ?: 0L
                val recChannelId = entry.arguments?.getInt("recChannelId") ?: -1
                val recId = entry.arguments?.getInt("recId") ?: -1
                // A recording / catch-up playback must silence any LIVE session
                // first: entering from the guide's Watch action (or DVR tab)
                // skips PlayerScreen's launch teardown, so the persistent live
                // window + mini-player decoder would keep streaming (and
                // sounding) underneath. Same teardown order as the MULTIVIEW
                // route above.
                val rpMiniPlayerVm: MiniPlayerViewModel = hiltViewModel()
                val rpContext = androidx.compose.ui.platform.LocalContext.current
                LaunchedEffect(Unit) {
                    val rpEntry = dagger.hilt.android.EntryPointAccessors.fromApplication(
                        rpContext.applicationContext,
                        MainScaffoldEntryPoint::class.java,
                    )
                    // See tearDownLiveForVod: phone on-demand mini replaced.
                    com.aeriotv.android.feature.player.PhoneVodMini.closeForNewContent()
                    rpMiniPlayerVm.dismiss()
                    rpEntry.exoWindowState().hide()
                    rpEntry.exoPlayerHolder().stop()
                    com.aeriotv.android.core.playback.AerioMediaPlaybackService
                        .stop(rpContext.applicationContext)
                }
                val csStart = entry.arguments?.getLong("csStart") ?: 0L
                val csEnd = entry.arguments?.getLong("csEnd") ?: 0L
                val csTz = Uri.decode(entry.arguments?.getString("csTz").orEmpty())
                val csUuid = Uri.decode(entry.arguments?.getString("csUuid").orEmpty())
                val csChannel = Uri.decode(entry.arguments?.getString("csChannel").orEmpty())
                // A recording is either a local file:// capture (no auth) or a
                // Dispatcharr server URL that needs the active source's
                // X-API-Key. Resolve the playlist's auth headers like the VOD
                // route and apply them only to remote (http/https) URLs so a
                // file:// recording plays headerless.
                val parent = remember(entry) {
                    navController.getBackStackEntry(Routes.PLAYLIST_GRAPH)
                }
                val playlistVm: PlaylistViewModel = hiltViewModel(parent)
                val playlistState by playlistVm.state.collectAsStateWithLifecycle()
                val headers = remember(
                    playlistState.playlist?.apiKey,
                    playlistState.playlist?.sourceType,
                    playbackUrl,
                    playlistState.playlist?.customUserAgent,
                ) { PlaybackHeaders.forPlaylist(playlistState.playlist, playbackUrl) }
                // Finalize migration target (iOS parity): the /file/ twin of
                // an in-progress /hls/ URL, served with the same headers.
                val completedUrl = remember(playbackUrl) {
                    if (playbackUrl.endsWith("hls/index.m3u8")) {
                        playbackUrl.removeSuffix("hls/index.m3u8") + "file/"
                    } else null
                }
                // Continue on Live TV: resolve the recorded channel's guide id
                // from the dispatcharr numeric id; null closure when absent.
                val continueOnLive: (() -> Unit)? = if (recChannelId > 0) {
                    {
                        val liveId = playlistState.channels
                            .firstOrNull { it.dispatcharrChannelId == recChannelId }?.id
                        navController.popBackStack()
                        if (liveId != null) {
                            navController.navigate(Routes.player(liveId))
                        }
                    }
                } else null
                val recProgressMeta = remember { com.aeriotv.android.feature.player.VodProgressMeta("recording") }
                // Phone: Back / top swipe minimize to the floating mini. The
                // reopen route drops fromStart / autoResume: an expand adopts the
                // playing instance, so no start or resume handling may run.
                val recMiniToken = remember { com.aeriotv.android.feature.player.PhoneVodMiniRouteToken() }
                var recMvOpen by remember { mutableStateOf(false) }
                com.aeriotv.android.feature.player.PhoneVodMiniRoute(
                    info = remember(playbackUrl, title, csChannel, csStart) {
                        com.aeriotv.android.feature.player.PhoneVodMini.Info(
                            key = playbackUrl,
                            videoId = recordingProgressId(playbackUrl, recId),
                            title = title.ifBlank { "Recording" },
                            posterUrl = null,
                            meta = recProgressMeta,
                            isDvr = isDvr,
                            reopenRoute = Routes.recordingPlayer(
                                playbackUrl, title, isDvr = isDvr,
                                recEnd = recEnd, recChannelId = recChannelId, recId = recId,
                                csStart = csStart, csEnd = csEnd, csTz = csTz, csUuid = csUuid,
                                csChannel = csChannel,
                            ),
                            catchupChannelId = csChannel,
                            catchupStartMillis = csStart,
                            catchupDurationMs = (csEnd - csStart).coerceAtLeast(0L),
                        )
                    },
                    token = recMiniToken,
                    onPop = { navController.popBackStack() },
                )
                VODPlayerScreen(
                    streamUrl = playbackUrl,
                    title = title.ifBlank { "Recording" },
                    httpHeaders = headers,
                    catchupStartMillis = csStart,
                    catchupEndMillis = csEnd,
                    catchupTz = csTz,
                    catchupChannelUuid = csUuid,
                    catchupChannelId = csChannel,
                    onRemintCatchup = { uuid, currentUrl, absStartMillis ->
                        // Task #183: csEnd rides along so the re-mint asks the
                        // provider for only the REMAINING programme length.
                        playlistVm.remintCatchupSession(uuid, currentUrl, absStartMillis, csEnd)
                    },
                    onRevokeCatchup = { url -> playlistVm.revokeCatchupSession(url) },
                    onReportCatchupPosition = { url, secs, paused ->
                        playlistVm.reportCatchupPosition(url, secs, paused)
                    },
                    onClose = { if (!recMiniToken.minimized) navController.popBackStack() },
                    loadingMessage = null,
                    // STABLE progress identity (2026-08-28, iOS parity): server
                    // recordings key as dvr-<remoteID> (derived from the
                    // /api/channels/recordings/<id>/ URL - same numeric id iOS
                    // uses), so resume survives LAN/WAN base swaps AND syncs
                    // across devices. URLs (local files, catch-up sessions)
                    // stay as-is; the sync builder filters URL-shaped keys.
                    // GH #75: the DVR tab passes the id explicitly (a
                    // server-reported file_url need not contain it); the
                    // URL match covers the in-progress /hls/ and legacy
                    // /file/ shapes, with or without the /api/channels
                    // prefix.
                    videoId = recordingProgressId(playbackUrl, recId),
                    progressMeta = recProgressMeta,
                    posterUrl = null,
                    isDvr = isDvr,
                    startAtLiveEdge = isDvr && !fromStart && !autoResume,
                    dvrAutoResume = autoResume,
                    recEndMillis = recEnd,
                    completedUrl = completedUrl,
                    onContinueOnLive = continueOnLive,
                    // GH #76: catch-up sessions are not recordings; no tile.
                    onMultiview = if (csUuid.isBlank()) ({ recMvOpen = true }) else null,
                )
                if (recMvOpen) {
                    com.aeriotv.android.feature.player.RecordingMultiviewPicker(
                        seedTile = remember(playbackUrl, recId) {
                            com.aeriotv.android.feature.player.recordingMultiviewTile(
                                recordingKey = if (recId > 0) "server-$recId" else playbackUrl,
                                title = title.ifBlank { "Recording" },
                                playbackUrl = playbackUrl,
                                headers = headers,
                                inProgress = isDvr,
                            )
                        },
                        onLaunch = {
                            recMvOpen = false
                            // Pop the recording player (its player releases on
                            // dispose) so only the tiles make sound.
                            navController.popBackStack()
                            navController.navigate(Routes.MULTIVIEW) { launchSingleTop = true }
                        },
                        onClose = { recMvOpen = false },
                    )
                }
            }
        }
    }
        // In-app reminder banner overlay. Floats over every screen; the bus
        // only surfaces a banner when a reminder fires while foregrounded.
        ReminderBannerHost(
            onOpenChannel = { channelId -> navController.navigate(Routes.player(channelId)) },
            modifier = Modifier.align(Alignment.TopCenter),
        )
        // What's New sheet (Phase 137 / audit #46). Decides internally
        // whether to show based on BuildConfig.VERSION_NAME vs the user's
        // last-dismissed value; first-ever install is seeded silently so
        // the onboarding flow isn't interrupted.
        WhatsNewGate()

        // In-app updater prompt (github flavor; inert no-op on Play). Renders
        // only on the main tabs, after What's New settles, and drives the
        // throttled foreground update check.
        val updateBackStack by navController.currentBackStackEntryAsState()
        UpdateGate(currentRoute = updateBackStack?.destination?.route)

        // Live Rewind one-time feature prompt (task #145). Renders only on
        // the main tabs after What's New settles, so prompts never stack.
        com.aeriotv.android.feature.whatsnew.LiveRewindPromptGate(
            currentRoute = updateBackStack?.destination?.route,
        )

        // Mini-player overlay (Phase 139 / audit #22). The session ViewModel
        // is rooted here so the same instance is visible from PlayerScreen
        // (writes state on its dispose) and from this overlay (reads state
        // and renders). The TV variant draws a top-right video window with a
        // "hold Back to resume" hint; the phone variant lives inside
        // MainScaffold as a row above the bottom nav.
        val miniPlayerVm: MiniPlayerViewModel = androidx.hilt.navigation.compose.hiltViewModel()
        val miniState by miniPlayerVm.state.collectAsStateWithLifecycle()
        val miniContext = androidx.compose.ui.platform.LocalContext.current
        val miniEntry = remember {
            dagger.hilt.android.EntryPointAccessors.fromApplication(
                miniContext.applicationContext,
                MainScaffoldEntryPoint::class.java,
            )
        }
        val miniExoHolder = remember { miniEntry.exoPlayerHolder() }
        val miniExoWindowState = remember { miniEntry.exoWindowState() }
        // tvOS-parity mini Back: SINGLE Back expands to fullscreen, DOUBLE
        // Back jumps the guide to the top channel (mini keeps playing). There
        // is no Back-to-close (tvOS only stops via the player's X); the video
        // is drawn by the activity-lifetime PersistentExoWindow at root.
        TvMiniPlayerOverlay(
            state = miniState,
            onResume = {
                val resumed = miniPlayerVm.resumeChannel()
                if (resumed != null) {
                    // Single top: a repeated expand must never stack a
                    // second player route over the first.
                    navController.navigate(Routes.player(resumed.id)) { launchSingleTop = true }
                }
            },
            onJumpToTop = {
                // Mini stays Active; the guide (composed under the mini on the
                // Live TV tab) scrolls + focuses its top channel.
                miniPlayerVm.session.requestGuideTop()
            },
        )
        // Radio Mode "Return to Channel": the holder is still playing the
        // channel, so the player adopts it with no re-tune.
        androidx.compose.runtime.LaunchedEffect(Unit) {
            com.aeriotv.android.feature.player.RadioMode.returnRequests.collect { ch ->
                runCatching { navController.navigate(Routes.player(ch.id)) { launchSingleTop = true } }
            }
        }
        // Double-press D-pad Select event - MainActivity emits into the
        // session's resumeRequests flow; this collects and re-pushes the
        // PLAYER route. Belongs at the NavController scope, hence here.
        // Phone on-demand mini tap (PhoneVodMini.kt): re-push the player route
        // that minimized; its VODPlayerScreen adopts the playing instance.
        // Never emits on TV.
        androidx.compose.runtime.LaunchedEffect(Unit) {
            com.aeriotv.android.feature.player.PhoneVodMini.expandRequests.collect { route ->
                runCatching { navController.navigate(route) { launchSingleTop = true } }
                    .onFailure { android.util.Log.e("PhoneVodMini", "expand navigate threw", it) }
            }
        }
        androidx.compose.runtime.LaunchedEffect(Unit) {
            miniPlayerVm.session.resumeRequests.collect { channel ->
                android.util.Log.i(
                    "MiniPlayerResume",
                    "NavHost received resume for channel id=${channel.id}; navigating to PLAYER",
                )
                runCatching { navController.navigate(Routes.player(channel.id)) { launchSingleTop = true } }
                    .onFailure {
                        android.util.Log.e(
                            "MiniPlayerResume",
                            "navController.navigate(PLAYER) threw",
                            it,
                        )
                    }
            }
        }
    }
    }
}

/** True while MAIN (the tab shell) is the TOP nav destination: false the
 *  instant a detail, player or settings route is pushed over it. TV pages
 *  read it to tell "the tab lost focus because a route is opening" from
 *  "focus was lost and nothing holds it" (see the focus watchdog in
 *  TvMediaPage). Always true on the phone shell's default. */
val LocalMainIsTopDestination: androidx.compose.runtime.ProvidableCompositionLocal<androidx.compose.runtime.State<Boolean>> =
    androidx.compose.runtime.staticCompositionLocalOf { mutableStateOf(true) }

@Composable
private fun BootstrapSplash() {
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center,
    ) {
        CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
    }
}
