package com.aeriotv.android.ui.theme

import androidx.compose.ui.graphics.Color

/**
 * Brand theme presets mirroring iOS AerioTV's AppTheme enum.
 * User-selectable from Settings. Default is [RoyalBlue], inspired by the supplied blue reference.
 *
 * Each theme carries BOTH a dark and a light rendition. The dark rendition
 * ([appBackground]/[cardBackground]/[accentPrimary]) is the original palette
 * and is what every existing install sees. The light rendition
 * ([lightAppBackground]/[lightCardBackground]/[lightAccentPrimary]) is a
 * hand-authored counterpart used only when the orthogonal [AppearanceMode]
 * resolves to Light. Theme = hue/identity; mode = surface luminance.
 *
 * [lightAccentPrimary] exists because several presets' dark accents are far
 * too pale to read as text/tint on a white surface (Aerio's pale cyan,
 * Monochrome's near-white grey, Forest's bright green). The light rendition
 * uses a darkened accent that keeps the hue but earns real contrast on white.
 */
enum class AppTheme(
    val displayName: String,
    val accentPrimary: Color,
    val accentSecondary: Color,
    val appBackground: Color,
    val cardBackground: Color,
    // Light rendition (used only when AppearanceMode resolves to Light).
    val lightAppBackground: Color,
    val lightCardBackground: Color,
    val lightAccentPrimary: Color,
    // Apple ThemeManager.lightAccentSecondary.
    val lightAccentSecondary: Color,
) {
    RoyalBlue(
        displayName = "Que Blue",
        accentPrimary = Color(0xFFFFFFFF),
        accentSecondary = Color(0xFFDCE9FF),
        appBackground = Color(0xFF0C40DF),
        cardBackground = Color(0xFF1046E7),
        lightAppBackground = Color(0xFFF0F4FF),
        lightCardBackground = Color(0xFFFFFFFF),
        lightAccentPrimary = Color(0xFF0747C7),
        lightAccentSecondary = Color(0xFF06349A),
    ),
    SkyBlue(
        displayName = "Sky Blue",
        accentPrimary = Color(0xFFA8E7FF),
        accentSecondary = Color(0xFF58C9F2),
        appBackground = Color(0xFF082A44),
        cardBackground = Color(0xFF103B59),
        lightAppBackground = Color(0xFFBCE9FA),
        lightCardBackground = Color(0xFFDDF4FD),
        lightAccentPrimary = Color(0xFF006992),
        lightAccentSecondary = Color(0xFF005373),
    ),
    PowderBlue(
        displayName = "Powder Blue",
        accentPrimary = Color(0xFFBDD9FF),
        accentSecondary = Color(0xFF8DB9F3),
        appBackground = Color(0xFF142840),
        cardBackground = Color(0xFF213A56),
        lightAppBackground = Color(0xFFD8E8F7),
        lightCardBackground = Color(0xFFF0F6FC),
        lightAccentPrimary = Color(0xFF275E9B),
        lightAccentSecondary = Color(0xFF1C4777),
    ),
    Arctic(
        displayName = "Arctic",
        accentPrimary = Color(0xFFB5F0F1),
        accentSecondary = Color(0xFF77CFD1),
        appBackground = Color(0xFF092B32),
        cardBackground = Color(0xFF143D45),
        lightAppBackground = Color(0xFFD8F0F2),
        lightCardBackground = Color(0xFFF0FAFB),
        lightAccentPrimary = Color(0xFF006775),
        lightAccentSecondary = Color(0xFF00515B),
    ),
    Ocean(
        displayName = "Ocean",
        accentPrimary = Color(0xFFA4CBFF),
        accentSecondary = Color(0xFF70A8F0),
        appBackground = Color(0xFF0A2448),
        cardBackground = Color(0xFF123763),
        lightAppBackground = Color(0xFFE7EFF9),
        lightCardBackground = Color(0xFFF8FBFF),
        lightAccentPrimary = Color(0xFF145C9A),
        lightAccentSecondary = Color(0xFF104779),
    ),
    Aerio(
        displayName = "AerioTV",
        accentPrimary = Color(0xFF1AC4D8),
        accentSecondary = Color(0xFF1A8FA8),
        appBackground = Color(0xFF0A1628),
        cardBackground = Color(0xFF0D1E35),
        lightAppBackground = Color(0xFFF2F7FA),
        lightCardBackground = Color(0xFFFFFFFF),
        // Bright pale cyan is invisible as text on white -> darkened teal.
        lightAccentPrimary = Color(0xFF0E8FA0),
        lightAccentSecondary = Color(0xFF0B6E7C),
    ),
    Midnight(
        displayName = "Midnight",
        accentPrimary = Color(0xFF60A5FA),
        accentSecondary = Color(0xFF3B82F6),
        appBackground = Color(0xFF0A0F1A),
        cardBackground = Color(0xFF111827),
        lightAppBackground = Color(0xFFF4F6FB),
        lightCardBackground = Color(0xFFFFFFFF),
        lightAccentPrimary = Color(0xFF2563EB),
        lightAccentSecondary = Color(0xFF1D4ED8),
    ),
    Sunset(
        displayName = "Sunset",
        accentPrimary = Color(0xFFFB923C),
        accentSecondary = Color(0xFFF97316),
        appBackground = Color(0xFF0F0A07),
        cardBackground = Color(0xFF1A1108),
        lightAppBackground = Color(0xFFFCF7F2),
        lightCardBackground = Color(0xFFFFFFFF),
        lightAccentPrimary = Color(0xFFE8590C),
        lightAccentSecondary = Color(0xFFC2410C),
    ),
    Forest(
        displayName = "Forest",
        accentPrimary = Color(0xFF4ADE80),
        accentSecondary = Color(0xFF22C55E),
        appBackground = Color(0xFF080F0A),
        cardBackground = Color(0xFF0E1A10),
        lightAppBackground = Color(0xFFF3F8F4),
        lightCardBackground = Color(0xFFFFFFFF),
        lightAccentPrimary = Color(0xFF16A34A),
        lightAccentSecondary = Color(0xFF15803D),
    ),
    Lavender(
        displayName = "Lavender",
        accentPrimary = Color(0xFFA78BFA),
        accentSecondary = Color(0xFF8B5CF6),
        appBackground = Color(0xFF0C0A12),
        cardBackground = Color(0xFF130F1E),
        lightAppBackground = Color(0xFFF7F5FC),
        lightCardBackground = Color(0xFFFFFFFF),
        lightAccentPrimary = Color(0xFF7C3AED),
        lightAccentSecondary = Color(0xFF6D28D9),
    ),
    Monochrome(
        displayName = "Monochrome",
        accentPrimary = Color(0xFFE2E8F0),
        accentSecondary = Color(0xFF94A3B8),
        appBackground = Color(0xFF0A0A0A),
        cardBackground = Color(0xFF111111),
        lightAppBackground = Color(0xFFF5F5F5),
        lightCardBackground = Color(0xFFFFFFFF),
        // Near-white pale grey is invisible on white -> dark slate ink.
        lightAccentPrimary = Color(0xFF475569),
        lightAccentSecondary = Color(0xFF334155),
    ),

    /**
     * Standalone neutral "Light" theme. A low-chroma teal-grey accent that
     * reads on white. Orthogonal to [AppearanceMode]: picking this theme does
     * NOT flip the mode. It ships a dark rendition too so it stays consistent
     * when the user's mode is Dark/System-dark.
     */
    Light(
        displayName = "Light",
        // Dark rendition: a lighter teal reads on the near-black ground.
        accentPrimary = Color(0xFF3E9EAC),
        accentSecondary = Color(0xFF2B7A86),
        appBackground = Color(0xFF0E1518),
        cardBackground = Color(0xFF17211F),
        lightAppBackground = Color(0xFFF6F8FA),
        lightCardBackground = Color(0xFFFFFFFF),
        lightAccentPrimary = Color(0xFF2B7A86),
        lightAccentSecondary = Color(0xFF1F5A64),
    ),
}

/**
 * Appearance mode axis, ORTHOGONAL to [AppTheme]. Theme picks the hue; mode
 * picks the surface luminance. Default is [Dark] so every existing install
 * (no stored value) is visually unchanged on upgrade. Persisted + Drive-synced
 * as the raw [wire] string so the choice follows the user across all devices.
 */
enum class AppearanceMode(val wire: String) {
    Dark("dark"),
    Light("light"),
    System("system"),
    ;

    companion object {
        /** Resolve a stored wire value; unknown/absent -> [Dark] (the default). */
        fun fromWire(raw: String?): AppearanceMode =
            entries.firstOrNull { it.wire == raw } ?: Dark
    }
}
