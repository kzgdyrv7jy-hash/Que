package com.aeriotv.android.ui.tv

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.relocation.BringIntoViewRequester
import androidx.compose.foundation.relocation.bringIntoViewRequester
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.focus.onFocusEvent
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.unit.dp
import androidx.compose.ui.zIndex
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

/**
 * tvOS-style focus grow.
 *
 * Apple TV grows the focused element with a quick, slightly springy scale (and
 * lifts it above its neighbours). Android TV focusables in this app previously
 * only swapped a border/background colour the instant focus landed, which is
 * exactly the "rigid vs the smoothness of the tvOS app" feel Archie called out.
 *
 * Drop [tvFocusScale] into a focusable's modifier chain BEFORE the
 * clip/background/border so the whole card scales as one unit, e.g.
 *
 * ```
 * Modifier
 *     .onFocusChanged { focused = it.isFocused }
 *     .tvFocusScale(focused)
 *     .clip(shape)
 *     .background(bg)
 *     .border(...)
 *     .focusable()
 * ```
 *
 * Keyed on [focused], which is only ever true under D-pad focus, so this is a
 * no-op on touch devices (their elements never gain focus) and is safe to apply
 * unconditionally without an `isTv` guard.
 *
 * The [zIndex] bump means the focused, scaled element draws on top of its
 * siblings (so a grown poster/cell/pill is never clipped by the next item),
 * matching how the tvOS focus engine lifts the focused view.
 */
@Composable
fun Modifier.tvFocusScale(
    focused: Boolean,
    focusedScale: Float = 1.08f,
): Modifier {
    val scale by animateFloatAsState(
        targetValue = if (focused) focusedScale else 1f,
        // tvOS grows the focused element with easeInOut over 0.15 s and does
        // NOT overshoot (MoviesView.swift:3840-3856, :3444). The spring this
        // used to run settled in ~250 ms with a bounce, which read as a
        // different, softer motion than the Apple TV next to it. No drop
        // shadow either: tvOS dropped its shadow because it re-rasterized the
        // card on every frame of the grow.
        animationSpec = androidx.compose.animation.core.tween(
            durationMillis = 150,
            easing = androidx.compose.animation.core.EaseInOut,
        ),
        label = "tvFocusScale",
    )
    // CRITICAL for perf: only attach the render layer (and zIndex) while the
    // element is actually focused or mid-animation. Applying graphicsLayer
    // unconditionally put a permanent layer on EVERY element using this
    // modifier; on a dense surface (a guide with 50-100 cells) that made a
    // low-power Android TV box composite that many layers per frame and lagged
    // D-pad navigation. Gating on `focused || scale != 1f` means at most the
    // one focused element (plus the one animating back) ever owns a layer.
    return if (focused || scale != 1f) {
        this
            .zIndex(1f)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
    } else {
        this
    }
}

/**
 * Lets a focused [androidx.compose.material3.Slider] be escaped with the
 * D-pad on Android TV.
 *
 * User report (v0.1.6, Amlogic S905X4): "When I press the down button on
 * my remote [on a focused slider], it doesn't go to the other options
 * below." A Compose Slider claims LEFT/RIGHT to change its value, but it
 * does not reliably hand UP/DOWN back to the focus system on a leanback
 * remote, so the user gets stuck on the slider with no way down.
 *
 * Apply this to the Slider's `modifier`. `onPreviewKeyEvent` fires on the
 * way DOWN the tree -- before the Slider's own key handling -- so we can
 * intercept UP/DOWN, explicitly move focus, and consume them, while
 * LEFT/RIGHT (and everything else) fall through to the Slider so value
 * adjustment is unchanged. No-op on touch devices, which never deliver
 * these key events, so it's safe to apply without an `isTv` guard.
 */
@Composable
fun Modifier.dpadFocusEscape(): Modifier {
    val focusManager = LocalFocusManager.current
    return this.onPreviewKeyEvent { event ->
        if (event.type != KeyEventType.KeyDown) return@onPreviewKeyEvent false
        when (event.key) {
            Key.DirectionDown -> focusManager.moveFocus(FocusDirection.Down)
            Key.DirectionUp -> focusManager.moveFocus(FocusDirection.Up)
            else -> false
        }
    }
}

/**
 * Deadband [androidx.compose.foundation.gestures.BringIntoViewSpec] for TV
 * form screens whose text fields sit under the floating leanback IME.
 *
 * With the keyboard open, Compose Foundation's keep-cursor-visible logic
 * pins the focused field's cursor rect at the IME's top edge. The required
 * correction lands on a fractional pixel, the scrollable rounds it, and the
 * 1px correction re-fires every frame in the opposite direction: the whole
 * form visibly "jiggles" up and down (measured on the Streamer: the form
 * column flips +/-1px continuously while the title and keyboard stay
 * pixel-static). The GH #1 fix (TV-only SOFT_INPUT_ADJUST_PAN) removed the
 * window-resize channel but not this scroll-container loop.
 *
 * The deadband swallows corrections under 2px, breaking the loop; real
 * scrolls (row-to-row focus moves) are far larger. Provide it around the
 * form's scroll container on TV:
 *
 * ```
 * CompositionLocalProvider(LocalBringIntoViewSpec provides TvImeNoJitterBringIntoViewSpec) {
 *     LazyColumn(...) { ... }
 * }
 * ```
 */
@kotlin.OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
object TvImeNoJitterBringIntoViewSpec : androidx.compose.foundation.gestures.BringIntoViewSpec {
    override fun calculateScrollDistance(
        offset: Float,
        size: Float,
        containerSize: Float,
    ): Float {
        // Already fully visible: no scroll.
        if (offset >= 0f && offset + size <= containerSize) return 0f
        // Minimal nudge (default behavior)...
        val distance = if (offset < 0f) offset else offset + size - containerSize
        // ...unless it is a sub-2px correction, which is the IME boundary
        // oscillation, not a real scroll.
        return if (kotlin.math.abs(distance) < 2f) 0f else distance
    }
}

/**
 * Shared state for the keyboard-on-OK gate: [armed] is true only after the
 * user pressed OK on a text field, and flips false whenever D-pad focus
 * moves away. See [TvKeyboardOnOkHost].
 */
class TvKeyboardGateState {
    var armed by androidx.compose.runtime.mutableStateOf(false)
}

val LocalTvKeyboardGate =
    androidx.compose.runtime.staticCompositionLocalOf<TvKeyboardGateState?> { null }

/**
 * TV form keyboard gate: the on-screen keyboard opens only when the user
 * presses OK on a text field, not the moment a field gains D-pad focus.
 *
 * Stock Compose text fields start a platform text-input session (which shows
 * the IME) on focus gain, so walking DOWN through a form popped the keyboard
 * at every field. This wraps the form in [InterceptPlatformTextInput] and
 * blocks the session until the gate is armed by an OK press (see
 * [tvFormFieldInput]). The IME's own Next/Done actions keep the gate armed,
 * so the type-Next-type flow still works; a D-pad move disarms it.
 *
 * No-op on touch devices: phones keep keyboard-on-focus, which is correct
 * there because focusing a field IS the tap.
 */
@OptIn(androidx.compose.ui.ExperimentalComposeUiApi::class)
@Composable
fun TvKeyboardOnOkHost(content: @Composable () -> Unit) {
    val configuration = androidx.compose.ui.platform.LocalConfiguration.current
    val isTv = (configuration.uiMode and android.content.res.Configuration.UI_MODE_TYPE_MASK) ==
        android.content.res.Configuration.UI_MODE_TYPE_TELEVISION
    if (!isTv) {
        content()
        return
    }
    val gate = androidx.compose.runtime.remember { TvKeyboardGateState() }
    androidx.compose.ui.platform.InterceptPlatformTextInput(
        // ONE stable interceptor that reads gate.armed live via snapshotFlow.
        // A recomposition-keyed interceptor raced D-pad moves: the next
        // field's session started under the stale armed=true instance before
        // the swap landed, popping the keyboard mid-walk. collectLatest
        // starts the IME when the gate arms and cancels it (hiding the IME)
        // the moment the gate disarms, with no recomposition in the loop.
        interceptor = androidx.compose.runtime.remember(gate) {
            androidx.compose.ui.platform.PlatformTextInputInterceptor { request, nextHandler ->
                kotlinx.coroutines.coroutineScope {
                    launch {
                        androidx.compose.runtime.snapshotFlow { gate.armed }
                            .collectLatest { armed ->
                                if (armed) nextHandler.startInputMethod(request)
                            }
                    }
                    kotlinx.coroutines.awaitCancellation()
                }
            }
        },
    ) {
        androidx.compose.runtime.CompositionLocalProvider(
            LocalTvKeyboardGate provides gate,
            content = content,
        )
    }
}

/**
 * Form text-field input behavior for TV, used INSIDE a [TvKeyboardOnOkHost]:
 *
 *  - OK (D-pad center / Enter) arms the gate and shows the keyboard.
 *  - D-pad UP/DOWN disarms the gate and moves focus (single-line fields have
 *    no use for vertical cursor movement), so walking the form never pops
 *    the keyboard. This subsumes [dpadFocusEscape], which it falls back to
 *    when no host is present.
 *  - Whenever the keyboard is summoned for the field (OK press, or focus
 *    arriving while the gate is already armed), the field is scrolled toward
 *    the viewport top so the floating centered leanback IME panel cannot
 *    cover it. See the clearance comment in the body.
 *
 * No-op on touch devices (these key events never fire).
 */
@Composable
fun Modifier.tvFormFieldInput(
    horizontalFocusEscape: Boolean = false,
    okSuppressed: () -> Boolean = { false },
): Modifier {
    val gate = LocalTvKeyboardGate.current ?: return this.dpadFocusEscape()
    val keyboard = androidx.compose.ui.platform.LocalSoftwareKeyboardController.current
    val focusManager = LocalFocusManager.current
    // Floating-IME clearance: the Google TV leanback keyboard is a CENTERED
    // floating panel, so it contributes no bottom inset (adjustResize and
    // imePadding are no-ops) and a mid-screen field can sit half-covered
    // behind it. Whenever the keyboard is summoned for this field, request a
    // bring-into-view for the field's rect EXTENDED ~360dp downward;
    // satisfying that oversized rect makes the enclosing scroll container
    // park the field near the viewport TOP, clear of the centered panel.
    // A real scroll like this passes TvImeNoJitterBringIntoViewSpec's <2px
    // deadband unchanged; with no scrollable ancestor (e.g. the SSID dialog)
    // the request is a harmless no-op.
    val bringIntoViewRequester = androidx.compose.runtime.remember { BringIntoViewRequester() }
    val scope = rememberCoroutineScope()
    val imeClearancePx = with(LocalDensity.current) { 360.dp.toPx() }
    val fieldSize = androidx.compose.runtime.remember {
        androidx.compose.runtime.mutableStateOf(androidx.compose.ui.unit.IntSize.Zero)
    }
    fun scrollClearOfFloatingIme() {
        scope.launch {
            bringIntoViewRequester.bringIntoView(
                androidx.compose.ui.geometry.Rect(
                    0f,
                    0f,
                    fieldSize.value.width.toFloat(),
                    fieldSize.value.height.toFloat() + imeClearancePx,
                ),
            )
        }
    }
    // Only an OK whose DOWN-press was also seen by THIS field may arm the
    // gate. The OK that opened the screen (pressed on the navigating row,
    // released after focus pulled into the first field) otherwise delivers
    // its KeyUp here and pops the keyboard on entry, the same spurious
    // release-click TvMenuGuard exists for.
    val sawOkDown = androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }
    // GH #79: whether the FIELD ITSELF holds focus, as opposed to a focusable
    // decoration inside it (the password-reveal eye). This modifier sits on
    // the text field, which is an ANCESTOR of its trailing slot, so
    // onPreviewKeyEvent gets first crack at keys headed for the eye too - and
    // swallowing OK there pops the keyboard instead of letting the button
    // click, which is why the reveal eye never revealed anything on a remote.
    //
    // onFocusEvent CANNOT tell the two apart on its own: it aggregates
    // descendant focus targets (FocusEventModifierNode.getFocusState returns
    // the focused CHILD's state), so it reports isFocused = true for the eye
    // as well. The eye therefore reports its own focus to the caller, which
    // feeds it back as [okSuppressed]; while that is true this modifier keeps
    // its hands off OK entirely. See SecretRevealState.
    val fieldItselfFocused = androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }
    return this
        .bringIntoViewRequester(bringIntoViewRequester)
        .onSizeChanged { fieldSize.value = it }
        .onFocusEvent { state ->
            fieldItselfFocused.value = state.isFocused
            // IME-Next path: focus hopped to this field with the gate still
            // armed (keyboard left open), so no OK press re-fires the scroll.
            // Re-park the newly focused field clear of the floating panel.
            // D-pad moves disarm the gate BEFORE focus lands, so plain
            // form-walking never triggers this.
            if (state.isFocused && gate.armed) scrollClearOfFloatingIme()
        }
        .onPreviewKeyEvent { event ->
        val isOk = event.key == Key.DirectionCenter || event.key == Key.Enter ||
            event.key == Key.NumPadEnter
        when {
            event.type == KeyEventType.KeyDown && event.key == Key.DirectionDown -> {
                gate.armed = false
                focusManager.moveFocus(FocusDirection.Down)
            }
            event.type == KeyEventType.KeyDown && event.key == Key.DirectionUp -> {
                gate.armed = false
                focusManager.moveFocus(FocusDirection.Up)
            }
            // GH #79: a field with a trailing control (the password/API-key
            // reveal eye) needs LEFT/RIGHT to WALK FOCUS, because the trailing
            // button is unreachable otherwise. Up/Down are handled above and OK
            // opens the keyboard, but left/right fell through to the text
            // field, which eats them to move the text cursor - so on a remote
            // there was simply no way to land on the eye and no way to see what
            // you had typed. Only fields that opt in behave this way, and only
            // secret fields opt in, where a cursor you cannot see moving
            // through dots is worth nothing next to reaching the control.
            // moveFocus returns false when there is nothing that way, and the
            // event then falls through to the field unconsumed, exactly like
            // the Up/Down branches.
            event.type == KeyEventType.KeyDown && horizontalFocusEscape &&
                (event.key == Key.DirectionRight || event.key == Key.DirectionLeft) -> {
                gate.armed = false
                // Next/Previous, NOT Right/Left: the reveal button lives in the
                // field's own trailing slot, so its bounds sit INSIDE the
                // field's bounds, and a directional search rejects a candidate
                // it already contains (measured on an ATV emulator: the button
                // reports focusable, and moveFocus(Right) still returned false).
                // Traversal order walks into the decoration slot correctly.
                focusManager.moveFocus(
                    if (event.key == Key.DirectionRight) FocusDirection.Next
                    else FocusDirection.Previous,
                )
            }
            // Swallow the down-press so the field's own key handling never
            // sees a half-click; act on the release.
            event.type == KeyEventType.KeyDown && isOk && fieldItselfFocused.value &&
                !okSuppressed() -> {
                sawOkDown.value = true
                true
            }
            event.type == KeyEventType.KeyUp && isOk && fieldItselfFocused.value &&
                !okSuppressed() -> {
                if (sawOkDown.value) {
                    gate.armed = true
                    keyboard?.show()
                    scrollClearOfFloatingIme()
                }
                sawOkDown.value = false
                true
            }
            else -> false
        }
    }
}

/**
 * BringIntoViewSpec for TV surfaces whose focusables are large cards (poster
 * grids, cast rows): D-pad moves WITHIN a row must never produce a transient
 * vertical scroll of the host list. Fully visible -> no scroll; an item
 * taller than the viewport stays put while any part is visible; corrections
 * under 24px are the title-strip oscillation from a same-row move, not a
 * genuine row change, and are suppressed. Provide via
 * CompositionLocalProvider(LocalBringIntoViewSpec provides ...) around the
 * scrollable, TV only.
 */
/**
 * tvOS page scrolling, measured on the Apple TV DVR tab (2026-09-10): the
 * focused element is kept about 200 pt (100 dp) clear of BOTH screen edges,
 * so the page starts moving on the first Down and steps evenly instead of
 * waiting until a card touches the edge and then jumping. Minimal distance
 * to satisfy the margin; an element taller than the room aligns its top.
 * Same-row wobble under 24 px is suppressed like [TvLargeCardBringIntoViewSpec].
 */
@kotlin.OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
class TvEdgeMarginBringIntoViewSpec(
    private val marginPx: Float,
    /** True while the page runs its own scroll (snap to top): no competing request. */
    private val suppressed: () -> Boolean = { false },
    /** True while a target that must not scroll the page holds focus (the library header row). */
    private val holdIfVisible: () -> Boolean = { false },
) : androidx.compose.foundation.gestures.BringIntoViewSpec {
    /**
     * MUST be a spring, never a tween. `UpdatableAnimationState.animateToZero`
     * restarts this spec from the CURRENT remaining distance on every frame
     * with playTime equal to one frame, and a tween ignores the carried
     * velocity, so feeding it a tween turns the scroll into a fixed-ratio
     * exponential decay: about 70 frames to cover 200 px, with a sub-pixel
     * tail that renders as frames of no movement at all (Compose 1.11.1,
     * UpdatableAnimationState.kt:100-137, FloatAnimationSpec.kt:210-219,
     * LazyGridState.kt:536-541). A spring carries velocity, which is what the
     * loop is built for.
     */
    override val scrollAnimationSpec: androidx.compose.animation.core.AnimationSpec<Float> =
        spring(stiffness = Spring.StiffnessMediumLow)

    override fun calculateScrollDistance(
        offset: Float,
        size: Float,
        containerSize: Float,
    ): Float {
        if (suppressed()) return 0f
        // Up from the genre pills onto the sort circle must not move the
        // page (Logan 2026-09-10): while the header row holds focus and any
        // of it is on screen, no scroll at all.
        if (holdIfVisible() && offset + size > 0f && offset < containerSize) return 0f
        val top = marginPx
        val bottom = containerSize - marginPx
        if (size > bottom - top) {
            // Too tall for the room: keep it anchored to the top margin.
            val d = offset - top
            return if (kotlin.math.abs(d) < 24f) 0f else d
        }
        if (offset >= top && offset + size <= bottom) return 0f
        val distance = if (offset < top) offset - top else offset + size - bottom
        return if (kotlin.math.abs(distance) < 24f) 0f else distance
    }
}

/**
 * Horizontal counterpart of [TvEdgeMarginBringIntoViewSpec] for the TV shelf
 * LazyRows and the genre-pill LazyRow: keep the focused child [marginPx] clear
 * of the row's START and END edges, and do nothing while it already is. tvOS
 * scrolls its shelves the same way, keeping the focused poster off both
 * edges instead of waiting for it to touch one.
 *
 * No `scrollAnimationSpec` override on purpose: the framework default is a
 * spring, and a tween here decays into a crawl (see the note on
 * [TvEdgeMarginBringIntoViewSpec.scrollAnimationSpec]).
 */
@kotlin.OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
class TvHorizontalBringIntoViewSpec(
    private val marginPx: Float,
) : androidx.compose.foundation.gestures.BringIntoViewSpec {
    override fun calculateScrollDistance(
        offset: Float,
        size: Float,
        containerSize: Float,
    ): Float {
        val start = marginPx
        val end = containerSize - marginPx
        if (size > end - start) {
            // Wider than the room between the margins: anchor its start edge.
            return offset - start
        }
        if (offset >= start && offset + size <= end) return 0f
        return if (offset < start) offset - start else offset + size - end
    }
}

@kotlin.OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
object TvLargeCardBringIntoViewSpec : androidx.compose.foundation.gestures.BringIntoViewSpec {
    override fun calculateScrollDistance(
        offset: Float,
        size: Float,
        containerSize: Float,
    ): Float {
        if (offset >= 0f && offset + size <= containerSize) return 0f
        if (size > containerSize && offset < containerSize && offset + size > 0f) return 0f
        val distance = if (offset < 0f) offset else offset + size - containerSize
        return if (kotlin.math.abs(distance) < 24f) 0f else distance
    }
}


/**
 * Grid prefetch for the TV media pages: the default strategy prepares one
 * line ahead, and on the Streamer a shelf or grid row still composed on
 * the frame it entered (15 to 26 ms Compose spikes in the frame stats,
 * 2026-09-10). This one also schedules the line after the next in the
 * scroll direction, and forgets handles for lines that scrolled far away.
 */
@kotlin.OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
class TvTwoLinePrefetchStrategy : androidx.compose.foundation.lazy.grid.LazyGridPrefetchStrategy {
    private val base = androidx.compose.foundation.lazy.grid.LazyGridPrefetchStrategy(nestedPrefetchItemCount = 6)
    private val extra = HashMap<Int, List<androidx.compose.foundation.lazy.layout.LazyLayoutPrefetchState.PrefetchHandle>>()

    /**
     * Lines a page wants composed BEFORE it starts a long snap (the hero
     * and shelves above a scrolled-down viewport, Logan 2026-09-10: the snap
     * hitched while both hero cards composed mid-animation). Drained on the
     * next scroll callback; [onDone] fires once every requested line has
     * finished precomposing and premeasuring.
     */
    private var wanted: List<Int> = emptyList()
    private var wantedDone: (() -> Unit)? = null

    /**
     * True once the grid has actually driven this strategy. A strategy that is
     * NOT the grid's own (see [rememberTvMediaGridState], which has to choose
     * between a cache window and a custom strategy in Compose 1.11.1) never
     * receives a [LazyGridPrefetchScope], so a queued request would hang its
     * caller forever; report the lines as ready instead.
     */
    private var attached = false

    fun requestLines(lines: List<Int>, onDone: () -> Unit) {
        if (lines.isEmpty() || !attached) { onDone(); return }
        wanted = lines
        wantedDone = onDone
    }

    private fun androidx.compose.foundation.lazy.grid.LazyGridPrefetchScope.drainWanted() {
        val lines = wanted
        val done = wantedDone ?: return
        if (lines.isEmpty()) return
        wanted = emptyList(); wantedDone = null
        var remaining = lines.size
        lines.forEach { line ->
            scheduleLinePrefetch(line) { if (--remaining == 0) done() }
        }
    }

    override fun androidx.compose.foundation.lazy.grid.LazyGridPrefetchScope.onScroll(
        delta: Float,
        layoutInfo: androidx.compose.foundation.lazy.grid.LazyGridLayoutInfo,
    ) {
        attached = true
        drainWanted()
        with(base) { onScroll(delta, layoutInfo) }
        val visible = layoutInfo.visibleItemsInfo
        if (visible.isEmpty()) return
        val forward = delta < 0
        val line = if (forward) visible.last().row + 2 else visible.first().row - 2
        if (line >= 0 && !extra.containsKey(line)) extra[line] = scheduleLinePrefetch(line)
        val keep = (visible.first().row - 3)..(visible.last().row + 3)
        extra.keys.filter { it !in keep }.forEach { k -> extra.remove(k)?.forEach { it.cancel() } }
    }

    override fun androidx.compose.foundation.lazy.grid.LazyGridPrefetchScope.onVisibleItemsUpdated(
        layoutInfo: androidx.compose.foundation.lazy.grid.LazyGridLayoutInfo,
    ) {
        attached = true
        drainWanted()
        with(base) { onVisibleItemsUpdated(layoutInfo) }
    }

    override fun androidx.compose.foundation.lazy.layout.NestedPrefetchScope.onNestedPrefetch(firstVisibleItemIndex: Int) {
        with(base) { onNestedPrefetch(firstVisibleItemIndex) }
    }
}

private val tvGridStrategies = java.util.WeakHashMap<androidx.compose.foundation.lazy.grid.LazyGridState, TvTwoLinePrefetchStrategy>()

/** The strategy behind a [rememberTvMediaGridState] state, for pages that want lines warmed. */
fun tvPrefetchStrategyFor(state: androidx.compose.foundation.lazy.grid.LazyGridState): TvTwoLinePrefetchStrategy? = tvGridStrategies[state]

/**
 * LazyGridState for the TV media pages: a cache window keeps items composed
 * for one viewport ahead and two behind instead of disposing them the
 * moment they leave. The tvOS DVR tab keeps its hero and shelves in a plain
 * stack for the same reason (trace 2026-09-05 01:47: a shelf unloaded on
 * the way up and the page redrew); rapid Up presses from the library to
 * the hero here composed the hero mid-scroll (Logan 2026-09-10).
 */
@kotlin.OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@androidx.compose.runtime.Composable
fun rememberTvMediaGridState(): androidx.compose.foundation.lazy.grid.LazyGridState {
    val window = androidx.compose.runtime.remember {
        androidx.compose.foundation.lazy.layout.LazyLayoutCacheWindow(aheadFraction = 1f, behindFraction = 2f)
    }
    val strategy = androidx.compose.runtime.remember { TvTwoLinePrefetchStrategy() }
    // Compose 1.11.1 offers a cacheWindow overload and a prefetchStrategy
    // overload, and they are mutually exclusive: the cacheWindow constructor
    // installs the internal LazyGridCacheWindowPrefetchStrategy itself
    // (LazyGridState.kt:100-141, :169-178). The cache window is the stronger
    // of the two here, because it RETAINS items that scrolled out instead of
    // only precomposing ones that are coming in, so it wins. The strategy is
    // still registered so [tvPrefetchStrategyFor] resolves and a caller's
    // requestLines(...) completes (immediately, since the window has already
    // kept the lines above and below the viewport composed) rather than
    // silently doing nothing on a null.
    val state = androidx.compose.foundation.lazy.grid.rememberLazyGridState(cacheWindow = window)
    androidx.compose.runtime.remember(state, strategy) {
        tvGridStrategies[state] = strategy
        true
    }
    return state
}
