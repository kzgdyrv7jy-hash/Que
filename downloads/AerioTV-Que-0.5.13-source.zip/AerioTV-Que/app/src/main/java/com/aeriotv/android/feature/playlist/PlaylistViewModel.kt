package com.aeriotv.android.feature.playlist

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aeriotv.android.DeepLinkTarget
import com.aeriotv.android.core.data.EPGProgramme
import com.aeriotv.android.core.data.guideMatchKey
import com.aeriotv.android.core.data.M3UChannel
import com.aeriotv.android.core.guide.guideChannelId
import com.aeriotv.android.core.data.ChannelCollection
import com.aeriotv.android.core.data.SourceType
import com.aeriotv.android.core.debug.LogSanitizer
import com.aeriotv.android.core.app.AppLaunchTrace
import com.aeriotv.android.core.data.bridgeChannelIds
import com.aeriotv.android.core.data.buildChannelEpgKeyBridge
import com.aeriotv.android.core.data.db.entity.PlaylistEntity
import com.aeriotv.android.core.data.db.entity.GUIDE_DAYS_ALL_MAX_AHEAD
import com.aeriotv.android.core.data.db.entity.GUIDE_DAYS_ALL_MAX_BACK
import com.aeriotv.android.core.data.db.entity.sanitizeGuideDays
import com.aeriotv.android.core.data.db.entity.resolveGuideDays
import com.aeriotv.android.core.data.repository.ChannelProfileOption
import com.aeriotv.android.core.data.repository.PlaylistRepository
import com.aeriotv.android.core.debug.MemoryPressureBus
import com.aeriotv.android.core.debug.VodResetBus
import com.aeriotv.android.core.preferences.AppPreferences
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.withLock
import javax.inject.Inject

/**
 * App-scoped state for the source flow:
 *   Bootstrap -> (existing source? auto-refresh : Onboarding -> add) ->
 *   Main (tabs) -> tap channel -> Player.
 *
 * Onboarding supports multiple source types (M3U URL, Dispatcharr API key, etc.)
 * via a picker. The fields surface conditionally based on [UiState.sourceType].
 */
@HiltViewModel
class PlaylistViewModel @Inject constructor(
    private val repository: PlaylistRepository,
    private val memoryPressureBus: MemoryPressureBus,
    private val vodResetBus: VodResetBus,
    private val appPreferences: AppPreferences,
    private val catchupResolver: com.aeriotv.android.core.playback.CatchupPlaybackResolver,
    // GH #22: playback teardown on playlist switch (see switchToPlaylist).
    private val exoHolder: com.aeriotv.android.core.playback.AerioExoPlayerHolder,
    private val exoWindowState: com.aeriotv.android.feature.player.ExoWindowState,
    private val miniPlayerSession: com.aeriotv.android.feature.miniplayer.MiniPlayerSession,
    // Launch ordering only: the guide announces its cached paint here so the
    // other sections' CACHED restores can start right behind it instead of
    // waiting out the 20 s settle delay (see AppSettleGate.awaitGuidePainted).
    private val settleGate: com.aeriotv.android.core.app.AppSettleGate,
) : ViewModel() {

    enum class Phase { Bootstrapping, NeedsUrl, ChannelsReady }

    data class UiState(
        val phase: Phase = Phase.Bootstrapping,
        val sourceType: SourceType = SourceType.M3uUrl,
        /** User-supplied display name for the playlist (Phase 30 multi-playlist). */
        val name: String = "",
        /** Generic URL field; M3U URL for [SourceType.M3uUrl], base URL otherwise. */
        val url: String = "",
        /**
         * Optional LAN URL captured during onboarding for Dispatcharr / Xtream.
         * When the device joins one of the user's saved home SSIDs (Network
         * Settings) and this is non-blank, the runtime URL flips to this. The
         * remote URL above stays the canonical "off-network" path.
         */
        val lanUrl: String = "",
        val epgUrl: String = "",
        val apiKey: String = "",
        val username: String = "",
        val password: String = "",
        /** Per-playlist On Demand opt-in (iOS ServerConnection.vodEnabled).
         *  Bound to the "Fetch On Demand from this playlist" toggle in
         *  ConfigureSourceScreen / EditPlaylistScreen. Default true, threaded
         *  through SaveRequest into PlaylistEntity.vodEnabled. */
        val vodEnabled: Boolean = true,
        /** Task #45 DVR onboarding step (iOS AddServerView Destination
         *  picker): where recordings land by default for Dispatcharr
         *  sources. Persisted to AppPreferences.dvrDefaultDestination only
         *  when the add succeeds, so backing out never mutates the global
         *  setting. */
        val dvrDestinationServer: Boolean = true,
        /** Catch-up guide-history retention draft for the add flow (task
         *  #135); threaded into SaveRequest.epgRetentionDays on submit. */
        val epgRetentionDays: Int = 7,
        val playlist: PlaylistEntity? = null,
        /** Id of the row THIS add-draft created (null until its first successful
         *  Test Connection). Used as the loadAndPersist existingId so a re-test
         *  edits the same draft row instead of duplicating -- WITHOUT reusing the
         *  active [playlist]'s id, which would edit the wrong playlist. Reset by
         *  [startNewSource] when a new add begins. */
        val draftPlaylistId: String? = null,
        val channels: List<M3UChannel> = emptyList(),
        val epgByChannel: Map<String, List<EPGProgramme>> = emptyMap(),
        val isEpgLoading: Boolean = false,
        /** Hours of already-aired guide the grid can scroll back through:
         *  the active playlist's epgRetentionDays * 24 once the deferred
         *  history pass has merged (task #135); 1h before that so cold-launch
         *  paint keeps its cheap narrow window. */
        val epgHistoryHours: Int = 1,
        /** Whole days either side of now that the on-disk EPG cache actually
         *  holds, refreshed whenever the cached paint runs. The guide catalog
         *  itself only spans the launch window plus whatever the user has
         *  scrolled or jumped to (see [rebuildGuideCatalog]), so the Jump To
         *  extent has to come from the cache instead of from the catalog:
         *  Guide Days still promises every cached day is reachable. */
        val epgCachedDaysBack: Int = 0,
        val epgCachedDaysAhead: Int = 0,
        val searchQuery: String = "",
        val selectedGroup: String = ALL_GROUPS,
        val sortMode: SortMode = SortMode.ByNumber,
        val isLoading: Boolean = false,
        val error: String? = null,
        /**
         * Dispatcharr channel profiles available for the active playlist, shown
         * as scoping options in Edit Playlist. Empty until [loadDispatcharrProfiles]
         * resolves (or for non-Dispatcharr sources / servers with no profiles).
         */
        val availableProfiles: List<ChannelProfileOption> = emptyList(),
        val profilesLoading: Boolean = false,
        /** Per-action feedback for Playlist Detail's rows. Idle outside that
         *  screen; the screen resets them on dispose via
         *  [clearDetailActionStatuses]. */
        val testStatus: ActionStatus = ActionStatus.Idle,
        val playlistRefreshStatus: ActionStatus = ActionStatus.Idle,
        val epgRefreshStatus: ActionStatus = ActionStatus.Idle,
        val refreshAllStatus: ActionStatus = ActionStatus.Idle,
        val lanRefreshStatus: ActionStatus = ActionStatus.Idle,
        /** Which URL [PlaylistRepository.effectiveBaseUrl] resolves to right
         *  now (LAN vs WAN), for the Connection row. Null until probed. */
        val activeRoute: ActiveRoute? = null,
    )

    /** Lifecycle of one Playlist Detail action (Test Connection / Refresh
     *  Playlist / Refresh EPG Data). */
    sealed interface ActionStatus {
        data object Idle : ActionStatus
        data object Running : ActionStatus
        data class Success(val message: String) : ActionStatus
        data class Failure(val message: String) : ActionStatus
    }

    /**
     * "Skip for now" on the Welcome screen: the user chose to enter the app
     * with no playlist. The MAIN route's NeedsUrl bounce-back guard respects
     * this for the rest of the session; without it, Skip navigated to MAIN
     * and was bounced straight back to Welcome within a frame, so the button
     * read as dead. Resets with the process: an unconfigured app still lands
     * on Welcome at next launch.
     */
    var onboardingSkipped: Boolean = false

    data class ActiveRoute(val isLan: Boolean, val url: String)

    companion object {
        const val ALL_GROUPS = "All"
        /** Pinned Favorites group inside Live TV (Apple parity: Favorites is a
         *  channel group, not a tab). Never a provider group name. */
        const val FAVORITES_GROUP = "__favorites__"
        /** Synthetic "Recently Watched" group (Logan 2026-09-14): the last 25
         *  channels played, most recent first. Hidden until it is checked in
         *  Manage Groups. Never a provider group name. */
        const val RECENT_GROUP = "__recent__"
        private const val TAG = "PlaylistViewModel"

        /** Timing log tag shared with [PlaylistRepository]'s save stages. */
        private const val TAG_SAVE = "AerioSave"

        /**
         * How long the save screen waits for one On Demand half to produce its
         * first page before moving on. Generous (a cold Dispatcharr VOD page on
         * a big panel is seconds, not milliseconds) but bounded: a server that
         * neither answers nor fails must not strand the user on a save screen.
         */
        private const val VOD_REBUILD_STAGE_TIMEOUT_MS = 45_000L

        /**
         * How long a disk-cached EPG is treated as fresh before a relaunch also
         * hits the network. Within this window the cache is used as-is (instant,
         * no network); past it the cache is still painted instantly but a
         * background refresh runs. 30 minutes keeps now-playing accurate while
         * making quick app revisits zero-network.
         */
        private const val EPG_CACHE_TTL_MS = 30L * 60L * 1000L

        /** Launch quick paint: the cached rows read before the first guide
         *  frame (the pre-9be8071 quick pass window). The full window follows
         *  in the background. */
        private const val QUICK_PAINT_BACK_MS = 2L * 60L * 60L * 1000L
        private const val QUICK_PAINT_AHEAD_MS = 8L * 60L * 60L * 1000L

        /** Generation of the on-disk EPG cache this build trusts. BUMP THIS
         *  whenever a shipped defect could have written a corrupt cache: the
         *  next launch forces one full refetch, re-stamps, and resumes normal
         *  TTL behaviour. 1 = the 0.4.10 per-source merge bug, where each
         *  upstream feed deleted the previous one's present+future. */
        private const val EPG_CACHE_EPOCH = 1

        /**
         * Channel snapshots refresh on a much slower cadence than the EPG (a
         * channel list adds/removes channels far less often than guide data
         * changes), so the cache is treated as fresh for 24 h before a relaunch
         * also hits the network. Within the window the cache paints and we
         * skip the network entirely; outside it the cache still paints
         * instantly but a background refresh runs. Per Archie: loading times
         * shouldn't be an issue unless we're 24 hours removed from the cache.
         */
        private const val CHANNEL_CACHE_TTL_MS = 24L * 60L * 60L * 1000L

        /** GH #124: non-Dispatcharr playlists above this many channels keep
         *  the fresh-cache skip at cold launch (Apple GuideStore.largePlaylistChannels). */
        private const val LARGE_PLAYLIST_CHANNELS = 5_000

        /**
         * iOS GuideStore audit P3 #12: trigger a Rolling Prefetch when the
         * user has scrolled within 4 hours of the latest cached programme's
         * end time. 4h means a guide-scale=0.5 user (12h viewport) trips
         * the prefetch when they've consumed 8 of the 12 visible hours --
         * enough lead time for the fetch to land before they hit the empty
         * tail. Bigger gap = more wasted fetches; smaller gap = visible
         * empty cells before the refresh arrives. 4h is the iOS default
         * (`prefetchTriggerHours = 4`).
         */
        private const val PREFETCH_TRIGGER_DISTANCE_MS = 4L * 60L * 60L * 1000L

        /**
         * Don't re-fire a Rolling Prefetch within this many millis of the
         * previous one. The same coalescing layer (P1 #6) already dedups
         * concurrent fetches that overlap; the cooldown here is for the
         * case where a fetch succeeded but the user keeps scrolling --
         * without it, the cell-onAppear stream of trigger events would
         * keep firing every frame. 60s lines up with the iOS Rolling
         * Prefetch's `prefetchBreakerCooldown` floor.
         */
        private const val PREFETCH_COOLDOWN_MS = 60L * 1000L
    }

    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state.asStateFlow()

    /** I-5 (perf campaign 2026-08-20): every writer of
     *  [UiState.epgByChannel] serializes through this mutex, with the heavy
     *  merge computed on Dispatchers.Default against a snapshot taken under
     *  the lock. Because no other epg writer can run between snapshot and
     *  install, the install is a plain map swap - the merge loops that used
     *  to run INSIDE `_state.update` (on the caller's Main dispatcher, and
     *  re-run on CAS contention) are gone. This was the "EPG merge storms on
     *  Main" finding: the minutes-after-open hitch cascade, and the iowait
     *  half of the group-switch ANR. */
    private val epgWriteMutex = kotlinx.coroutines.sync.Mutex()

    /** One-shot signal that a source was successfully configured (added). The
     *  add flow navigates forward on THIS event, not on `phase == ChannelsReady`:
     *  when adding a second playlist `phase` is already ChannelsReady, so a
     *  phase-watcher never re-fires and the add silently succeeds with no advance. */
    private val _sourceConfigured = MutableSharedFlow<Unit>(extraBufferCapacity = 1)
    val sourceConfigured: SharedFlow<Unit> = _sourceConfigured.asSharedFlow()

    /**
     * Which phase of a playlist save is running right now, or null when no save
     * is in flight. Emitted by [PlaylistRepository.loadAndPersist] at the real
     * call boundaries (login, channel fetch, persist), never on a timer, so the
     * staged loading screen Edit Playlist shows can name what is taking the
     * time. A StateFlow because the repository reports stages from whatever
     * dispatcher it is on.
     */
    private val _saveStage = MutableStateFlow<PlaylistRepository.SaveStage?>(null)
    val saveStage: StateFlow<PlaylistRepository.SaveStage?> = _saveStage.asStateFlow()

    /**
     * The steps THIS save is going to run, in display order, so the staged
     * screen lists exactly those and no others (a playlist whose account cannot
     * view TV Shows never gets a "Loading TV shows..." row). Grows as the save
     * learns what it will do; see [PlaylistRepository.SavePlan].
     */
    private val _savePlan = MutableStateFlow(
        PlaylistRepository.SavePlan(
            stages = listOf(
                PlaylistRepository.SaveStage.LoadingChannels,
                PlaylistRepository.SaveStage.Finishing,
            ),
        ),
    )
    val savePlan: StateFlow<PlaylistRepository.SavePlan> = _savePlan.asStateFlow()

    /**
     * Whether the save now in flight has a network stage worth a loading screen.
     * False for an instant save (a rename, a Guide Days change, an On Demand
     * toggle): those write one row and pop, so showing "Loading channels" for a
     * frame would be both a lie and a flash. Set before the work starts and
     * cleared when it settles.
     */
    private val _saveHasProgress = MutableStateFlow(false)
    val saveHasProgress: StateFlow<Boolean> = _saveHasProgress.asStateFlow()

    /** Pending Live TV guide-jump target (channel guideMatchKey + programme
     *  start millis), emitted when a Search EPG result is tapped while the
     *  app is foregrounded. GuideScreen collects this (when mounted) to
     *  scroll + focus the cell; MainScaffold collects it to switch to the
     *  Live TV tab. extraBufferCapacity=1 + DROP_OLDEST so a tap that lands
     *  before any collector is attached (cold guide) is still replayable via
     *  the DeepLinkTarget.GuideProgram durable path in Navigation.kt. */
    private val _guideJumpRequests =
        kotlinx.coroutines.flow.MutableSharedFlow<DeepLinkTarget.GuideProgram>(
            replay = 1,
            extraBufferCapacity = 1,
            onBufferOverflow = kotlinx.coroutines.channels.BufferOverflow.DROP_OLDEST,
        )
    val guideJumpRequests: SharedFlow<DeepLinkTarget.GuideProgram> = _guideJumpRequests.asSharedFlow()

    /**
     * Companion remote X (GH #33): "put the tab shell back on Live TV".
     *
     * Separate from [guideJumpRequests] because there is no programme to jump
     * to and because this one must NOT replay: a replayed value would yank a
     * later, deliberate tab choice back to Live TV the next time MainScaffold
     * recomposed its collector.
     */
    private val _liveTvTabRequests =
        kotlinx.coroutines.flow.MutableSharedFlow<Unit>(
            replay = 0,
            extraBufferCapacity = 1,
            onBufferOverflow = kotlinx.coroutines.channels.BufferOverflow.DROP_OLDEST,
        )
    val liveTvTabRequests: SharedFlow<Unit> = _liveTvTabRequests.asSharedFlow()

    /**
     * Pending `aeriotvblue://settings/<page>` screenshot deep link, or null.
     *
     * A StateFlow rather than a SharedFlow because SettingsTabContent is NOT
     * composed until MainScaffold has switched to the Settings tab, so the
     * request has to still be readable on a later frame; the consumer clears
     * it with [consumeSettingsPage]. It also survives the wait for the active
     * playlist that the playlist-detail / edit-playlist pages need.
     */
    private val _settingsPageRequest = MutableStateFlow<SettingsPageRequest?>(null)
    val settingsPageRequest: StateFlow<SettingsPageRequest?> = _settingsPageRequest.asStateFlow()

    /**
     * One request, carrying a [seq] so two requests for the SAME page are two
     * distinct values. A StateFlow conflates equal values, so a bare page
     * string meant a second `aeriotvblue://settings/livetv` (or any link arriving
     * while that page was already open) emitted nothing and the warm app never
     * navigated - the bug that made a force-stop the only way to re-link.
     */
    data class SettingsPageRequest(val page: String, val seq: Long)

    private var settingsPageSeq = 0L

    /** Open Settings on [page] (screenshot deep link). */
    fun requestSettingsPage(page: String) {
        settingsPageSeq += 1
        _settingsPageRequest.value = SettingsPageRequest(page, settingsPageSeq)
    }

    /** Clear the pending settings deep link once it has been applied. */
    fun consumeSettingsPage() {
        _settingsPageRequest.value = null
    }

    /** Select the Live TV tab (companion X / exit-to-Live-TV). */
    fun requestLiveTvTab() {
        _liveTvTabRequests.tryEmit(Unit)
    }

    /** Called when a Search EPG result is tapped: stash + broadcast the
     *  jump, and force the group filter back to All so the target channel is
     *  guaranteed visible (iOS ChannelListView sets selectedGroup='All').
     *  Guide-mode itself is a SettingsViewModel/DataStore pref, flipped by
     *  the collector in MainScaffold (see that file). */
    fun requestGuideJump(channelGuideMatchKey: String, startMillis: Long) {
        _state.update { it.copy(selectedGroup = ALL_GROUPS) }
        _guideJumpRequests.tryEmit(
            DeepLinkTarget.GuideProgram(channelGuideMatchKey, startMillis)
        )
    }

    /** Begin adding a NEW source: clear the draft form + draft id so the add
     *  creates a fresh row (existingId = null) and never edits the active
     *  [UiState.playlist], and so the form can't carry over the active server's
     *  API key (which would win over typed user/pass and re-add the old server).
     *  Deliberately does NOT touch [UiState.playlist] / [UiState.channels] /
     *  [UiState.phase], so cancelling the add leaves the active playlist intact. */
    fun startNewSource(type: SourceType) {
        _state.update {
            it.copy(
                sourceType = type,
                name = "",
                url = "",
                lanUrl = "",
                epgUrl = "",
                apiKey = "",
                username = "",
                password = "",
                vodEnabled = true,
                epgRetentionDays = 7,
                draftPlaylistId = null,
                availableProfiles = emptyList(),
                isLoading = false,
                error = null,
            )
        }
    }

    init {
        bootstrap()
        observeMemoryPressure()
        observeUpstreamLayering()
        // Server-declared radio channels of the ACTIVE playlist, for the
        // player's declared audio-only start (playlist-scoped: replaced whole).
        viewModelScope.launch {
            _state.map { s -> s.channels }.distinctUntilChanged { a, b -> a === b }.collect { list ->
                com.aeriotv.android.core.playback.DeclaredRadioChannels.replace(
                    list.asSequence().filter { it.isRadio }.map { it.id }.toSet(),
                )
            }
        }
    }

    /**
     * Fold background-layered upstream catch-up history into the guide when it
     * lands. The repository merges each upstream XMLTV source into the EPG
     * cache OFF the load's critical path (the guide now paints from the grid
     * in seconds; deep history arrives whenever the feeds finish) and emits
     * the playlistId here. mergeEpgHistory is the existing cache -> state
     * merge with per-(channel, start) dedup, so this adds no second merge
     * implementation.
     */
    private fun observeUpstreamLayering() {
        viewModelScope.launch {
            repository.upstreamEpgLayered.collect { playlistId ->
                val active = runCatching { repository.activePlaylist() }.getOrNull()
                if (active?.id != playlistId) return@collect
                Log.i(TAG, "upstream layering landed; merging history into guide")
                runCatching { mergeEpgHistory(active) }
                    .onFailure { Log.w(TAG, "layered history merge failed", it) }
            }
        }
    }

    /**
     * Phase 144 audit task #58: when the system signals critical memory
     * pressure, drop the in-memory `epgByChannel` map. The Room disk cache is
     * untouched, so the next guide open re-paints from cache; the gain is
     * tens of MB of parsed EPGProgramme objects + the groupBy result map
     * that would otherwise wait until the next launch to be GC'd.
     *
     * The Streamer was running at 91% RAM + 100% swap in Phase 142
     * diagnostics; even modest EPG shedding here keeps us out of the
     * low-memory killer queue when other apps want to come up.
     */
    /** Set when a trim shed the in-memory guide; [refreshEpgIfStale] (the
     *  return-to-foreground hook) rebuilds it from the Room cache. */
    @Volatile private var guideShedByTrim = false

    private val repaintMutex = kotlinx.coroutines.sync.Mutex()

    /**
     * Android#131: rebuild a trim-shed guide from the Room cache (no network).
     * Called on process return to foreground, on MAIN re-entry (back from the
     * player), and when the guide opens. No-op unless a shed happened.
     */
    fun repaintGuideIfShed(trigger: String) {
        if (!guideShedByTrim) return
        viewModelScope.launch { repaintShedGuide(trigger) }
    }

    private suspend fun repaintShedGuide(trigger: String) = repaintMutex.withLock {
        if (!guideShedByTrim) return@withLock
        val playlist = _state.value.playlist ?: return@withLock
        if (_state.value.channels.isEmpty()) return@withLock
        guideShedByTrim = false
        Log.i(TAG, "guide repaint after trim: trigger=$trigger (cache only)")
        // Same two-step paint as launch: the quick window first
        // (~4 s on a Shield), then the full window (~18 s).
        val (fromMs, toMs) = guideWindow(playlist)
        val nowMs = System.currentTimeMillis()
        val quick = runCatching {
            repository.loadCachedEpg(
                playlist.id,
                maxOf(fromMs, nowMs - QUICK_PAINT_BACK_MS),
                minOf(toMs, nowMs + QUICK_PAINT_AHEAD_MS),
            )
        }.getOrDefault(emptyList())
        if (quick.isNotEmpty()) rebuildGuideCatalog(playlist, "after-trim-quick", preloadedRows = quick)
        rebuildGuideCatalog(playlist, "after-trim")
    }

    /** Playlist whose catalog rebuild was skipped for want of channels. */
    @Volatile private var pendingCatalogRebuild: String? = null

    private fun observeDeferredCatalogRebuild() {
        viewModelScope.launch {
            _state.map { it.channels.isNotEmpty() }.distinctUntilChanged().collect { has ->
                if (!has) return@collect
                val pending = pendingCatalogRebuild ?: return@collect
                val playlist = _state.value.playlist?.takeIf { it.id == pending } ?: return@collect
                pendingCatalogRebuild = null
                rebuildGuideCatalog(playlist, "deferred")
            }
        }
    }

    private fun observeMemoryPressure() {
        observeDeferredCatalogRebuild()
        viewModelScope.launch {
            com.aeriotv.android.core.data.repository.EpgSweepGate.returnedToForeground.collect {
                repaintGuideIfShed("process-start")
            }
        }
        viewModelScope.launch {
            memoryPressureBus.level.collect { level ->
                if (MemoryPressureBus.isCritical(level)) {
                    val cleared = _state.value.epgByChannel.isNotEmpty()
                    if (!cleared) return@collect
                    // Foreground: never blank the guide the user is looking at.
                    // RUNNING_CRITICAL reports SYSTEM-wide pressure (seen on a
                    // 3 GB Shield with ~650 MB available while this app sat at
                    // ~410 MB PSS); shedding there blanked the visible guide
                    // until the next launch and the rebuild cost ~23 s of
                    // allocation on that device, which is worse than keeping it.
                    // Shed only once backgrounded (COMPLETE), where it is
                    // invisible and rebuilt on return.
                    if (com.aeriotv.android.core.data.repository.EpgSweepGate.appInForeground) {
                        Log.i(TAG, "onTrimMemory=$level: in foreground, keeping in-memory EPG map")
                        return@collect
                    }
                    Log.i(TAG, "onTrimMemory=$level: shedding in-memory EPG map")
                    epgWriteMutex.withLock { _state.update { it.copy(epgByChannel = emptyMap()) } }
                    guideShedByTrim = true
                }
            }
        }
    }

    /**
     * Playlist delete crash guard (Apple d051505 parity): the cold-launch
     * bootstrap job and the EPG load jobs, keyed by the playlist they hold, so
     * [deletePlaylist] can cancel them before the row goes away.
     */
    private val playlistTasks = java.util.concurrent.ConcurrentHashMap<String, MutableMap<String, kotlinx.coroutines.Job>>()

    private val playlistTaskSeq = java.util.concurrent.atomic.AtomicLong()

    private fun trackPlaylistTask(playlistId: String, name: String, job: kotlinx.coroutines.Job) {
        val tasks = playlistTasks.getOrPut(playlistId) { java.util.concurrent.ConcurrentHashMap() }
        // Unique key: several EPG loads can overlap; each must stay cancellable.
        val key = "$name#${playlistTaskSeq.incrementAndGet()}"
        tasks[key] = job
        job.invokeOnCompletion { tasks.remove(key, job) }
    }

    private fun cancelPlaylistTasks(playlistId: String) {
        val tasks = playlistTasks.remove(playlistId).orEmpty()
        var any = false
        for ((key, job) in tasks) {
            val name = key.substringBefore('#')
            if (job.isActive) {
                job.cancel()
                any = true
                Log.i(TAG, "[PLAYLIST] delete: cancelled $name (${playlistId.take(8)})")
            }
        }
        if (_state.value.playlist?.id == playlistId) {
            guideForwardJob?.let { job ->
                if (job.isActive) {
                    job.cancel()
                    any = true
                    Log.i(TAG, "[PLAYLIST] delete: cancelled guide range fetch (${playlistId.take(8)})")
                }
            }
            guideForwardJob = null
        }
        if (!any) Log.i(TAG, "[PLAYLIST] delete: no running view model tasks (${playlistId.take(8)})")
    }

    private fun bootstrap() {
        viewModelScope.launch {
            // Reclaim download temps orphaned by a process death mid fetch,
            // before anything else. Cheap (one cacheDir listing) and it is the
            // only thing that recovers space a force-stopped download leaves
            // behind -- the 4GB-cache report was exactly that, repeated.
            withContext(Dispatchers.IO) { repository.sweepOrphanedDownloads() }
            val saved = repository.activePlaylist()
            if (saved == null) {
                _state.update { it.copy(phase = Phase.NeedsUrl) }
                return@launch
            }
            val sourceType = SourceType.entries.firstOrNull { it.name == saved.sourceType }
                ?: SourceType.M3uUrl
            coroutineContext[kotlinx.coroutines.Job]?.let { trackPlaylistTask(saved.id, "startup channel load", it) }

            // GH #124 (Apple 5e34cf6 parity): a cold launch (the process was
            // killed in the background, then reopened) refreshes channels AND
            // guide for EVERY backend. The 24 h channel TTL and 30 min guide
            // TTL used to skip the network on relaunch, so a playlist that
            // changed on the provider stayed stale until a manual refresh.
            // The cache still paints first; the refresh runs behind it. Huge
            // non-Dispatcharr panels keep the fresh-cache skip (their full
            // M3U/XMLTV pass on top of the cache is what pushes small TV
            // boxes past their memory line), the same carve-out Apple keeps.
            val cachedForGate = runCatching { repository.newestChannelFetch(saved.id) }.getOrNull()
            val isDispatcharrSource = sourceType == SourceType.DispatcharrApiKey ||
                sourceType == SourceType.DispatcharrUserPass
            val channelCountForGate = maxOf(saved.channelCount, 0)
            val largeNonDispatcharr = !isDispatcharrSource && channelCountForGate > LARGE_PLAYLIST_CHANNELS
            val channelCacheFresh = cachedForGate != null &&
                (System.currentTimeMillis() - cachedForGate) < CHANNEL_CACHE_TTL_MS
            val startupRefresh = !(largeNonDispatcharr && channelCacheFresh)

            // Phase 130: paint the disk-cached channel list IMMEDIATELY so the
            // Live TV rail + cells are never blank on a cold launch (Archie's
            // observation: with caching working, loading times shouldn't be an
            // issue under 24h). The network refresh below runs in parallel and
            // swaps in fresh data when ready.
            val cachedChannels = runCatching { repository.loadCachedChannels(saved.id) }
                .getOrDefault(emptyList())
            val hasChannelCache = cachedChannels.isNotEmpty()
            _state.update {
                it.copy(
                    playlist = saved,
                    // Task #136: the guide's back-scroll span is known from the
                    // playlist row itself, so publish it BEFORE the guide first
                    // composes. Keeping windowStart stable from the start
                    // avoids the whole widen-mid-session scroll-compensation
                    // dance (the history ROWS still merge in lazily).
                    epgHistoryHours = (resolveGuideDays(saved.epgRetentionDays)
                        ?: GUIDE_DAYS_ALL_MAX_BACK) * 24,
                    sourceType = sourceType,
                    name = saved.name.orEmpty(),
                    url = saved.urlString,
                    lanUrl = saved.lanUrlString.orEmpty(),
                    epgUrl = saved.epgUrl.orEmpty(),
                    apiKey = saved.apiKey.orEmpty(),
                    username = saved.username.orEmpty(),
                    password = saved.password.orEmpty(),
                    // If we have cached channels, skip straight to ChannelsReady
                    // and don't show the spinner; otherwise stay in pre-bootstrap
                    // phase with the spinner until the first-ever network fetch
                    // lands.
                    phase = if (hasChannelCache) Phase.ChannelsReady else it.phase,
                    channels = cachedChannels,
                    isLoading = !hasChannelCache,
                )
            }
            // GH #81: bring back the group this playlist was left on (Favorites
            // included) before the guide first composes, so the launch paint is
            // already on the user's default group.
            restoreSelectedGroup(
                saved.id,
                cachedChannels.asSequence().map { it.groupTitle }.filter { it.isNotBlank() }.distinct().toList(),
            )
            if (hasChannelCache) {
                Log.i(TAG, "bootstrap: painted ${cachedChannels.size} cached channels")
                AppLaunchTrace.noteChannels()
                // Start the EPG cache-first paint in parallel so the guide
                // cells light up immediately too, instead of waiting on the
                // channel network refresh.
                loadEpgIfConfigured(saved, coldLaunch = startupRefresh)
            }

            // Freshness gate: within the TTL window, the cached rail is
            // good enough and we skip the channel network round-trip entirely
            // (the EPG cache has its own 30-min TTL).
            val freshChannels = hasChannelCache && channelCacheFresh
            val ageMin = cachedForGate?.let { (System.currentTimeMillis() - it) / 60_000L }
            if (freshChannels && !startupRefresh) {
                Log.i(
                    TAG,
                    "[STARTUP] refresh skipped: large non-Dispatcharr playlist " +
                        "($channelCountForGate channels > $LARGE_PLAYLIST_CHANNELS), channel cache fresh (age ${ageMin}m)",
                )
                return@launch
            }
            if (freshChannels) {
                Log.i(
                    TAG,
                    "[STARTUP] refresh scheduled: cold launch, channel cache fresh (age ${ageMin}m), " +
                        "background refresh after the guide paints (type=${saved.sourceType}, channels=$channelCountForGate)",
                )
                // Behind the cached paint, never ahead of it.
                settleGate.awaitGuidePainted()
            }
            Log.i(
                TAG,
                "[STARTUP] refresh running: cold launch, channels " +
                    (if (!hasChannelCache) "not cached" else if (freshChannels) "cached" else "cache stale (age ${ageMin}m)") +
                    " (type=${saved.sourceType})",
            )

            Log.i(TAG, "bootstrap: refreshing channels (hadCache=$hasChannelCache)")
            repository.refresh(saved).fold(
                onSuccess = { channels ->
                    Log.i(TAG, "bootstrap: refreshed ${channels.size} channels")
                    _state.update {
                        it.copy(
                            phase = Phase.ChannelsReady,
                            channels = channels,
                            isLoading = false,
                            error = null,
                        )
                    }
                    // First time we have channels, kick the EPG load now (if
                    // we'd already done it above from cache, this is a no-op
                    // for fresh-cache cases and a re-trigger for non-cached
                    // cases - loadEpgIfConfigured is idempotent w.r.t. state).
                    if (!hasChannelCache) loadEpgIfConfigured(saved)
                },
                onFailure = { t ->
                    if (hasChannelCache) {
                        // Keep the cached rail visible; surface a soft log but
                        // don't bounce the user to NeedsUrl - they had a
                        // working playlist yesterday, the server is just
                        // unreachable right now.
                        Log.w(TAG, "channel refresh failed; cached rail still visible", t)
                        _state.update { it.copy(isLoading = false) }
                    } else {
                        _state.update {
                            it.copy(
                                phase = Phase.NeedsUrl,
                                isLoading = false,
                                error = "Failed to refresh saved source: ${LogSanitizer.redact(t.message ?: t::class.simpleName ?: "unknown error")}",
                            )
                        }
                    }
                },
            )
        }
    }

    fun onSourceTypeChange(value: SourceType) {
        _state.update { it.copy(sourceType = value, error = null) }
    }
    fun onNameChange(value: String) {
        _state.update { it.copy(name = value, error = null) }
    }
    fun onUrlChange(value: String) {
        _state.update { it.copy(url = value, error = null) }
    }
    fun onLanUrlChange(value: String) {
        _state.update { it.copy(lanUrl = value, error = null) }
    }
    fun onEpgUrlChange(value: String) {
        _state.update { it.copy(epgUrl = value) }
    }
    fun onApiKeyChange(value: String) {
        _state.update { it.copy(apiKey = value, error = null) }
    }
    fun onUsernameChange(value: String) {
        _state.update { it.copy(username = value) }
    }
    fun onPasswordChange(value: String) {
        _state.update { it.copy(password = value) }
    }
    /** Bound to "Fetch On Demand from this playlist" in ConfigureSourceScreen /
     *  EditPlaylistScreen. Threaded into SaveRequest.vodEnabled on submit. */
    fun onVodEnabledChange(value: Boolean) {
        _state.update { it.copy(vodEnabled = value) }
    }

    /** Task #45: DVR onboarding destination draft (Dispatcharr form). */
    fun onDvrDestinationChange(server: Boolean) {
        _state.update { it.copy(dvrDestinationServer = server) }
    }
    /** Bound to the "Guide Days" picker in ConfigureSourceScreen (task
     *  #135). Threaded into SaveRequest.epgRetentionDays on submit. */
    fun onEpgRetentionDaysChange(value: Int) {
        _state.update { it.copy(epgRetentionDays = sanitizeGuideDays(value)) }
    }
    fun onSearchQueryChange(value: String) {
        _state.update { it.copy(searchQuery = value) }
    }
    /**
     * @param persist false for automatic corrections (a stranded selection
     *   landing on the fallback pill) so a transient empty group list cannot
     *   overwrite the user's saved default group. GH #81.
     */
    @JvmOverloads
    fun onGroupSelected(group: String, persist: Boolean = true) {
        _state.update { it.copy(selectedGroup = group) }
        if (!persist) return
        // GH #81: the selection is the app's default group for this playlist and
        // has to survive the process. The RAW token is stored, so the Favorites
        // sentinel round-trips like a provider group name instead of being
        // rebuilt by name at launch (which is what dropped it).
        val playlistId = _state.value.playlist?.id
        if (!playlistId.isNullOrBlank()) {
            viewModelScope.launch { appPreferences.setLiveGroupToken(playlistId, group) }
        }
    }

    /**
     * GH #81: restore the saved Live TV group for [playlistId]. Called once the
     * playlist is active (bootstrap and playlist switch). [knownGroups] is the
     * live group-name list when it is already known, so a group that no longer
     * exists in this playlist falls back to All instead of filtering the guide
     * down to nothing.
     */
    private suspend fun restoreSelectedGroup(playlistId: String, knownGroups: Collection<String>) {
        // GH #81: an explicit "Default Group" setting wins; with nothing set
        // (empty) the last selected group is restored exactly as before.
        val preferred = appPreferences.defaultGroupTokenOnce(playlistId)
        val saved = appPreferences.liveGroupTokenOnce(playlistId)
        val restored = com.aeriotv.android.feature.livetv.launchGroupToken(preferred, saved, knownGroups)
            ?: ALL_GROUPS
        _state.update { if (it.selectedGroup == restored) it else it.copy(selectedGroup = restored) }
    }

    fun onSortModeChange(mode: SortMode) {
        _state.update { it.copy(sortMode = mode) }
    }

    /** Pre-fill an M3U URL pair and immediately load. Debug-only path used by --es intent extras. */
    fun loadFromUrl(url: String, epgUrl: String? = null) {
        _state.update {
            it.copy(
                sourceType = SourceType.M3uUrl,
                url = url,
                epgUrl = epgUrl.orEmpty(),
                error = null,
            )
        }
        loadPlaylist()
    }

    /** Debug-only Dispatcharr auto-load to bypass keyboard typing on emulators. */
    fun loadFromDispatcharr(url: String, apiKey: String) {
        _state.update {
            it.copy(
                sourceType = SourceType.DispatcharrApiKey,
                url = url,
                apiKey = apiKey,
                error = null,
            )
        }
        loadPlaylist()
    }

    fun loadPlaylist() {
        val s = _state.value
        if (s.url.trim().isEmpty()) {
            _state.update { it.copy(error = "Enter a URL") }
            return
        }
        // Auto-prepend the scheme so users can type "dispatcharr.example.com"
        // instead of "https://dispatcharr.example.com" -- the bare-host case
        // is the overwhelmingly common typing pattern, and 99% of the field
        // population is dictated by what the user copy-pastes from their
        // server admin who almost always omits the scheme. LAN-shaped hosts
        // (192.168 / 10 / 172.16-31 / *.local) get http:// since home
        // servers usually don't terminate TLS; everything else gets https://.
        val url = normalizeSchemedUrl(s.url)
        if (!s.sourceType.isImplemented) {
            _state.update {
                it.copy(error = "${s.sourceType.displayName} support is coming in a later phase.")
            }
            return
        }
        // Dispatcharr takes EITHER an API key OR a username + password.
        // Derive the effective source type from whichever the user actually
        // supplied, so a stale/mis-set auth toggle can't reject a valid
        // credential (the "2 fields need attention" + "had to use user/pass"
        // bug). Whichever is present wins; API key takes precedence if both.
        val effectiveSourceType: SourceType = when (s.sourceType) {
            SourceType.DispatcharrApiKey, SourceType.DispatcharrUserPass -> {
                val hasApiKey = s.apiKey.isNotBlank()
                val hasUserPass = s.username.isNotBlank() && s.password.isNotBlank()
                when {
                    hasApiKey -> SourceType.DispatcharrApiKey
                    hasUserPass -> SourceType.DispatcharrUserPass
                    else -> {
                        _state.update { it.copy(error = "Enter an API key, or a username and password.") }
                        return
                    }
                }
            }
            else -> s.sourceType
        }
        if (s.sourceType == SourceType.XtreamCodes &&
            (s.username.isBlank() || s.password.isBlank())) {
            _state.update { it.copy(error = "Username and password are required") }
            return
        }
        // EPG URL gets the same scheme-normalization as the server URL.
        val epgUrl = s.epgUrl.trim().takeIf { it.isNotEmpty() }?.let { normalizeSchemedUrl(it) }
        // LAN URL too -- typing "192.168.1.50:9191" should land as
        // "http://192.168.1.50:9191" automatically.
        val lanUrl = s.lanUrl.trim().takeIf { it.isNotEmpty() }?.let { normalizeSchemedUrl(it) }

        viewModelScope.launch {
            _state.update { it.copy(isLoading = true, error = null) }
            val request = PlaylistRepository.SaveRequest(
                sourceType = effectiveSourceType,
                name = s.name.trim().ifBlank { null },
                url = url,
                lanUrl = lanUrl,
                epgUrl = epgUrl,
                apiKey = s.apiKey.trim().ifBlank { null },
                username = s.username.trim().ifBlank { null },
                password = s.password.ifBlank { null },
                vodEnabled = s.vodEnabled,
                epgRetentionDays = s.epgRetentionDays,
            )
            repository.loadAndPersist(request, existingId = s.draftPlaylistId).fold(
                onSuccess = { (entity, channels) ->
                    _state.update {
                        it.copy(
                            phase = Phase.ChannelsReady,
                            playlist = entity,
                            // Remember THIS draft's row so a re-test edits it
                            // instead of duplicating; never the active playlist.
                            draftPlaylistId = entity.id,
                            channels = channels,
                            isLoading = false,
                            error = if (channels.isEmpty()) "No channels found." else null,
                        )
                    }
                    loadEpgIfConfigured(entity)
                    // Task #45 DVR onboarding step: commit the destination
                    // draft now that the Dispatcharr add actually succeeded
                    // (iOS persists on Save; backing out never writes).
                    if (effectiveSourceType == SourceType.DispatcharrApiKey ||
                        effectiveSourceType == SourceType.DispatcharrUserPass
                    ) {
                        appPreferences.setDvrDefaultDestination(
                            if (s.dvrDestinationServer) "server" else "local",
                        )
                    }
                    // One-shot: advance the add flow even when phase was already
                    // ChannelsReady (second-playlist add). Skip on an empty result
                    // so the "No channels found." error stays visible.
                    if (channels.isNotEmpty()) _sourceConfigured.tryEmit(Unit)
                },
                onFailure = { t ->
                    _state.update {
                        it.copy(
                            isLoading = false,
                            channels = emptyList(),
                            error = loadFailureMessage("Failed to load", t),
                        )
                    }
                },
            )
        }
    }

    /**
     * User-facing message for a failed load/save. OutOfMemoryError gets a
     * plain-language message instead of the raw ART allocation string: a
     * giant playlist (an XC panel's get.php m3u_plus dumping its whole VOD
     * catalog) can exhaust a 256MB-heap TV box during parse, and "Failed to
     * allocate a 103877413 byte allocation..." reads like a crash, not
     * guidance (Discord report, Onn 4K, 2026-07-29).
     */
    private fun loadFailureMessage(prefix: String, t: Throwable): String =
        if (t is OutOfMemoryError) {
            "$prefix: playlist is too large for this device's memory. If this is an " +
                "Xtream Codes get.php link, add it with the Xtream Codes source type instead."
        } else {
            "$prefix: ${LogSanitizer.redact(t.message ?: t::class.simpleName ?: "unknown error")}"
        }

    private fun loadEpgIfConfigured(
        playlist: PlaylistEntity,
        forceRefresh: Boolean = false,
        coldLaunch: Boolean = false,
    ) {
        viewModelScope.launch {
            coroutineContext[kotlinx.coroutines.Job]?.let { trackPlaylistTask(playlist.id, "EPG load", it) }
            doLoadEpg(playlist, forceRefresh, coldLaunch)
            // doLoadEpg rebuilds the catalog on every path that has rows; the
            // fallback covers a failed fetch over a history-only cache.
            if (_state.value.epgByChannel !is com.aeriotv.android.core.guide.GuideCatalog) {
                rebuildGuideCatalog(playlist, "history")
            }
            // Belt and braces for the early-return paths inside doLoadEpg (no
            // EPG configured, read threw): the signal is sticky, so a second
            // call after the paint already announced it is a no-op, and the
            // other sections never sit out the 12 s cap for nothing.
            settleGate.noteGuidePainted()
        }
    }

    /**
     * Catch-up (task #135): deferred second-pass load of ALREADY-AIRED guide
     * rows, kept out of [doLoadEpg]'s critical path so cold-launch paint keeps
     * its cheap now-1h..+window read. The EPG cache retains up to the
     * playlist's epgRetentionDays of ended programmes (see
     * PlaylistRepository.saveEpgToCache); this merges them into
     * [PlaylistUiState.epgByChannel] once the live grid is up, then widens
     * [PlaylistUiState.epgHistoryHours] so the guide grid extends its
     * back-scroll window to match. Dedup by (channel, start) keeps the edge
     * where the fresh feed still overlaps history from doubling cells.
     */
    /**
     * The ONLY way guide state is installed (guide rebuild, phase 2): read the
     * retention window plus the forward window from Room and build a
     * [com.aeriotv.android.core.guide.GuideCatalog] once. Fetch, cached paint,
     * category enrichment and history all write to Room and then call this,
     * so every path produces the same guide for the same cache. Unchanged
     * channels keep their previous list instance (no recomposition).
     */
    /** Guide jump: how far forward the catalog has been asked to cover (ms); 0 = default window. */
    private var guideForwardThroughMs = 0L
    private var guideForwardFetchedThroughMs = 0L
    private var guideForwardJob: kotlinx.coroutines.Job? = null

    /**
     * Guide jump: how far BACK the catalog has been asked to cover (absolute
     * ms; 0 = default window). Counterpart to [guideForwardThroughMs], added
     * with the lazy launch window below so a backward jump can widen the
     * catalog the same way a forward one does.
     */
    private var guideBackThroughMs = 0L

    /**
     * Days either side of now the catalog covers at launch.
     *
     * Measured 2026-09-12 (gtvlogs/session5.txt line 142506, nplogs line
     * 29688): the old launch path rebuilt the ENTIRE retention window from
     * Room every single launch. On the Google TV Streamer with Guide Days =
     * All Available that is "guide catalog rebuilt (cache): 267051 rows -> 657
     * channels in 72960ms", with the heap climbing to 440 MB and 2-4 s
     * concurrent GCs running back to back for the whole minute (Choreographer
     * "Skipped 171 frames"); the Nothing Phone paid 4930 ms and a 229 MB heap
     * for 160622 rows. Nothing on screen needs more than today, so the catalog
     * now starts at today plus/minus one day and widens on demand through
     * [ensureGuideRange]. The cache is untouched: every cached day is still
     * reachable, it is just not decoded into memory until it is asked for.
     */
    private val guideLaunchSpanDays = 1L

    /**
     * Guide jump-to-day (Apple parity, GuideStore.ensureForwardWindow): make
     * sure the catalog covers [throughMs]. Dispatcharr sources fetch the
     * missing day chunks on demand; every source then rebuilds the catalog
     * with the wider forward edge. Never refetches a day already pulled.
     */
    fun ensureGuideForward(throughMs: Long) = ensureGuideRange(0L, throughMs)

    /**
     * Widen the loaded catalog to cover [fromMs]..[throughMs] (either may be 0
     * to leave that edge alone). Forward days are still fetched from
     * Dispatcharr on demand exactly as before; backward days are always
     * already in Room (retention keeps them), so widening back is a pure
     * re-read. Both edges are hard-bounded by the playlist's Guide Days.
     */
    fun ensureGuideRange(fromMs: Long, throughMs: Long) {
        val playlist = _state.value.playlist ?: return
        val widensBack = fromMs > 0L && (guideBackThroughMs == 0L || fromMs < guideBackThroughMs)
        val widensForward = throughMs > guideForwardThroughMs
        if (!widensBack && !widensForward) return
        if (widensBack) guideBackThroughMs = fromMs
        if (widensForward) guideForwardThroughMs = throughMs
        guideForwardJob?.cancel()
        guideForwardJob = viewModelScope.launch {
            // Logan 2026-09-11: the playlist's Guide Days setting governs the
            // default forward edge (both directions), not the old Settings >
            // Network "Guide Window" preference.
            val windowHours = ((resolveGuideDays(playlist.epgRetentionDays)
                ?: GUIDE_DAYS_ALL_MAX_AHEAD) * 24).coerceAtLeast(24)
            val defaultEnd = System.currentTimeMillis() + windowHours * 3_600_000L
            val from = maxOf(defaultEnd, guideForwardFetchedThroughMs)
            if (throughMs > from) {
                runCatching { repository.fetchDispatcharrGridRange(playlist, from, throughMs) }
                    .onFailure { Log.w(TAG, "guide forward fetch failed", it) }
                guideForwardFetchedThroughMs = throughMs
            }
            rebuildGuideCatalog(playlist, "jump")
        }
    }

    /**
     * The window the catalog should currently span: today plus or minus
     * [guideLaunchSpanDays], widened to whatever the user has jumped or
     * scrolled to, and hard-bounded by the playlist's Guide Days in both
     * directions. Shared by [rebuildGuideCatalog] and the cached paint in
     * [doLoadEpg] so launch performs ONE windowed Room read, not two
     * overlapping ones.
     */
    private fun guideWindow(playlist: PlaylistEntity): Pair<Long, Long> {
        // Guide Days drives history AND forward (Logan 2026-09-11).
        val guideDays = resolveGuideDays(playlist.epgRetentionDays)
        val retentionDays = guideDays ?: GUIDE_DAYS_ALL_MAX_BACK
        val windowHours = ((guideDays ?: GUIDE_DAYS_ALL_MAX_AHEAD) * 24).coerceAtLeast(24)
        val now = System.currentTimeMillis()
        val dayMs = 24L * 60L * 60L * 1000L
        val backBoundMs = now - retentionDays * dayMs
        val forwardBoundMs = now + windowHours * 60L * 60L * 1000L
        val wantedFrom = if (guideBackThroughMs > 0L) {
            minOf(guideBackThroughMs, now - guideLaunchSpanDays * dayMs)
        } else {
            now - guideLaunchSpanDays * dayMs
        }
        val from = maxOf(backBoundMs, wantedFrom)
        val to = minOf(forwardBoundMs, maxOf(now + guideLaunchSpanDays * dayMs, guideForwardThroughMs))
        return from to to
    }

    /**
     * @param preloadedRows rows the caller has ALREADY read for exactly this
     * window (the cached paint), so the launch path does not re-query Room for
     * data it is holding.
     */
    private suspend fun rebuildGuideCatalog(
        playlist: PlaylistEntity,
        reason: String,
        preloadedRows: List<EPGProgramme>? = null,
    ) {
        val channels = _state.value.channels
        if (channels.isEmpty()) {
            // Used to return silently: a cached paint that ran before the
            // channels landed left the guide with no catalog (filler rows)
            // until a manual refresh. Re-run once channels arrive.
            pendingCatalogRebuild = playlist.id
            Log.i(TAG, "guide catalog rebuild ($reason) deferred: no channels yet")
            return
        }
        val (fromMillis, toMillis) = guideWindow(playlist)
        val t0 = android.os.SystemClock.elapsedRealtime()
        val rows = preloadedRows
            ?: runCatching { repository.loadCachedEpg(playlist.id, fromMillis, toMillis) }
                .onFailure { Log.w(TAG, "rebuildGuideCatalog($reason): cache read failed", it) }
                .getOrDefault(emptyList())
        val previous = _state.value.epgByChannel as? com.aeriotv.android.core.guide.GuideCatalog
        val catalog = withContext(Dispatchers.Default) {
            com.aeriotv.android.core.guide.GuideCatalog.build(
                channels, rows, fromMillis, toMillis, previous = previous,
            )
        }
        epgWriteMutex.withLock {
            val retentionDays = resolveGuideDays(playlist.epgRetentionDays) ?: GUIDE_DAYS_ALL_MAX_BACK
            _state.update { it.copy(epgByChannel = catalog, epgHistoryHours = retentionDays * 24) }
        }
        Log.i(
            TAG,
            "guide catalog rebuilt ($reason): ${rows.size} rows -> ${catalog.size} channels " +
                "in ${android.os.SystemClock.elapsedRealtime() - t0}ms",
        )
    }

    /**
     * Publish how many whole days either side of now the on-disk cache holds,
     * so Jump To can still offer every cached day now that the catalog only
     * decodes the days in view. Two indexed aggregates; safe to call on every
     * cached paint.
     */
    private suspend fun publishCachedEpgSpan(playlist: PlaylistEntity) {
        val span = runCatching { repository.cachedEpgSpan(playlist.id) }.getOrNull() ?: return
        val now = System.currentTimeMillis()
        val dayMs = 24L * 60L * 60L * 1000L
        val back = (((now - span.first) + dayMs - 1) / dayMs).toInt().coerceAtLeast(0)
        val ahead = (((span.second - now) + dayMs - 1) / dayMs).toInt().coerceAtLeast(0)
        _state.update {
            if (it.epgCachedDaysBack == back && it.epgCachedDaysAhead == ahead) it
            else it.copy(epgCachedDaysBack = back, epgCachedDaysAhead = ahead)
        }
    }

    private suspend fun mergeEpgHistory(playlist: PlaylistEntity) {
        // History lives in Room; the catalog build already spans the whole
        // retention window, so "merging history" is just a rebuild.
        rebuildGuideCatalog(playlist, "history")
    }

    /**
     * EPG load body. Returns Result.success(programme count) / Result.failure
     * on a network outcome, or null on the early exits (no EPG configured,
     * cache still fresh) so [refreshEpg] can surface per-action feedback.
     * Every other caller goes through the fire-and-forget
     * [loadEpgIfConfigured] wrapper and ignores the return.
     */
    private suspend fun doLoadEpg(
        playlist: PlaylistEntity,
        forceRefresh: Boolean,
        /** GH #124: cold launch. Paint the cache, then refresh behind it even
         *  when the cache is inside its TTL (no coverage purge, unlike force). */
        coldLaunch: Boolean = false,
    ): Result<Int>? {
        val sourceType = SourceType.entries.firstOrNull { it.name == playlist.sourceType }
            ?: SourceType.M3uUrl
        // M3uUrl only loads EPG when user provided an XMLTV URL. Dispatcharr derives one
        // from the base URL automatically.
        val willHaveEpg = when (sourceType) {
            SourceType.M3uUrl -> !playlist.epgUrl.isNullOrBlank()
            SourceType.DispatcharrApiKey, SourceType.DispatcharrUserPass -> true
            SourceType.XtreamCodes -> !playlist.username.isNullOrBlank()
        }
        if (!willHaveEpg) {
            Log.i(TAG, "loadEpgIfConfigured: no EPG for sourceType=${playlist.sourceType}")
            return null
        }
        // 1. Paint the disk cache immediately (iOS GuideStore parity) so the
        // guide + now-playing are never blank on relaunch while the network
        // fetch runs. Cache is keyed per source (playlist id).
        // iOS parity (EPGGuideView.swift lines 1395-1414): rewrite each
        // programme's raw `channel="..."` attribute to the canonical key
        // its M3UChannel will look up under, so Dispatcharr `/output/epg`
        // (channel-number keyed) and Dummy EPG feeds (UUID keyed) populate
        // the rail even when `tvgID` is blank. See ChannelEpgKey.kt.
        val channelsForBridge = _state.value.channels
        // iOS GuideStore.loadFromCache predicate (P1 #5): only load
        // programmes whose airing overlaps the guide window (now-1h ..
        // now + the playlist's Guide Days). On a 7-day, 58K-row cache a
        // narrow first read drops most rows before they hit the bridge /
        // dedup / group pipeline, cutting cold-launch CPU + GC by a similar
        // fraction. Logan 2026-09-11: the span comes from the playlist's
        // Guide Days setting, not the retired Settings > Network preference.
        //
        // Launch paints a QUICK window first (what the guide shows on its
        // first frame), then [rebuildGuideCatalog] widens to the full
        // [guideWindow] in the background. The single now-1d..now+1d read that
        // replaced the old quick pass (9be8071) is ~5x the rows: on a Shield
        // with 1401 channels it returned 133297 programmes in 18.7 s, and the
        // guide was blank for all of it.
        val (cacheFromMs, cacheToMs) = guideWindow(playlist)
        val launchNowMs = System.currentTimeMillis()
        val quickFromMs = maxOf(cacheFromMs, launchNowMs - QUICK_PAINT_BACK_MS)
        val quickToMs = minOf(cacheToMs, launchNowMs + QUICK_PAINT_AHEAD_MS)
        val readStartedAt = android.os.SystemClock.elapsedRealtime()
        val cachedRaw = runCatching {
            repository.loadCachedEpg(playlist.id, quickFromMs, quickToMs)
        }.getOrDefault(emptyList())
        val readMs = android.os.SystemClock.elapsedRealtime() - readStartedAt
        // Off-main, same reason as the network path below: on a 30-day Guide
        // Days setting this is effectively the entire cache, which catch-up
        // depth grew to six figures.
        val channelsNowCached = _state.value.channels
        val bridgeStartedAt = android.os.SystemClock.elapsedRealtime()
        val cached = withContext(Dispatchers.Default) {
            bridgeChannelIds(cachedRaw, channelsForBridge)
        }
        val bridgeMs = android.os.SystemClock.elapsedRealtime() - bridgeStartedAt
        val hasCache = cached.isNotEmpty()
        // Identity gate: a cache that does not match the current channel
        // identity is stale regardless of age. Rows are persisted under each
        // channel's canonical guideMatchKey, so when the current channels'
        // canonical keys barely intersect the cached keys (key derivation
        // changed between builds, playlist re-keyed), the freshness TTL below
        // must not skip the network: the cached rows are orphans no channel
        // will ever look up, and the guide renders blank while reading as
        // "fresh". Judged only when both sides are non-empty; an empty channel
        // list (still hydrating) or an empty cache proves nothing about
        // identity. In-memory pass over what loadCachedEpg already returned
        // and the bridge that was built anyway; no extra queries.
        // Identity-hash staleness (docs/guide-semantics.md section 4): a
        // different set of loaded canonical ids means the cache was built for
        // a different channel list -> refetch. Same set -> paint from cache and
        // let the age rule decide. Replaces the old "fewer than 20 % of cached
        // keys match" ratio, which fired on every launch of a merged playlist
        // and again mid-session after layering landed.
        val identityHash = com.aeriotv.android.core.guide.GuideIdentityHash.of(channelsForBridge.distinctBy { it.url })
        val storedHash = appPreferences.epgIdentityHash(playlist.id).first()
        val identityStale = hasCache && channelsForBridge.isNotEmpty() && storedHash != identityHash
        // Rows painted from a stale-identity cache before the purge below.
        var identityPainted = 0
        if (identityStale) {
            Log.w(
                TAG,
                "loadEpgIfConfigured: cached EPG keys do not match current channel " +
                    "identity (stored=${storedHash.take(8)} current=${identityHash.take(8)} " +
                    "channels=${channelsForBridge.size}); treating cache as stale and refetching",
            )
            // Paint what is still unambiguous BEFORE the purge. The identity
            // hash also covers each channel's guide key (Dispatcharr's EPGData
            // tvg_id, which re-keys whenever the epgdata/sources lookups fail
            // or the server re-matches EPG), but rows the fetch path wrote
            // under a CANONICAL id (disp:<uuid>, m3u:<url hash>) are keyed to
            // the channel itself and cannot land on the wrong one. Without
            // this the guide sat blank, with no spinner (hasCache is true),
            // for the whole purge plus refetch: 33 s + 5 s on a Shield with
            // 1401 channels.
            val canonicalIds = channelsForBridge.mapTo(HashSet()) { it.guideChannelId().value }
            val unambiguous = cachedRaw.filter { it.channelId in canonicalIds }
            if (unambiguous.isNotEmpty()) {
                rebuildGuideCatalog(playlist, "cache-identity", preloadedRows = unambiguous)
                identityPainted = unambiguous.size
                Log.i(TAG, "loadEpgIfConfigured: painted $identityPainted canonically keyed programmes before the identity purge")
            }
            // Cache-identity rule: rows keyed to a channel identity that no
            // longer exists are orphans no channel will ever look up, so they
            // are dropped outright rather than painted, AND the grid coverage
            // map goes with them -- a surviving coverage row would tell the
            // incremental grid walk those chunks are already cached and the
            // guide would never refill.
            runCatching { repository.purgeEpgCache(playlist.id) }
                .onFailure { Log.w(TAG, "identity purge failed", it) }
        }
        if (hasCache && !identityStale) {
            Log.i(
                TAG,
                "loadEpgIfConfigured: painted ${cached.size} cached programmes " +
                    "(read ${readMs}ms, bridge ${bridgeMs}ms)",
            )
            // Quick paint over the rows just read, then widen to the full
            // window off the critical path. Unchanged channels keep their list
            // instances across the two builds (GuideCatalog previous=).
            rebuildGuideCatalog(playlist, "cache-quick", preloadedRows = cached)
            _state.update { it.copy(isEpgLoading = false) }
            AppLaunchTrace.noteGuidePrograms(cached.size)
            publishCachedEpgSpan(playlist)
            viewModelScope.launch { rebuildGuideCatalog(playlist, "cache") }
        }
        // Release the other sections' cached restores whether or not there WAS
        // a cache to paint: a fresh install has no guide rows, and On Demand
        // must not sit behind a paint that is never coming.
        settleGate.noteGuidePainted()
        // Catch-up reach prune (Logan 2026-09-12): once the cached guide has
        // painted, delete the history no channel can replay any more. The
        // repository runs it on its low-priority EPG dispatcher and once per
        // process per playlist, so it never competes with the first frame of
        // the guide or of a tune.
        repository.startCatchupReachPruneAfterGuidePainted(playlist.id) {
            settleGate.awaitGuidePainted()
        }
        // 2. Freshness: skip the network entirely when the cache is recent,
        // unless the caller forced a refresh (e.g. Refresh Playlist).
        // A cache written by a build with a known cache-corrupting defect must
        // not be trusted no matter how recent it is. The 0.4.10 per-source
        // merge (see EpgProgrammeDao.mergeForPlaylist) let each upstream feed
        // delete the previous one's present+future; the survivor was still
        // inside the TTL, so the network was skipped on every relaunch and the
        // guide never healed - history only, nothing at or after "now".
        //
        // Deliberately NOT a heuristic. "Does the cache reach past now?" was
        // tried and is unusable: a single channel with forward data satisfies
        // it while hundreds have none, which is exactly the poisoned shape.
        // One stamped refetch per epoch bump is deterministic and verifiable.
        // Per-playlist (0.4.11 review fix): the cache is per-playlist, so a
        // global stamp let the active playlist's refetch "clear" every OTHER
        // playlist's still-poisoned cache; switching to a second playlist
        // inside its freshness TTL trusted the poisoned rows. Each playlist
        // now proves ITS OWN cache was rebuilt (old global stamps read as 0
        // here, which forces exactly the one refetch those playlists need).
        val cacheEpoch = runCatching { appPreferences.epgCacheEpochFor(playlist.id) }.getOrDefault(0)
        val staleEpoch = cacheEpoch < EPG_CACHE_EPOCH
        if (staleEpoch) {
            Log.w(
                TAG,
                "loadEpgIfConfigured: cache epoch $cacheEpoch < $EPG_CACHE_EPOCH " +
                    "(written by a build with a known EPG cache defect); forcing one refetch",
            )
        }
        if (!forceRefresh && !staleEpoch && !identityStale) {
            val newest = runCatching { repository.newestEpgFetch(playlist.id) }.getOrNull()
            val fresh = newest != null &&
                (System.currentTimeMillis() - newest) < EPG_CACHE_TTL_MS
            if (fresh && coldLaunch && hasCache) {
                Log.i(TAG, "[STARTUP] refresh running: cold launch, guide cache fresh, background guide refresh (type=${playlist.sourceType})")
            } else if (fresh) {
                Log.i(TAG, "loadEpgIfConfigured: cache fresh, skipping network")
                _state.update { it.copy(isEpgLoading = false) }
                return null
            }
        }
        // 3. Stale / forced / first-ever launch -> network. Only show the
        // spinner when there is nothing cached to display yet.
        Log.i(TAG, "loadEpgIfConfigured: fetching EPG for ${playlist.sourceType} (force=$forceRefresh, hadCache=$hasCache)")
        // A forced reload (Refresh on Edit Playlist, Refresh EPG Data, Refresh
        // Everything) means "get fresh guide data": forget which one-day grid
        // chunks are covered so the incremental walk fetches all of them again.
        // The programmes themselves stay put here so the catch-up archive
        // survives a plain Refresh; refreshEpg purges those separately.
        if (forceRefresh) {
            runCatching { repository.purgeEpgCoverage(playlist.id) }
                .onFailure { Log.w(TAG, "purgeEpgCoverage failed", it) }
        }
        if (!hasCache || (identityStale && identityPainted == 0)) _state.update { it.copy(isEpgLoading = true) }
        // iOS GuideStore audit P3 #13: pass the candidate-key set so the
        // XMLTV parser can drop any programme whose `channel="..."`
        // attribute will never match a M3UChannel before allocating an
        // EPGProgramme. For a 7000-channel guide that the user only has
        // 700 active channels for, this trims ~90% of in-parse allocations
        // -- the same speedup the windowed cache load (P1 #5) gives the
        // downstream pipeline, but applied to fresh network fetches too.
        val knownKeys = buildChannelEpgKeyBridge(_state.value.channels).keys
        return repository.loadEpg(playlist, knownKeys).fold(
            onSuccess = { rawProgrammes ->
                // Channels may have arrived between the cache-paint above
                // and the network fetch; re-read so we bridge against the
                // freshest channel set.
                //
                // OFF-MAIN (0.4.3): loadEpg parses on Dispatchers.Default but
                // RETURNS to this caller's context, which is viewModelScope =
                // Main. Bridging + grouping + placeholder-filling a Dispatcharr
                // grid (~6k rows) was survivable there; once catch-up depth
                // layers the server's upstream XMLTV sources the same transform
                // runs over ~139k rows, and a Google TV Streamer froze its UI
                // for 30-35s at a time (Choreographer "Skipped 2111 frames",
                // Davey duration=35250ms). None of this touches UI state, so
                // it belongs on Default; only the _state.update stays here
                // (MutableStateFlow.update is thread-safe either way).
                val channelsNow = _state.value.channels
                // Same degenerate-programme rule the persistence chokepoint
                // applies (EpgProgrammeDao, >= 30s), so the in-memory guide and
                // the DB always see the same set.
                val programmes = withContext(Dispatchers.Default) {
                    bridgeChannelIds(rawProgrammes, channelsNow)
                        .filter { it.endMillis - it.startMillis >= 30_000L }
                }
                Log.i(TAG, "EPG loaded: ${programmes.size} programmes")
                // Stamp the cache with the identity it was built for (see identityStale).
                runCatching { appPreferences.setEpgIdentityHash(playlist.id, com.aeriotv.android.core.guide.GuideIdentityHash.of(channelsNow.distinctBy { it.url })) }
                // A fetch that yields ZERO programmes is a FAILED fetch, not an
                // empty guide, and it must not be allowed to overwrite anything.
                // Installing it wiped the 6,916 rows the cached paint had just
                // put on screen -- Logan's "the full guide shows for a second at
                // launch and then disappears" (Streamer, 2026-08-20) -- and the
                // save below then wrote the empty set OVER the good on-disk
                // cache and stamped the epoch clean, so the next launch had
                // nothing to paint either. One bad response from the server
                // (hiccup, expired token, an IP ban answering 200 with no rows)
                // took out the guide until a later fetch happened to succeed.
                // Keep what we have; a real guide will arrive on the next
                // refresh, and the cache stays intact meanwhile.
                if (programmes.isEmpty()) {
                    Log.w(
                        TAG,
                        "EPG fetch returned 0 programmes - keeping the existing " +
                            "guide and cache (treating as a failed fetch)",
                    )
                    _state.update { it.copy(isEpgLoading = false) }
                    return@fold Result.failure(
                        IllegalStateException("EPG fetch returned no programmes"),
                    )
                }
                // Persist the fresh guide so the next launch is instant.
                // Re-stamp the cache generation only HERE, on a SUCCESSFUL
                // network fetch: a failed one must leave the old epoch alone
                // so the next launch retries instead of trusting a cache the
                // bump exists to distrust. Without this the epoch check turns
                // into a refetch-on-every-launch loop (observed on the TV
                // emulator: three cold starts, three full fetches).
                // Save FIRST, stamp SECOND: the stamp certifies "this
                // playlist's on-disk cache was rebuilt clean", so writing it
                // before (or despite) a failed save would leave poisoned rows
                // behind a clean stamp, the state the epoch exists to detect.
                // Rows go to Room first; the guide is then rebuilt from Room so
                // fetch, cache paint, enrichment and history all install the
                // same way (one deterministic build, no map surgery).
                runCatching { repository.saveEpgToCache(playlist.id, programmes) }
                    .also {
                        rebuildGuideCatalog(playlist, "fetch")
                        _state.update { it.copy(isEpgLoading = false) }
                    }
                    .onSuccess {
                        runCatching {
                            appPreferences.setEpgCacheEpochFor(playlist.id, EPG_CACHE_EPOCH)
                        }
                    }
                    .onFailure { Log.w(TAG, "saveEpgToCache failed", it) }
                // iOS parity: fire-and-forget category enrichment for
                // Dispatcharr's bulk grid (which strips the category).
                // Categories tint in progressively as detail responses
                // land; Live TV cards + Guide cells stay interactive
                // throughout. Mirrors EPGGuideView.swift line 848
                // `Task { await self.enrichDispatcharrCategories(...) }`.
                // viewModelScope (not a child of this suspend call) so the
                // enrichment never blocks refreshEpg's completion signal.
                viewModelScope.launch {
                    val enriched = runCatching {
                        repository.enrichNowPlayingCategories(playlist, programmes)
                    }.onFailure { Log.w(TAG, "category enrichment failed", it) }
                        .getOrDefault(programmes)
                    // Only push an update when enrichment actually changed
                    // something; short-circuits the recompose when the source
                    // already had categories baked in (XMLTV path).
                    if (enriched !== programmes) {
                        runCatching { repository.saveEpgToCache(playlist.id, enriched) }
                            .onFailure { Log.w(TAG, "persisting enriched categories failed", it) }
                        rebuildGuideCatalog(playlist, "enrich")
                        // Keep the cache enriched too so tints survive a relaunch
                        // -- but write ONLY the rows enrichment actually
                        // touched. E-6: this used to hand the whole feed back
                        // to saveEpgToCache, re-writing ~139k rows and four
                        // indexes each, plus a second retention sweep, to
                        // change a category string on a few hundred airing
                        // programmes. enrichNowPlayingCategories returns a
                        // parallel list whose untouched entries are the SAME
                        // instances, so identity picks out the changes for
                        // free.
                        val changedRows = withContext(Dispatchers.Default) {
                            if (enriched.size == programmes.size) {
                                enriched.filterIndexed { i, p -> p !== programmes[i] }
                            } else {
                                enriched
                            }
                        }
                        runCatching { repository.updateEpgRowsInCache(playlist.id, changedRows) }
                            .onFailure { Log.w(TAG, "enriched cache update failed", it) }
                        Log.i(
                            TAG,
                            "EPG enriched: categories backfilled for now-playing programmes " +
                                "(${changedRows.size} of ${enriched.size} rows written)",
                        )
                    }
                }
                Result.success(programmes.size)
            },
            onFailure = { t ->
                Log.w(TAG, "EPG load failed", t)
                // Keep whatever cache we already painted on screen.
                _state.update { it.copy(isEpgLoading = false) }
                Result.failure(t)
            },
        )
    }

    /**
     * iOS GuideStore `mergeProgramInto` mirror. Input is a per-channel
     * start-time-sorted list; walks the list once, collapsing a programme
     * into the previously kept one whenever [isSameAiring] reports the
     * two describe the same airing. O(n) per bucket and allocation-light:
     * a single ArrayList is built only when at least one merge happens.
     */
    private fun dedupSameAiring(sorted: List<EPGProgramme>): List<EPGProgramme> =
        com.aeriotv.android.core.guide.GuideMerge.dedup(sorted)

    /**
     * Catch-up (task #133): resolve a past programme on a catch-up-capable
     * channel to a playable timeshift URL, then hand it to [onResult] on the
     * main thread. Resolution is async (the Dispatcharr path may fetch the
     * user's XC credentials and pre-resolve the session redirect; the XC path
     * may fetch the panel timezone) -- all memoized after the first call.
     */
    fun playCatchup(
        channel: com.aeriotv.android.core.data.M3UChannel,
        programme: com.aeriotv.android.core.data.EPGProgramme,
        onResult: (Result<com.aeriotv.android.core.playback.CatchupPlaybackResolver.Playback>) -> Unit,
    ) {
        viewModelScope.launch {
            val active = repository.activePlaylist()
                ?: return@launch onResult(
                    Result.failure(IllegalStateException("No active playlist")),
                )
            onResult(
                catchupResolver.resolve(
                    playlist = active,
                    channel = channel,
                    startMillis = programme.startMillis,
                    endMillis = programme.endMillis,
                ),
            )
        }
    }

    /**
     * Task #149: mint a fresh native catch-up session for a seek re-tune
     * (programmeStart + floored offset). Suspends; returns the new
     * absolute playback URL or null (the player keeps its current
     * window). Only meaningful when the playing URL is a native
     * /proxy/catchup/ session URL.
     */
    suspend fun remintCatchupSession(
        channelUuid: String,
        currentPlaybackUrl: String,
        absStartMillis: Long,
        programmeEndMillis: Long = 0L,
    ): String? {
        val active = repository.activePlaylist() ?: return null
        return catchupResolver.remintNative(
            playlist = active,
            channelUuid = channelUuid,
            currentPlaybackUrl = currentPlaybackUrl,
            absStartMillis = absStartMillis,
            programmeEndMillis = programmeEndMillis,
        )
    }

    /** Task #183: report the local catch-up playhead / pause state for
     *  the native session in `playbackUrl`. Returns false only when the
     *  server lacks the position endpoint (caller stops reporting). */
    suspend fun reportCatchupPosition(
        playbackUrl: String,
        positionSecs: Double,
        paused: Boolean,
    ): Boolean {
        val active = repository.activePlaylist() ?: return true
        return catchupResolver.reportNativePosition(active, playbackUrl, positionSecs, paused)
    }

    /** Task #149: best-effort revoke of a native catch-up session when
     *  the player closes (frees the server's provider slot early). */
    fun revokeCatchupSession(playbackUrl: String) {
        viewModelScope.launch {
            val active = repository.activePlaylist() ?: return@launch
            catchupResolver.revokeNative(active, playbackUrl)
        }
    }

    /**
     * Re-fetch the active playlist (channels) and follow with EPG. Used by
     * Playlist Detail's "Refresh Playlist" action.
     */
    fun refreshPlaylist() {
        viewModelScope.launch {
            val active = repository.activePlaylist() ?: return@launch
            Log.i(TAG, "refreshPlaylist: re-loading ${active.name}")
            // isLoading stays: the MainScaffold sync pill and the source
            // screens consume it. playlistRefreshStatus is the per-row signal.
            _state.update {
                it.copy(
                    isLoading = true,
                    error = null,
                    playlistRefreshStatus = ActionStatus.Running,
                )
            }
            repository.refresh(active).fold(
                onSuccess = { channels ->
                    // Count goes to the LOG, not only the UI status pill: the
                    // 2026-08 "40 channels" report was undiagnosable because
                    // the size only ever reached the screen.
                    Log.i(TAG, "refreshPlaylist: ${channels.size} channels loaded")
                    // Re-read the persisted row so the detail card's Channels /
                    // Last Connected values go live (the repo just stamped them).
                    val updated = repository.activePlaylist()
                    _state.update {
                        it.copy(
                            channels = channels,
                            isLoading = false,
                            playlist = updated ?: it.playlist,
                            playlistRefreshStatus = ActionStatus.Success(
                                "${channels.size} channels loaded",
                            ),
                            error = if (channels.isEmpty()) "No channels found." else null,
                        )
                    }
                    loadEpgIfConfigured(active, forceRefresh = true)
                },
                onFailure = { t ->
                    Log.w(TAG, "refreshPlaylist failed", t)
                    _state.update {
                        it.copy(
                            isLoading = false,
                            playlistRefreshStatus = ActionStatus.Failure(
                                "Refresh failed: ${LogSanitizer.redact(t.message ?: t::class.simpleName ?: "unknown error")}",
                            ),
                            error = "Refresh failed: ${LogSanitizer.redact(t.message ?: t::class.simpleName ?: "unknown error")}",
                        )
                    }
                },
            )
            refreshActiveRoute()
        }
    }

    /**
     * iOS GuideStore audit P3 #12 minimum-viable port: when the user scrolls
     * the Guide horizontally to within [PREFETCH_TRIGGER_DISTANCE_MS] of the
     * latest cached programme's end time, fire a single forced EPG refresh
     * on the active playlist so the grid stays populated as the user moves
     * forward in time.
     *
     * Why the iOS state machine isn't ported verbatim: iOS prefetches
     * per-channel via a windowed `getUpcomingFor(channelUUID, after, before)`
     * call -- the bulk grid endpoint returns -1h..+24h on every request,
     * regardless of when. Android's `loadEpg` already fetches the entire
     * source-side window in one shot (Dispatcharr grid OR full XMLTV) and
     * the post-P1 #5 windowed cache load is what controls memory pressure.
     * The iOS Rolling Prefetch's circuit-breaker / per-channel serial chain
     * therefore has no direct analog: the unit of fetch is the WHOLE
     * playlist, not the per-channel cell. What remains is the trigger -- the
     * scroll edge that says "user is about to run out of guide" -- which we
     * port here.
     *
     * Single-flight is delegated to the existing inFlightLoads coalescing
     * layer (P1 #6) inside PlaylistRepository.loadEpg: two scroll events
     * within the same fetch window share one round-trip. Debounce is local:
     * we ignore calls within [PREFETCH_COOLDOWN_MS] of the previous trigger
     * so a slow horizontal scroll doesn't fire the worker N times.
     */
    fun maybePrefetchUpcoming(visibleWindowEndMs: Long) {
        val state = _state.value
        val cachedEdge = state.epgByChannel.values
            .asSequence()
            .flatten()
            .maxOfOrNull { it.endMillis }
            ?: return
        if (visibleWindowEndMs < cachedEdge - PREFETCH_TRIGGER_DISTANCE_MS) return
        val now = System.currentTimeMillis()
        if (now - lastPrefetchAt < PREFETCH_COOLDOWN_MS) return
        lastPrefetchAt = now
        viewModelScope.launch {
            val active = repository.activePlaylist() ?: return@launch
            Log.i(
                TAG,
                "maybePrefetchUpcoming: scroll reached cached edge, forcing EPG refresh",
            )
            loadEpgIfConfigured(active, forceRefresh = true)
        }
    }

    private var lastPrefetchAt: Long = 0L

    /**
     * Re-fetch the EPG without re-fetching the channel list. iOS GuideStore
     * audit P2 #11: hard reset semantics. Purges the per-playlist EPG
     * cache row set BEFORE forcing a fresh network fetch, so a corrupt /
     * partial cached batch can't bleed back onto the rail if the user is
     * pressing this button precisely because the cache is misbehaving.
     * Cleared in-memory state stays empty until the fresh fetch lands; on
     * fetch failure the user sees a blank guide briefly (acceptable cost
     * for the hard-reset guarantee) until the next bootstrap repaints.
     */
    fun refreshEpg() {
        viewModelScope.launch {
            val active = repository.activePlaylist() ?: return@launch
            _state.update { it.copy(epgRefreshStatus = ActionStatus.Running) }
            runCatching { repository.purgeEpgCache(active.id) }
                .onFailure { Log.w(TAG, "purgeEpgCache failed", it) }
            epgWriteMutex.withLock { _state.update { it.copy(epgByChannel = emptyMap()) } }
            val outcome = doLoadEpg(active, forceRefresh = true)
            // The purge above dropped retained history too; re-merge whatever
            // survives (nothing on a true clean slate, task #135 semantics:
            // "Refresh EPG Data" is the user's reset-everything hammer).
            if (_state.value.epgByChannel !is com.aeriotv.android.core.guide.GuideCatalog) {
                rebuildGuideCatalog(active, "history")
            }
            // Re-read the row so lastEpgRefreshedAt (stamped in Room by the
            // repo) reaches the detail card's "Last refreshed" footer.
            val updated = repository.activePlaylist()
            _state.update {
                it.copy(
                    playlist = updated ?: it.playlist,
                    epgRefreshStatus = when {
                        outcome == null -> ActionStatus.Failure("No EPG source configured")
                        outcome.isSuccess -> ActionStatus.Success(
                            "EPG updated (${outcome.getOrThrow()} programs)",
                        )
                        else -> ActionStatus.Failure(
                            "EPG refresh failed: ${LogSanitizer.redact(outcome.exceptionOrNull()?.message ?: "unknown error")}",
                        )
                    },
                )
            }
            refreshActiveRoute()
        }
    }

    /**
     * "Refresh Everything" nuclear reset (iOS a039ba71a parity). Strictly
     * more thorough than Refresh Playlist + Refresh EPG Data: it purges the
     * per-playlist EPG cache AND drops the in-memory guide map AND re-fetches
     * channels (so newly-added server channels appear; refresh() also rewrites
     * the channel-snapshot cache) AND force-reloads the guide AND tells
     * OnDemandViewModel to run its existing VOD nuclear reset for the CURRENT
     * (unchanged) active id via [vodResetBus]. Confirmation-gated in the UI,
     * and also auto-invoked by [switchToPlaylist] so every playlist switch
     * gets the same from-scratch reload (maintainer requirement).
     */
    fun refreshEverything() {
        viewModelScope.launch {
            val active = repository.activePlaylist() ?: return@launch
            Log.i(TAG, "refreshEverything: nuking all caches for ${active.name}")
            _state.update {
                it.copy(
                    isLoading = true,
                    error = null,
                    refreshAllStatus = ActionStatus.Running,
                )
            }
            // 1. Purge guide cache (disk) + drop in-memory map, like refreshEpg.
            runCatching { repository.purgeEpgCache(active.id) }
                .onFailure { Log.w(TAG, "refreshEverything: purgeEpgCache failed", it) }
            epgWriteMutex.withLock { _state.update { it.copy(epgByChannel = emptyMap()) } }
            // 2. Signal On Demand to run its nuclear reset (id unchanged, so the
            //    observeActiveId collector won't fire; the bus is the bridge).
            //    The collector deletes THIS playlist's stored VOD catalog and
            //    forces a full sweep of both kinds, so the tabs go to a loading
            //    state and repopulate as pages land.
            vodResetBus.requestReset()
            // 3. Re-fetch channels (refresh() rewrites the snapshot cache too).
            repository.refresh(active).fold(
                onSuccess = { channels ->
                    // See refreshPlaylist: the count must reach the log too.
                    Log.i(TAG, "refreshEverything: ${channels.size} channels reloaded")
                    val updated = repository.activePlaylist()
                    _state.update {
                        it.copy(
                            channels = channels,
                            isLoading = false,
                            playlist = updated ?: it.playlist,
                            refreshAllStatus = ActionStatus.Success(
                                "${channels.size} channels reloaded",
                            ),
                            error = if (channels.isEmpty()) "No channels found." else null,
                        )
                    }
                    // 4. Force-reload the guide from scratch.
                    loadEpgIfConfigured(active, forceRefresh = true)
                },
                onFailure = { t ->
                    Log.w(TAG, "refreshEverything failed", t)
                    _state.update {
                        it.copy(
                            isLoading = false,
                            refreshAllStatus = ActionStatus.Failure(
                                "Refresh failed: ${LogSanitizer.redact(t.message ?: t::class.simpleName ?: "unknown error")}",
                            ),
                            error = "Refresh failed: ${LogSanitizer.redact(t.message ?: t::class.simpleName ?: "unknown error")}",
                        )
                    }
                },
            )
            refreshActiveRoute()
        }
    }

    /**
     * iOS Issue #24: when the app returns to the foreground after a while,
     * refresh the guide if it has gone stale (cached fetch older than
     * [maxAgeMillis], default 30 min) AND nothing is already loading. EPG only
     * -- it does NOT re-pull channels or VOD. Gated on staleness so ordinary
     * app-switching never refetches. A source with no cached guide yet is left
     * to the normal cold-launch load path (no double-fetch).
     */
    fun refreshEpgIfStale(maxAgeMillis: Long = 30L * 60L * 1000L) {
        viewModelScope.launch {
            // A background trim shed the in-memory guide: repaint it from the
            // cache before anything else (the staleness gate below may skip).
            repaintShedGuide("stale-check")
            val s = _state.value
            if (s.isLoading || s.isEpgLoading) return@launch
            val active = repository.activePlaylist() ?: return@launch
            val newest = repository.newestEpgFetch(active.id) ?: return@launch
            val ageMs = System.currentTimeMillis() - newest
            if (ageMs <= maxAgeMillis) return@launch
            Log.i(TAG, "refreshEpgIfStale: guide is ${ageMs / 60000}min old, refreshing on foreground")
            loadEpgIfConfigured(active, forceRefresh = true)
        }
    }

    /**
     * Quiet EPG sweep gate (Logan 2026-09-12). Asks the server whether its EPG
     * sources were re-ingested since the cached guide was stored and, if so,
     * lets the repository sweep the day chunks in the background. Nothing here
     * blocks or clears the cache: the guide keeps painting from it while the
     * sweep quietly replaces one day at a time.
     *
     * Called on a 15 minute foreground tick and on return to the foreground;
     * the repository rate-limits both to one check per 15 minutes per playlist.
     */
    fun checkEpgSourcesForChanges() {
        viewModelScope.launch {
            val active = repository.activePlaylist() ?: return@launch
            runCatching { repository.maybeSweepEpgForSourceChanges(active.id) }
                .onFailure { Log.w(TAG, "checkEpgSourcesForChanges failed: $it") }
        }
    }

    /**
     * Apply user edits to the active playlist. Reuses [PlaylistRepository.loadAndPersist]
     * with `existingId` so the row's UUID stays stable. Mirrors iOS Edit Playlist
     * Save action, connection details + auth credentials + EPG URL can change
     * but the source type does not (iOS gates that too via a separate flow).
     */
    /**
     * Load the Dispatcharr channel profiles for the active playlist so the
     * Edit Playlist screen can render the Channel Profile picker. No-op (and
     * clears any stale list) for non-Dispatcharr sources. Failures leave the
     * list empty so the picker just shows "All Channels".
     */
    fun loadDispatcharrProfiles(playlistId: String? = null) {
        viewModelScope.launch {
            val active = editTarget(playlistId) ?: return@launch
            val sourceType = SourceType.entries.firstOrNull { it.name == active.sourceType }
                ?: SourceType.M3uUrl
            val isDispatcharr = sourceType == SourceType.DispatcharrApiKey ||
                sourceType == SourceType.DispatcharrUserPass
            if (!isDispatcharr) {
                _state.update { it.copy(availableProfiles = emptyList(), profilesLoading = false) }
                return@launch
            }
            _state.update { it.copy(profilesLoading = true) }
            val profiles = runCatching { repository.listChannelProfiles(active) }
                .onFailure { Log.w(TAG, "loadDispatcharrProfiles failed", it) }
                .getOrDefault(emptyList())
            _state.update { it.copy(availableProfiles = profiles, profilesLoading = false) }
        }
    }

    /** The playlist Edit Playlist is editing: [playlistId] when given, else the active one. */
    private suspend fun editTarget(playlistId: String?): PlaylistEntity? =
        playlistId?.let { repository.playlistById(it) } ?: repository.activePlaylist()

    fun saveEdits(
        name: String,
        url: String,
        lanUrl: String?,
        epgUrl: String?,
        apiKey: String?,
        username: String?,
        password: String?,
        dispatcharrProfileId: Int?,
        vodEnabled: Boolean = true,
        epgRetentionDays: Int = 7,
        /**
         * Overrides the stored source type. Only Edit Playlist's Dispatcharr
         * Authentication toggle passes it: flipping between Username &
         * Password and API Key IS a source-type change, and without this the
         * new credentials would be written under the old type and ignored.
         * Null keeps whatever the row already has.
         */
        sourceTypeOverride: SourceType? = null,
        /**
         * Per-playlist Dispatcharr User-Agent (Apple `customUserAgent`).
         * Blank clears the override; null leaves the stored value alone.
         */
        customUserAgent: String? = null,
        /**
         * Called on the main thread when the save settles: null on success, the
         * user-facing failure line otherwise.
         *
         * Edit Playlist used to pop the moment Save was tapped, so a rejected
         * login or a failed channel fetch (both of which restore the previous
         * row, see [PlaylistRepository.loadAndPersist]) looked exactly like
         * "my credentials did not save" with no message anywhere - the error
         * landed in [UiState.error], which that screen never renders. The
         * screen now waits for this and only leaves on success.
         */
        onResult: ((String?) -> Unit)? = null,
        /**
         * The playlist being edited. Null = the active one. Any saved playlist
         * can be edited (owner decision, Settings phase 3); a non-active one
         * stays non-active and never touches the active session state.
         */
        playlistId: String? = null,
    ) {
        viewModelScope.launch {
            // Fresh save, fresh plan: the previous save's rows must not decide
            // this one's (a credential change followed by a rename).
            _savePlan.value = PlaylistRepository.SavePlan(
                stages = listOf(
                    PlaylistRepository.SaveStage.LoadingChannels,
                    PlaylistRepository.SaveStage.Finishing,
                ),
            )
            val active = editTarget(playlistId) ?: run {
                _saveStage.value = null
                _saveHasProgress.value = false
                onResult?.invoke("No playlist loaded.")
                return@launch
            }
            val sourceType = sourceTypeOverride
                ?: SourceType.entries.firstOrNull { it.name == active.sourceType }
                ?: SourceType.M3uUrl
            val request = PlaylistRepository.SaveRequest(
                sourceType = sourceType,
                name = name.ifBlank { null },
                // Scheme-normalize all three URLs so the user can type
                // bare hostnames in Edit Playlist too. Same rules as
                // loadPlaylist() above.
                url = normalizeSchemedUrl(url),
                lanUrl = lanUrl?.trim()?.takeIf { it.isNotEmpty() }?.let { normalizeSchemedUrl(it) },
                epgUrl = epgUrl?.trim()?.takeIf { it.isNotEmpty() }?.let { normalizeSchemedUrl(it) },
                apiKey = apiKey?.trim()?.ifBlank { null },
                username = username?.trim()?.ifBlank { null },
                password = password?.ifBlank { null },
                dispatcharrProfileId = dispatcharrProfileId,
                vodEnabled = vodEnabled,
                epgRetentionDays = sanitizeGuideDays(epgRetentionDays),
                customUserAgent = customUserAgent,
            )
            // What does this edit actually need? A rename, a User-Agent, a LAN
            // URL, an EPG URL, Guide Days or the On Demand toggle change nothing
            // about which channels exist, so they take the instant path: one row
            // UPDATE, no login, no 650-channel fetch, no capability probe, no
            // loading screen. Apple has always worked this way; here the rename
            // was costing 9 to 11 s (Logan, measured 2026-09-18).
            val editPlan = repository.classifyEdit(request, active.id)
            if (editPlan != null && editPlan.instant) {
                _saveHasProgress.value = false
                _saveStage.value = null
                repository.applyInstantEdit(request, active.id, editPlan).fold(
                    onSuccess = { entity ->
                        if (!entity.isActive) {
                            onResult?.invoke(null)
                            return@fold
                        }
                        _state.update { it.copy(playlist = entity, isLoading = false, error = null) }
                        // Guide Days / EPG URL: reload in the BACKGROUND. The
                        // screen has already popped, so nothing waits on it.
                        if (editPlan.reloadGuide) loadEpgIfConfigured(entity, forceRefresh = true)
                        // On Demand ON kicks the ordinary sweep, OFF hides the
                        // catalog: both come from the row this save just wrote,
                        // which OnDemandViewModel collects (vodEnabled gate), so
                        // there is nothing to drive from here.
                        onResult?.invoke(null)
                    },
                    onFailure = { t ->
                        Log.w(TAG, "saveEdits (instant) failed", t)
                        val message = loadFailureMessage("Save failed", t)
                        if (active.isActive) {
                            _state.update { it.copy(playlist = active, isLoading = false, error = message) }
                        }
                        onResult?.invoke(message)
                    },
                )
                return@launch
            }
            // A real network stage from here: the staged screen is honest now.
            _saveHasProgress.value = true
            if (!active.isActive) {
                // Non-active playlist: the network save runs, but the active
                // session's UiState (playlist, channels, guide, VOD) is left
                // alone because none of it belongs to this row.
                repository.loadAndPersist(
                    request,
                    existingId = active.id,
                    onStage = { stage -> _saveStage.value = stage },
                    onPlan = { plan -> _savePlan.value = plan },
                ).fold(
                    onSuccess = {
                        _saveStage.value = null
                        _saveHasProgress.value = false
                        onResult?.invoke(null)
                    },
                    onFailure = { t ->
                        _saveStage.value = null
                        _saveHasProgress.value = false
                        Log.w(TAG, "saveEdits (non-active) failed", t)
                        onResult?.invoke(loadFailureMessage("Save failed", t))
                    },
                )
                return@launch
            }
            _state.update { it.copy(isLoading = true, error = null) }
            // GH #83: Edit Playlist reads state.playlist, so reflect the
            // edited fields there NOW (the repository writes the DB row early
            // too); a failed save puts the previous values back.
            _state.update {
                it.copy(
                    playlist = active.copy(
                        sourceType = sourceType.name,
                        name = request.name ?: active.name,
                        urlString = request.url.trimEnd('/'),
                        lanUrlString = request.lanUrl?.trimEnd('/'),
                        epgUrl = request.epgUrl,
                        apiKey = request.apiKey ?: active.apiKey,
                        username = request.username,
                        password = request.password,
                        dispatcharrProfileId = request.dispatcharrProfileId,
                        vodEnabled = request.vodEnabled,
                        epgRetentionDays = request.epgRetentionDays,
                        customUserAgent = request.customUserAgent ?: active.customUserAgent,
                    ),
                )
            }
            repository.loadAndPersist(
                request,
                existingId = active.id,
                onStage = { stage -> _saveStage.value = stage },
                onPlan = { plan -> _savePlan.value = plan },
            ).fold(
                onSuccess = { (entity, channels) ->
                    _state.update {
                        it.copy(
                            playlist = entity,
                            channels = channels,
                            isLoading = false,
                            error = if (channels.isEmpty()) "No channels found." else null,
                        )
                    }
                    // The account or the address changed on the active playlist,
                    // so its stored On Demand catalog was built as somebody
                    // else: wipe it and re-sweep. Same nuclear path "Refresh
                    // Everything" uses (OnDemandViewModel collects the bus),
                    // and the wait here is only for the FIRST page of each half
                    // the account may view - the uncapped sweep carries on in
                    // the background exactly as it does after an Add.
                    awaitVodRebuild()
                    loadEpgIfConfigured(entity)
                    _saveStage.value = null
                    _saveHasProgress.value = false
                    onResult?.invoke(null)
                },
                onFailure = { t ->
                    // Stage cleared on failure too, so the staged screen gets
                    // out of the way and the form can show Save Failed with the
                    // typed values still in the fields.
                    _saveStage.value = null
                    _saveHasProgress.value = false
                    Log.w(TAG, "saveEdits failed", t)
                    val message = loadFailureMessage("Save failed", t)
                    _state.update {
                        it.copy(
                            playlist = active,
                            isLoading = false,
                            error = message,
                        )
                    }
                    onResult?.invoke(message)
                },
            )
        }
    }

    /**
     * Wipe + rebuild the active playlist's On Demand catalog after a save that
     * changed the account or the address, reporting the two stages the save
     * screen shows while it happens. No-op unless the save decided the rebuild
     * is real (see [PlaylistRepository.SavePlan]).
     *
     * Each half is waited on only to its FIRST stored page (or to a terminal
     * answer: nothing to fetch, permission denied, a failed walk). The sweep is
     * uncapped and can run for minutes; holding the screen for all of it would
     * be a worse bug than the stale catalog, so it is left running in the
     * background exactly as it is after Add Playlist. The timeout is the
     * backstop for a server that answers neither way.
     */
    private suspend fun awaitVodRebuild() {
        val plan = _savePlan.value
        if (!plan.rebuildVod || !(plan.hasMovies || plan.hasSeries)) return
        val token = vodResetBus.requestReset()
        Log.i(TAG_SAVE, "vod rebuild requested token=$token movies=${plan.hasMovies} series=${plan.hasSeries}")
        if (plan.hasMovies) {
            _saveStage.value = PlaylistRepository.SaveStage.LoadingMovies
            awaitVodHalf(token, VodResetBus.Kind.Movies)
        }
        if (plan.hasSeries) {
            _saveStage.value = PlaylistRepository.SaveStage.LoadingSeries
            awaitVodHalf(token, VodResetBus.Kind.Series)
        }
        _saveStage.value = PlaylistRepository.SaveStage.Finishing
    }

    private suspend fun awaitVodHalf(token: Long, kind: VodResetBus.Kind) {
        val startedAt = System.currentTimeMillis()
        val settled = kotlinx.coroutines.withTimeoutOrNull(VOD_REBUILD_STAGE_TIMEOUT_MS) {
            vodResetBus.rebuild.first { it != null && it.token >= token && it.settled(kind) }
        } != null
        // Same shape as the repository's own stage lines, so one AerioSave
        // filter still accounts for the whole save end to end.
        Log.i(
            TAG_SAVE,
            "stage=Loading$kind elapsedMs=${System.currentTimeMillis() - startedAt} " +
                "firstPage=${if (settled) "landed" else "timedOut"}",
        )
    }

    /**
     * Edit Playlist > Refresh Session (Apple parity). Re-mints the Direct
     * Connect JWT pair from the saved username + password and re-reads the
     * account's api_key. Returns the user-facing result line so the caller can
     * show it under the row; true in the pair means "succeeded".
     */
    suspend fun refreshDispatcharrSession(playlistId: String? = null): Pair<Boolean, String> {
        val id = editTarget(playlistId)?.id
            ?: return false to "No playlist loaded."
        return repository.refreshDispatcharrSession(id).fold(
            onSuccess = { rotated ->
                true to if (rotated) "Session refreshed. Cached API key updated."
                else "Session refreshed. API key unchanged."
            },
            onFailure = { t ->
                Log.w(TAG, "refreshDispatcharrSession failed", t)
                false to (t.message ?: "Refresh failed.")
            },
        )
    }

    /**
     * Probe the playlist URL. v1 re-runs the channel fetch as a connectivity
     * test (same code path the bootstrap uses), so success means the source
     * still responds with parseable content. Outcome lands in
     * [UiState.testStatus] for the Playlist Detail row.
     */
    fun testConnection() {
        viewModelScope.launch {
            val active = repository.activePlaylist() ?: return@launch
            Log.i(TAG, "testConnection: probing ${active.urlString}")
            _state.update { it.copy(testStatus = ActionStatus.Running) }
            repository.refresh(active).fold(
                onSuccess = { channels ->
                    Log.i(TAG, "testConnection: ok (${channels.size} channels)")
                    _state.update {
                        it.copy(
                            testStatus = ActionStatus.Success(
                                "Connected OK (${channels.size} channels)",
                            ),
                        )
                    }
                },
                onFailure = { t ->
                    Log.w(TAG, "testConnection failed", t)
                    _state.update {
                        it.copy(
                            testStatus = ActionStatus.Failure(
                                "Connection failed: ${LogSanitizer.redact(t.message ?: t::class.simpleName ?: "unknown error")}",
                            ),
                        )
                    }
                },
            )
            // The probe just resolved a URL; keep the Connection row honest.
            refreshActiveRoute()
        }
    }

    /**
     * Re-resolve which URL [PlaylistRepository.effectiveBaseUrl] would use
     * right now (LAN when the reachability probe says the server answers
     * at the LAN URL, WAN
     * otherwise) so Playlist Detail's Connection row reflects reality. Called
     * on screen entry / ON_RESUME and after each detail action; there is no
     * app-wide network callback, matching the NetworkSettingsScreen idiom.
     */
    fun refreshActiveRoute() {
        viewModelScope.launch {
            val pl = _state.value.playlist ?: return@launch
            val url = repository.effectiveBaseUrl(pl)
            val isLan = !pl.lanUrlString.isNullOrBlank() && url == pl.lanUrlString
            _state.update { it.copy(activeRoute = ActiveRoute(isLan = isLan, url = url)) }
        }
    }

    /** Manual "Refresh LAN Detection" action on Playlist Detail: re-probe
     *  which URL answers and report the outcome inline. The same probe
     *  already runs automatically on entry and ON_RESUME; this row exists
     *  for parity with iOS and for users who just changed networks. */
    fun refreshLanDetection() {
        viewModelScope.launch {
            val pl = _state.value.playlist ?: return@launch
            _state.update { it.copy(lanRefreshStatus = ActionStatus.Running) }
            val url = repository.effectiveBaseUrl(pl)
            val isLan = !pl.lanUrlString.isNullOrBlank() && url == pl.lanUrlString
            _state.update {
                it.copy(
                    activeRoute = ActiveRoute(isLan = isLan, url = url),
                    lanRefreshStatus = ActionStatus.Success(
                        if (isLan) "Local server reachable, using local URL" else "Using remote URL",
                    ),
                )
            }
        }
    }

    /** Reset Playlist Detail's per-action feedback. Called when the screen
     *  leaves composition so stale results don't greet the next visit. */
    fun clearDetailActionStatuses() {
        _state.update {
            it.copy(
                testStatus = ActionStatus.Idle,
                playlistRefreshStatus = ActionStatus.Idle,
                epgRefreshStatus = ActionStatus.Idle,
                refreshAllStatus = ActionStatus.Idle,
                lanRefreshStatus = ActionStatus.Idle,
            )
        }
    }

    /**
     * Observe the full set of saved playlists for the multi-playlist
     * switcher in Settings.
     */
    val allPlaylists: Flow<List<PlaylistEntity>> = repository.observeAll()

    /**
     * The ACTIVE playlist row, observed live from the database.
     *
     * [UiState.playlist] is a SNAPSHOT taken when the state was last written,
     * so anything the app learns about the row afterwards is invisible to it.
     * The per-user Dispatcharr capability probe (AerioCaps) lands seconds after
     * launch and writes the new custom_properties to this row, and MainScaffold
     * decides tab visibility from those flags: reading the snapshot meant a
     * capability the admin had already restored was never seen, and the Movies
     * tab stayed retired with a full 40050-title library sitting in state
     * (Streamer 2026-09-15). Anything that gates UI on a capability must read
     * THIS, not `state.playlist`.
     */
    val activePlaylistLive: Flow<PlaylistEntity?> =
        kotlinx.coroutines.flow.combine(
            repository.observeActiveId(),
            repository.observeAll(),
        ) { id, all -> all.firstOrNull { it.id == id } }
            .distinctUntilChanged()

    /**
     * The id of the ACTIVE playlist, observed live from the database.
     *
     * The playlist picker's selection indicator must follow THIS, never
     * `state.playlist?.id`: the snapshot in [UiState] is only rewritten once
     * [switchToPlaylist] has finished fetching the new playlist's channels
     * (and is never rewritten at all when that fetch fails), so on a phone the
     * radio button stayed on the OLD row for the whole load and sometimes for
     * good (Logan 2026-09-16, Nothing Phone). The DAO flow emits the instant
     * the active row flips.
     */
    val activeIdLive: Flow<String?> = repository.observeActiveId()

    /**
     * Display-only Dispatcharr account facts (echoed username, Channel Profile
     * names) for one playlist, backing the Playlist Detail permissions section.
     * Read-only: this never probes, so an inactive playlist simply shows what
     * the last probe persisted.
     */
    fun dispatcharrAccountFacts(
        playlistId: String,
    ): Flow<com.aeriotv.android.core.preferences.DispatcharrAccountFacts> =
        appPreferences.dispatcharrAccountFacts(playlistId)

    /**
     * GH #81 default group, now owned by Live TV's Manage Groups sheet rather
     * than a Settings picker (Logan 2026-09-17). Same per-playlist preference
     * key Live TV already reads for its launch group, so behavior is unchanged.
     */
    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val defaultGroupToken: StateFlow<String> = activeIdLive
        .flatMapLatest { id: String? ->
            if (id.isNullOrBlank()) kotlinx.coroutines.flow.flowOf("")
            else appPreferences.defaultGroupToken(id)
        }
        .stateIn(
            viewModelScope,
            kotlinx.coroutines.flow.SharingStarted.Eagerly,
            "",
        )

    /**
     * Set (or clear, with a blank token) the group Live TV opens on. Picking
     * Recently Watched also makes it visible, exactly as the old Settings
     * picker did: a default the user cannot see would open on nothing.
     */
    fun setDefaultGroup(token: String) {
        viewModelScope.launch {
            // Read the SAME id [defaultGroupToken] reads (the DAO's active
            // row), not state.playlist: that snapshot lags a playlist switch
            // and is never written at all when the channel fetch fails, so a
            // write could land under the previous playlist's key while the
            // pin read the new one.
            val id = activeIdLive.firstOrNull()
                ?: state.value.playlist?.id
                ?: return@launch
            if (id.isBlank()) return@launch
            val current = appPreferences.defaultGroupTokenOnce(id)
            // Tapping the marked group again clears the default (back to
            // "last used"), which is how Apple's sheet behaves.
            val next = if (current == token) "" else token
            appPreferences.setDefaultGroupToken(id, next)
            if (next == RECENT_GROUP) appPreferences.setRecentGroupVisible(id, true)
        }
    }

    /** Make [playlistId] active and load its channels. Mirrors the bootstrap
     * load-and-render flow, but skipping the JWT exchange the first-load does
     * for User+Pass since the apiKey is already cached on the row. */
    fun switchToPlaylist(playlistId: String) {
        viewModelScope.launch {
            // GH #22: stop whatever the OLD source is still playing (phone
            // mini-player / background audio keeps rolling across a switch;
            // TV already stops on leave). Besides being the right product
            // behavior -- the old source is gone -- this clears the holder's
            // currentChannelId latch so the next tune of a same-id channel
            // (same Dispatcharr server on both playlists) always re-primes
            // instead of being skipped as "already playing".
            runCatching { miniPlayerSession.dismiss() }
            runCatching { exoWindowState.hide() }
            runCatching { exoHolder.stop() }
            _state.update { it.copy(isLoading = true, error = null) }
            repository.switchActive(playlistId).fold(
                onSuccess = { (entity, channels) ->
                    _state.update {
                        it.copy(
                            phase = Phase.ChannelsReady,
                            playlist = entity,
                            channels = channels,
                            isLoading = false,
                            error = if (channels.isEmpty()) "No channels found." else null,
                        )
                    }
                    // GH #81 + per-playlist scoping: group selection belongs to
                    // the playlist, so a switch loads the NEW playlist's saved
                    // group rather than carrying the old one over. A saved group
                    // that no longer exists here falls back to All (keeping it
                    // would filter the guide down to nothing with no visible
                    // reason); synthetic tokens (Favorites, All, collections)
                    // always survive.
                    restoreSelectedGroup(
                        entity.id,
                        channels.asSequence().map { ch -> ch.groupTitle }.filter { g -> g.isNotBlank() }.distinct().toList(),
                    )
                    // A SWITCH NO LONGER PURGES ANYTHING (Logan 2026-09-16).
                    // This used to auto-run refreshEverything(), which purged
                    // the now-active playlist's guide cache and signalled the
                    // VOD nuclear reset, so switching back to a playlist threw
                    // away exactly the caches that make switching back
                    // instant. Every cache stays keyed by playlist id and is
                    // destroyed only when that playlist is deleted.
                    //
                    // The guide loads from this playlist's cache and refreshes
                    // itself on the normal staleness rules; the drop-in
                    // in-memory map from the OLD playlist is cleared first so
                    // the grid never paints the previous source's programmes.
                    epgWriteMutex.withLock { _state.update { st -> st.copy(epgByChannel = emptyMap()) } }
                    loadEpgIfConfigured(entity)
                },
                onFailure = { t ->
                    Log.w(TAG, "switchToPlaylist failed", t)
                    _state.update {
                        it.copy(
                            isLoading = false,
                            error = "Switch failed: ${LogSanitizer.redact(t.message ?: t::class.simpleName ?: "unknown error")}",
                        )
                    }
                },
            )
        }
    }

    /**
     * Re-resolve the active playlist from the database and load it. Used by
     * the Welcome screen after a Drive Sync pull lands new rows -- without
     * this, the UI is still parked on Phase.NeedsUrl from the initial cold
     * launch and the LaunchedEffect that watches `state.phase ==
     * ChannelsReady` for the auto-advance never fires.
     *
     * Returns true when an active playlist was found and queued for load;
     * false when the DB is still empty after the restore (Drive AppData was
     * empty on this account, or only non-playlist categories were pulled).
     */
    suspend fun loadActivePlaylistIfAvailable(): Boolean {
        val active = repository.activePlaylist() ?: return false
        // switchToPlaylist already wraps the full "set active + fetch
        // channels + advance phase + kick EPG" pipeline used elsewhere
        // (manual playlist switch in Settings), so we route through it
        // instead of duplicating the state-machine progression here.
        switchToPlaylist(active.id)
        return true
    }

    /** Persist a user-chosen ordering of playlists (top-to-bottom). Used by
     * the Playlists drag-to-reorder UI. */
    fun applyPlaylistOrder(orderedIds: List<String>) {
        viewModelScope.launch { repository.applyPlaylistOrder(orderedIds) }
    }

    /** GH #129: per-playlist Catch-Up Time Offset (minutes), Edit Playlist. */
    fun catchupTimeOffsetMinutes(playlistId: String): Flow<Int> =
        appPreferences.catchupTimeOffsetMinutes(playlistId)

    /** GH #129: written on pick (Apple @AppStorage parity), not on Save. */
    fun setCatchupTimeOffsetMinutes(playlistId: String, minutes: Int) {
        viewModelScope.launch {
            appPreferences.setCatchupTimeOffsetMinutes(playlistId, minutes)
            Log.i(TAG, "[CATCHUP] time offset set to $minutes min for playlist ${playlistId.take(8)}")
        }
    }

    /** Delete a saved playlist by id. If the deleted row was the active one,
     * fall back to the most-recent remaining playlist (or NeedsUrl if none). */
    fun deletePlaylist(playlistId: String) {
        // Crash guard (Apple d051505 parity): stop every task that holds this
        // playlist BEFORE the row is deleted; none of them may read or write
        // the deleted record afterward.
        com.aeriotv.android.core.data.repository.DeletedPlaylists.mark(playlistId)
        cancelPlaylistTasks(playlistId)
        viewModelScope.launch {
            val wasActive = repository.activePlaylist()?.id == playlistId
            repository.deletePlaylist(playlistId)
            if (wasActive) {
                val remaining = repository.allOnce()
                val next = remaining.firstOrNull()
                if (next == null) {
                    _state.update {
                        it.copy(phase = Phase.NeedsUrl, playlist = null, channels = emptyList())
                    }
                } else {
                    switchToPlaylist(next.id)
                }
            }
        }
    }

    fun clearPlaylist() {
        viewModelScope.launch {
            repository.clear()
            _state.update { UiState(phase = Phase.NeedsUrl) }
        }
    }

    /**
     * Player "Switch Stream" (Dispatcharr Direct Connect): the active channel's
     * member streams with quality stats. [channelIntPk] is
     * M3UChannel.dispatcharrChannelId. Returns empty on any failure or a
     * non-Dispatcharr source so the sheet simply shows the empty state.
     */
    suspend fun loadChannelStreams(
        channelIntPk: Int,
    ): List<com.aeriotv.android.core.network.DispatcharrChannelStream> =
        runCatching { repository.listDispatcharrChannelStreams(channelIntPk) }
            .getOrDefault(emptyList())

    /**
     * Mark as Radio Channel / Unmark Radio Channel (admin, Direct Connect).
     * On 2xx the channel in [state] flips at once (and the player's declared
     * set), so the menu wording and the next pick follow without a refresh.
     */
    suspend fun setChannelRadio(channel: M3UChannel, isRadio: Boolean): Result<Unit> =
        runCatching { repository.setDispatcharrChannelRadio(channel, isRadio) }.map {
            com.aeriotv.android.core.playback.DeclaredRadioChannels.set(channel.id, isRadio)
            _state.update { s ->
                s.copy(channels = s.channels.map { if (it.id == channel.id) it.copy(isRadio = isRadio) else it })
            }
        }

    /** Menu entry for [setChannelRadio]: fire and forget, [onError] on failure. */
    fun toggleChannelRadio(channel: M3UChannel, isRadio: Boolean, onError: (Throwable) -> Unit) {
        viewModelScope.launch {
            setChannelRadio(channel, isRadio).onFailure(onError)
        }
    }

    /** Switch Stream reorder (admin). Result failure carries the exception. */
    suspend fun saveChannelStreamOrder(channelIntPk: Int, streamIds: List<Int>): Result<Unit> =
        runCatching { repository.saveDispatcharrChannelStreamOrder(channelIntPk, streamIds) }

    /**
     * Playlist detail opened on the ACTIVE playlist: re-read its permissions
     * at most once a minute (the same floor as a return to foreground), so
     * the User Permissions block is never minutes stale. The block reads the
     * DAO row, so the fresh answer lands on screen without a reload.
     */
    fun refreshPermissionsForDetail() {
        viewModelScope.launch {
            runCatching {
                repository.probeAllCapabilities(
                    trigger = "playlist detail",
                    minIntervalMs = 60_000L,
                )
            }
        }
    }

    private val _permissionsRefreshing = kotlinx.coroutines.flow.MutableStateFlow(false)
    /** True while the playlist page's "Refresh Permissions" probe runs. */
    val permissionsRefreshing: kotlinx.coroutines.flow.StateFlow<Boolean> = _permissionsRefreshing

    /** Playlist page "Refresh Permissions": probe the active playlist now,
     *  no throttle (Apple ServerDetailView.refreshPermissions parity). */
    fun refreshPermissionsNow() {
        if (_permissionsRefreshing.value) return
        _permissionsRefreshing.value = true
        viewModelScope.launch {
            try {
                runCatching {
                    repository.probeAllCapabilities(force = true, trigger = "manual refresh")
                }
            } finally {
                _permissionsRefreshing.value = false
            }
        }
    }

    /** Re-read the user level now (Switch Stream open / reorder save / 403)
     *  and return the fresh Switch Stream gate; false when unknown. */
    suspend fun recheckSwitchStreamAllowed(trigger: String): Boolean =
        runCatching { repository.recheckSwitchStreamAllowed(trigger) }.getOrDefault(false)

    /** M3U account id -> source name, to label Switch Stream rows with their M3U.
     *  Empty on failure / non-Dispatcharr (the source label is then omitted). */
    suspend fun loadM3uAccountNames(): Map<Int, String> =
        runCatching { repository.dispatcharrM3uAccountNames() }.getOrDefault(emptyMap())

    /**
     * Player "Switch Stream": ask Dispatcharr to switch the channel's active
     * upstream to [streamId] (a Stream pk). [channelUuid] is M3UChannel.id minus
     * the "disp:" prefix. Result so the caller can Toast success/failure.
     */
    /** Switch the upstream; Result carries the resolved upstream URL (re-prime gate). */
    suspend fun switchChannelStream(channelUuid: String, streamId: Int): Result<String?> =
        runCatching { repository.switchDispatcharrStream(channelUuid, streamId) }

    /** Currently-active stream pk for the Switch Stream sheet's radio mark. */
    suspend fun loadCurrentStreamId(channelUuid: String): Int? =
        runCatching { repository.currentDispatcharrStreamId(channelUuid) }.getOrNull()

    /** Currently-active upstream URL (re-prime gate after a switch). */
    suspend fun loadCurrentStreamUrl(channelUuid: String): String? =
        runCatching { repository.currentDispatcharrStreamUrl(channelUuid) }.getOrNull()

    /** Clean-end session check for the player's "Stream ended" card. */
    suspend fun verifyStreamEndedByLimit(
        channelUuid: String?,
        ourConnectedAtEpochSec: Double,
    ): com.aeriotv.android.core.playback.StreamEndVerifier.Verdict =
        repository.verifyStreamEndedByLimit(channelUuid, ourConnectedAtEpochSec)

    /** LAN/WAN verdict-flip signal for the player's mid-stream re-tune failover. */
    val lanVerdictFlips: kotlinx.coroutines.flow.SharedFlow<String> =
        repository.lanVerdictFlips

    /** Rebuild a Dispatcharr channel's live proxy URL from the current LAN/WAN
     *  base (re-tune after a verdict flip). Null when not applicable. */
    suspend fun rebuildLiveStreamUrl(channelUuid: String): String? =
        runCatching { repository.rebuildLiveStreamUrl(channelUuid) }.getOrNull()

    /** Force a fresh LAN/WAN probe (terminal-error failover path). */
    suspend fun reprobeActiveBase(): String? =
        runCatching { repository.reprobeActiveBase() }.getOrNull()
}

/** Find the programme containing `now` for a given channel. */
fun List<EPGProgramme>.nowPlaying(now: Long = System.currentTimeMillis()): EPGProgramme? =
    firstOrNull { it.startMillis <= now && now < it.endMillis }

/**
 * Channel-list sort options. Mirrors iOS sort menu (16:44:33 screenshot):
 * By Number / By Name / Favorites First.
 */
enum class SortMode(val label: String) {
    ByNumber("By Number"),
    ByName("By Name"),
    FavoritesFirst("Favorites First"),
}

/**
 * Auto-prepend an HTTP scheme to a bare host the user typed in onboarding /
 * Edit Playlist. Saves the user from typing `https://` every time they
 * paste / type a Dispatcharr or Xtream host -- "dispatcharr.example.com"
 * becomes "https://dispatcharr.example.com", "192.168.1.50:9191" becomes
 * "http://192.168.1.50:9191".
 *
 * Heuristic for picking http vs https:
 *  - Already has `http://` or `https://` -> leave as-is.
 *  - Host looks LAN-shaped (RFC1918 private IPv4 + `localhost` + `*.local`
 *    mDNS) -> prepend `http://`. Home servers almost never terminate TLS.
 *  - Anything else (public hostname, public IP) -> prepend `https://`.
 *    Modern public IPTV servers all serve TLS by default; the legacy
 *    http-only public host case is rare enough that a user encountering
 *    it can still explicitly type `http://` themselves.
 *
 * Whitespace is trimmed off either end before the scheme check so a
 * trailing newline from a copy-paste doesn't defeat the detection.
 */
internal fun normalizeSchemedUrl(raw: String): String {
    val trimmed = raw.trim()
    if (trimmed.isEmpty()) return trimmed
    // Case-insensitive existing-scheme check covers "HTTP://..." pastes too.
    val lower = trimmed.lowercase()
    if (lower.startsWith("http://") || lower.startsWith("https://")) {
        return trimmed
    }
    // Task #45 file import: an imported playlist/EPG carries a file: URI in
    // the same URL fields (both the "file:///" and java.net "file:/" forms);
    // it already has its scheme -- pass through (prepending https:// would
    // mangle it into a bogus host).
    if (lower.startsWith("file:")) return trimmed
    // Strip any user-supplied leading scheme-ish prefix that's NOT a real
    // scheme (e.g. "//example.com" protocol-relative) before deciding.
    val hostPart = trimmed.removePrefix("//")
    // Pull out the host (drop port + path) for the LAN-shape check. The
    // resulting prefix decision applies to the FULL trimmed input, not
    // just the host -- we want to keep the user's port/path intact.
    val hostOnly = hostPart.substringBefore('/').substringBefore(':')
    val isLan = when {
        hostOnly.equals("localhost", ignoreCase = true) -> true
        hostOnly.endsWith(".local", ignoreCase = true) -> true
        hostOnly.startsWith("192.168.") -> true
        hostOnly.startsWith("10.") -> true
        // 172.16.0.0/12 -> 172.16. through 172.31.
        hostOnly.startsWith("172.") -> {
            val secondOctet = hostOnly.removePrefix("172.").substringBefore('.').toIntOrNull()
            secondOctet != null && secondOctet in 16..31
        }
        else -> false
    }
    val scheme = if (isLan) "http://" else "https://"
    return "$scheme$hostPart"
}
