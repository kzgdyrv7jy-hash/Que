package com.aeriotv.android.feature.livetv.grid

import com.aeriotv.android.core.pip.findActivity
import com.aeriotv.android.core.data.guideMatchKey
import androidx.activity.compose.BackHandler
import kotlinx.coroutines.launch
import androidx.compose.foundation.background
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.focusGroup
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.TravelExplore
import androidx.compose.material.icons.filled.ViewList
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.StarOutline
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.GridView
import androidx.compose.material.icons.outlined.FiberManualRecord
import androidx.compose.material.icons.outlined.CreateNewFolder
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.ui.text.input.ImeAction
import com.aeriotv.android.feature.collections.AddToCollectionFlow
import com.aeriotv.android.feature.collections.CollectionPill
import com.aeriotv.android.feature.livetv.LiveTvPhoneCircle
import com.aeriotv.android.feature.livetv.LiveTvPhoneHeaderRow
import com.aeriotv.android.feature.livetv.PhoneGroupDrawerHost
import com.aeriotv.android.feature.livetv.ManageGroupsSheet
import com.aeriotv.android.feature.livetv.TvGroupPicker
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.layout
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import com.aeriotv.android.feature.player.MiniPlayerChrome
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusProperties
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.compose.runtime.DisposableEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aeriotv.android.core.data.ChannelCollection
import com.aeriotv.android.core.data.EPGProgramme
import com.aeriotv.android.core.data.M3UChannel
import com.aeriotv.android.core.data.ProgramInfoTarget
import com.aeriotv.android.core.data.canReplay
import com.aeriotv.android.core.data.db.entity.dispatcharrVersionAtLeast
import com.aeriotv.android.core.data.db.entity.resolveGuideDays
import com.aeriotv.android.core.data.db.entity.GUIDE_DAYS_ALL_MAX_AHEAD
import com.aeriotv.android.core.data.db.entity.GUIDE_DAYS_ALL_MAX_BACK
import com.aeriotv.android.core.data.db.entity.reminderKey
import com.aeriotv.android.core.data.toInfoTarget
import com.aeriotv.android.core.guide.GuideCatalog
import com.aeriotv.android.core.tv.TvActionMenuDialog
import com.aeriotv.android.core.tv.TvMenuAction
import com.aeriotv.android.core.tv.rememberTvMenuGuard
import com.aeriotv.android.feature.collections.CollectionsViewModel
import com.aeriotv.android.feature.dvr.DvrViewModel
import com.aeriotv.android.feature.miniplayer.MiniPlayerSession
import com.aeriotv.android.feature.miniplayer.MiniPlayerViewModel
import com.aeriotv.android.feature.favorites.FavoritesViewModel
import com.aeriotv.android.feature.livetv.EmptyGroupNotice
import com.aeriotv.android.feature.livetv.GroupSortMode
import com.aeriotv.android.feature.livetv.GuideGroupSidebarPane
import com.aeriotv.android.feature.livetv.LiveTVViewMode
import com.aeriotv.android.feature.livetv.ProgramInfoSheet
import com.aeriotv.android.feature.livetv.RecordProgramSheet
import com.aeriotv.android.feature.livetv.computeDisplayChannels
import com.aeriotv.android.feature.livetv.orderGroups
import com.aeriotv.android.feature.livetv.rememberLiveTvFormFactor
import com.aeriotv.android.feature.multiview.rememberMultiviewStoreHandle
import com.aeriotv.android.feature.playlist.PlaylistViewModel
import com.aeriotv.android.feature.reminders.RemindersViewModel
import com.aeriotv.android.feature.settings.SettingsViewModel
import com.aeriotv.android.ui.LocalCanRecordToServer
import com.aeriotv.android.ui.theme.isQueTheme
import com.aeriotv.android.ui.theme.RoyalBlueFocus
import com.aeriotv.android.ui.theme.RoyalBlueRaised
import com.aeriotv.android.ui.theme.RoyalBlueSurface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext

/**
 * Host for the rebuilt guide (developer toggle "New guide renderer"). Same
 * public contract as GuideScreen so LiveTVTabContent can swap them. First
 * cut deliberately omits: the docked group sidebar, collection pills, record
 * dots, mini-player promotion on OK, the search field. Those return in the
 * cut-over phase once the grid itself passes the acceptance gates.
 */
@Composable
fun GuideScreen(
    onChannelClick: (M3UChannel) -> Unit,
    viewMode: LiveTVViewMode,
    canToggleViewMode: Boolean,
    onToggleViewMode: () -> Unit,
    onLaunchMultiview: () -> Unit = {},
    onOpenSearch: () -> Unit = {},
    onPlayCatchup: (
        channelId: String,
        playbackUrl: String,
        title: String,
        progStartMillis: Long,
        progEndMillis: Long,
        panelTz: String,
        channelUuid: String,
    ) -> Unit = { _, _, _, _, _, _, _ -> },
    modifier: Modifier = Modifier,
    /** Favorites tab on TV (Logan 2026-09-02): the grid shows only the
     *  starred channels in their favorites order; no group pills, no
     *  sidebar, no search / sort. */
    favoritesOnly: Boolean = false,
    viewModel: PlaylistViewModel = hiltViewModel(),
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val defaultGroupToken by viewModel.defaultGroupToken.collectAsStateWithLifecycle()
    val settingsVm: SettingsViewModel = hiltViewModel()
    val favoritesVm: FavoritesViewModel = hiltViewModel()
    val remindersVm: RemindersViewModel = hiltViewModel()
    val collectionsVm: CollectionsViewModel = hiltViewModel()
    val multiviewStore = rememberMultiviewStoreHandle()
    val miniPlayerVm: MiniPlayerViewModel = hiltViewModel()
    val miniState by miniPlayerVm.state.collectAsStateWithLifecycle()
    val miniActive = miniState is MiniPlayerSession.State.Active
    val miniChannelId = (miniState as? MiniPlayerSession.State.Active)?.channel?.id
    val dvrVm: DvrViewModel = hiltViewModel()
    val dvrState by dvrVm.state.collectAsStateWithLifecycle()
    val recordingWindows = remember(dvrState.recordings) {
        val out = HashMap<Int, MutableList<LongRange>>()
        for (rec in dvrState.recordings) {
            val st = rec.effectiveStatus()
            val chId = rec.dispatcharrChannelId ?: continue
            if (st == DvrViewModel.Recording.Status.Scheduled || st == DvrViewModel.Recording.Status.Recording) {
                out.getOrPut(chId) { ArrayList() }.add(rec.startMillis until rec.endMillis)
            }
        }
        out as Map<Int, List<LongRange>>
    }
    val isTv = rememberLiveTvFormFactor().isTv
    val queGuide = isTv && isQueTheme()
    val context = LocalContext.current
    val canRecordToServer = LocalCanRecordToServer.current

    val guideScale by settingsVm.guideScale.collectAsStateWithLifecycle()
    val categoryPalette by settingsVm.categoryPalette.collectAsStateWithLifecycle(initialValue = com.aeriotv.android.core.category.CategoryPaletteState.Default)
    val displayScaleLiveTv by settingsVm.displayScaleLiveTV.collectAsStateWithLifecycle()
    val hiddenGroups by settingsVm.hiddenGroups.collectAsStateWithLifecycle()
    val groupSortModeRaw by settingsVm.groupSortMode.collectAsStateWithLifecycle()
    val groupOrder by settingsVm.groupOrder.collectAsStateWithLifecycle()
    val groupSortMode = GroupSortMode.from(groupSortModeRaw)
    // Logan 2026-09-14: Recently Watched is a synthetic group, unchecked in
    // Manage Groups until the user shows it. "Hidden" is the one mechanism, so
    // the pref folds into the hidden set the sheets and the filters see.
    val recentGroupVisible by settingsVm.recentGroupVisible.collectAsStateWithLifecycle()
    val recentChannelIds by settingsVm.recentChannelIds.collectAsStateWithLifecycle(initialValue = emptyList())
    val programInfoButtonModeRaw by settingsVm.guideProgramInfoButton
        .collectAsStateWithLifecycle(initialValue = com.aeriotv.android.core.preferences.GuideProgramInfoButton.OFF)
    val programInfoButtonGuideOn by settingsVm.programInfoButtonGuide.collectAsStateWithLifecycle(initialValue = false)
    // Program Info Button > Guide View off hides the button in the guide.
    val programInfoButtonMode = if (programInfoButtonGuideOn) programInfoButtonModeRaw
        else com.aeriotv.android.core.preferences.GuideProgramInfoButton.OFF
    val effectiveHidden = remember(hiddenGroups, recentGroupVisible) {
        if (recentGroupVisible) hiddenGroups
        else hiddenGroups + com.aeriotv.android.feature.playlist.PlaylistViewModel.RECENT_GROUP
    }
    val favoritesOrNull by favoritesVm.all.collectAsStateWithLifecycle()
    val favoritesList = favoritesOrNull ?: emptyList()
    val favoriteIds = remember(favoritesList) { favoritesList.mapTo(HashSet()) { it.channelId } }
    val reminders by remindersVm.all.collectAsStateWithLifecycle()
    val reminderKeys = remember(reminders) { reminders.mapTo(HashSet()) { it.reminderKey } }
    val collections by collectionsVm.collections.collectAsStateWithLifecycle()
    val stagedMultiview by multiviewStore.selected.collectAsStateWithLifecycle(initialValue = emptyList())
    val stagingOn by multiviewStore.isStaging.collectAsStateWithLifecycle()
    val mvPlayingSeed by multiviewStore.playingSeed.collectAsStateWithLifecycle()
    val groupSelector by settingsVm.guideGroupSelector.collectAsStateWithLifecycle()
    val sidebarGroupMode = isTv && !queGuide && groupSelector == "sidebar" && !favoritesOnly
    // Sidebar layout (Logan 2026-09-14): "shift" docks the pane beside the
    // grid, which narrows instead of being covered; "overlay" keeps the scrim.
    val guideSidebarLayout by settingsVm.guideSidebarLayout.collectAsStateWithLifecycle()
    val sidebarShiftMode = isTv && guideSidebarLayout == "shift"
    // Phone group selector (Logan 2026-09-05, Apple parity): drawer by
    // default, pills on request. Separate preference from the TV's.
    val phoneGroupSelector by settingsVm.phoneGroupSelector.collectAsStateWithLifecycle()
    val phoneSidebarMode = !isTv && phoneGroupSelector != "pills" && !favoritesOnly
    var phoneDrawerOpen by remember { mutableStateOf(false) }
    val remoteMap by settingsVm.remoteControlMap.collectAsStateWithLifecycle()
    val tabActive = com.aeriotv.android.feature.main.LocalTabIsActive.current
    var groupSidebarOpen by remember { mutableStateOf(false) }
    var searchActive by remember { mutableStateOf(false) }
    com.aeriotv.android.ui.search.CloseSearchOnLeave(searchActive) {
        searchActive = false
        viewModel.onSearchQueryChange("")
    }
    var collectionPickerFor by remember { mutableStateOf<Pair<String, String>?>(null) }
    var showManageGroups by remember { mutableStateOf(false) }
    var sidebarOriginalGroup by remember { mutableStateOf<String?>(null) }
    // Manage Groups opened from the sidebar's header button: its dismissal
    // returns to the still-open sidebar instead of closing it.
    var manageGroupsFromSidebar by remember { mutableStateOf(false) }
    // Bumped when the sidebar should pull focus back onto its active row.
    var sidebarRefocusRequest by remember { mutableStateOf(0) }

    val tvComfortScale = if (isTv) displayScaleLiveTv.coerceIn(0.85f, 1.75f) else 1f
    // System font size times the app Text Size (the root LocalDensity carries
    // both), so TV rows grow with the text they hold.
    val fontScale = androidx.compose.ui.platform.LocalDensity.current.fontScale
    // Phone / tablet rows keep their fixed canon heights at 100% and grow only
    // with the app Text Size (not the system font size, unchanged from before).
    val appTextScale = com.aeriotv.android.ui.scale.LocalAppTextScale.current
    val hourWidth = if (queGuide) 300.dp else if (isTv) 300.dp * guideScale * tvComfortScale else 320.dp * guideScale
    val railWidth = if (queGuide) 188.dp else if (isTv) 120.dp * tvComfortScale else 78.dp
    // Phone cells carry the subtitle and two description lines (Logan
    // 2026-09-05, EPGGuideView.swift:3415: 98pt on the phone idiom, 72 on
    // the iPad), so they are taller. Phone = smallest width under 600dp,
    // so a rotated phone keeps the tall rows like the iPhone does.
    val isPhoneIdiom = !isTv && LocalConfiguration.current.smallestScreenWidthDp < 600
    // Channel Preview (tvOS "Live TV Layout", Logan 2026-09-05): a banner
    // above the guide carries the focused program; rows keep title + tags
    // and are shorter (tvOS 96 vs 110 pt).
    val liveTvLayout by settingsVm.liveTvLayout.collectAsStateWithLifecycle()
    val previewMode = isTv && (queGuide || liveTvLayout == "preview")
    // Subtext Size grows rows only (never shrinks them) by the share of the
    // row that holds secondary lines (subtitle, description, time).
    val subtextGrowth = com.aeriotv.android.ui.scale.LocalSubtextScale.current.let { s ->
        1f + (s - 1f).coerceAtLeast(0f) * (if (!isTv && isPhoneIdiom) GUIDE_PHONE_SUBTEXT_SHARE else GUIDE_SUBTEXT_SHARE)
    }
    // PHYSICAL PARITY WITH APPLE TV (Logan 2026-09-17). Apple TV points are
    // about 2x the Streamer's dp on the same physical screen (1080 pt tall vs
    // 540 dp), so Apple's 132 pt row is 66 dp here and its 22 pt band is 11 dp.
    // The TV base heights ARE those totals, band included: the band is carved
    // out of the row, never added on top of it. Preview mode is Apple's 96 pt
    // row, which is 48 dp here and is the mode Logan compares against, so the
    // Streamer shows the same seven rows as the Apple TV guide does
    // (measured 2026-09-17).
    //
    // THE TV ROW DOES NOT GROW FOR THE BAND (Logan 2026-09-16, Streamer).
    // The band is CARVED OUT of the row the guide already had, exactly as
    // Apple TV does it: Apple's 132 pt row is the row INCLUDING its band, not
    // 132 pt plus a band. Adding the 22 dp band on top here took the Streamer
    // row from 96 px to 140 px and dropped the guide from 7 visible channels
    // to under 5, because the Android TV guide viewport is proportionally
    // shorter than Apple's (the header, the filter row and the tab bar take
    // more of it), so the row count, not the row height, is what has to match.
    // The phone / tablet column still takes its small net growth: there the
    // band replaces a number line that used to sit under the logo.
    val rowHeight = if (queGuide) 66.dp else (if (isTv) (if (previewMode) 48.dp else 66.dp) * tvComfortScale * fontScale else if (isPhoneIdiom) 98.dp * appTextScale else 72.dp * appTextScale) * subtextGrowth +
        (if (isTv) 0.dp else com.aeriotv.android.feature.livetv.grid.GUIDE_PHONE_ROW_BAND_GROWTH)
    val headerHeight = if (queGuide) 32.dp else if (isTv) 25.dp * tvComfortScale * fontScale else 32.dp * appTextScale

    // Clock: 30 s tick for the now-line and the airing tint.
    var nowMs by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { delay(30_000L); nowMs = System.currentTimeMillis() } }

    val allGroupNames = remember(state.channels, groupSortMode, groupOrder, favoriteIds.isNotEmpty()) {
        com.aeriotv.android.feature.livetv.GuideMemo.get(
            "groupNames",
            listOf(com.aeriotv.android.feature.livetv.GuideMemo.Ref(state.channels), groupSortMode, groupOrder, favoriteIds.isNotEmpty()),
        ) {
            val sourceOrder = state.channels.asSequence().map { it.groupTitle }.filter { it.isNotBlank() }.distinct().toList()
            orderGroups(
                sourceOrder, groupSortMode, groupOrder,
                hasFavorites = favoriteIds.isNotEmpty(), hasRecent = true,
            )
        }
    }
    val groups = remember(allGroupNames, effectiveHidden) {
        com.aeriotv.android.feature.livetv.groupTokens(
            allGroupNames.filter { it !in effectiveHidden },
            effectiveHidden,
        )
    }
    val fallbackGroup = com.aeriotv.android.feature.livetv.fallbackGroupToken(groups)
    // GH #80: a selection that just got hidden (including All) lands on the
    // first pill still shown.
    // GH #81: Favorites is synthetic, so it only enters `groups` once the
    // favorites table has loaded. Resetting while it is still null threw away a
    // restored Favorites selection on every cold launch, which is why the
    // default group never stuck.
    LaunchedEffect(groups, state.selectedGroup, favoritesOrNull == null) {
        val sel = state.selectedGroup
        val favoritesPending = sel == com.aeriotv.android.feature.playlist.PlaylistViewModel.FAVORITES_GROUP &&
            favoritesOrNull == null
        if (sel !in groups && !sel.startsWith(ChannelCollection.TOKEN_PREFIX) &&
            !favoritesPending && allGroupNames.isNotEmpty()
        ) {
            viewModel.onGroupSelected(fallbackGroup, persist = false)
        }
    }
    // Pills: collections placed at the beginning, then the groups, then the rest.
    val pillItems = remember(groups, collections) {
        val begin = collections.filter { it.placement == ChannelCollection.PLACEMENT_BEGINNING }
        val end = collections.filter { it.placement != ChannelCollection.PLACEMENT_BEGINNING }
        begin.map { ChannelCollection.token(it.id) to it.name } +
            // Tokens (Favorites, All) read through the shared label map; the
            // raw "__favorites__" token showed on the Streamer (2026-09-10).
            groups.map { it to com.aeriotv.android.feature.livetv.groupDisplayName(it) } +
            end.map { ChannelCollection.token(it.id) to it.name }
    }
    val groupedChannels by produceState(
        initialValue = computeDisplayChannels(
            state.channels, state.selectedGroup, state.searchQuery, state.sortMode,
            allGroupNames, groupSortMode, effectiveHidden, favoriteIds, collections, recentChannelIds,
        ),
        state.channels, state.selectedGroup, state.searchQuery, state.sortMode,
        allGroupNames, groupSortMode, effectiveHidden, favoriteIds, collections, recentChannelIds,
    ) {
        value = withContext(Dispatchers.Default) {
            computeDisplayChannels(
                state.channels, state.selectedGroup, state.searchQuery, state.sortMode,
                allGroupNames, groupSortMode, effectiveHidden, favoriteIds, collections, recentChannelIds,
            )
        }
    }
    // favoritesOnly: the starred channels in the user's favorites order,
    // joined against the loaded playlist so stale rows fall away.
    val favoriteChannels = remember(favoritesList, state.channels) {
        val byId = state.channels.associateBy { it.id }
        favoritesList.mapNotNull { byId[it.channelId] }
    }
    val displayChannels = if (favoritesOnly) favoriteChannels else groupedChannels

    // Grid window: the playlist's Guide Days setting (epgRetentionDays) in
    // BOTH directions (Logan 2026-09-11); the retired Settings > Network
    // "Guide Window" preference no longer shapes the timeline.
    // Loaded EPG span in whole days either side of now, for the Jump To sheet
    // and (on All Available) for the timeline extent itself.
    val (epgDaysBack, epgDaysAhead) = remember(state.epgByChannel) {
        var minStart = Long.MAX_VALUE; var maxEnd = Long.MIN_VALUE
        for (list in state.epgByChannel.values) {
            list.firstOrNull()?.let { if (it.startMillis < minStart) minStart = it.startMillis }
            list.lastOrNull()?.let { if (it.endMillis > maxEnd) maxEnd = it.endMillis }
        }
        val nowMs0 = System.currentTimeMillis()
        val day = 86_400_000L
        val back = if (minStart == Long.MAX_VALUE) 0 else ((nowMs0 - minStart + day - 1) / day).toInt().coerceAtLeast(0)
        val ahead = if (maxEnd == Long.MIN_VALUE) 1 else ((maxEnd - nowMs0 + day - 1) / day).toInt().coerceAtLeast(1)
        back to ahead
    }
    // A Dispatcharr 0.30+ server keeps many days and ensureGuideForward
    // fetches the jumped day on demand, so Jump To offers exactly the
    // playlist's Guide Days there, back and ahead (Logan 2026-09-11); the
    // 14-day ceiling below is a Jump To sheet constraint, not a fetch limit.
    // Other sources are limited to the guide their XMLTV actually carries.
    val guideDaysOffered = state.playlist?.let { pl ->
        val dispatcharr = pl.sourceType == com.aeriotv.android.core.data.SourceType.DispatcharrApiKey.name ||
            pl.sourceType == com.aeriotv.android.core.data.SourceType.DispatcharrUserPass.name
        if (dispatcharr && pl.dispatcharrVersionAtLeast("0.30.0"))
            resolveGuideDays(pl.epgRetentionDays)
        else null
    }
    // The catalog only decodes the days in view now (PlaylistViewModel
    // guideLaunchSpanDays), so on All Available the offer comes from what the
    // CACHE holds, not from what happens to be loaded; jumping to one of those
    // days widens the catalog through ensureGuideRange below.
    val epgDaysAheadOffered = guideDaysOffered ?: maxOf(epgDaysAhead, state.epgCachedDaysAhead)
    val epgDaysBackOffered = guideDaysOffered ?: maxOf(epgDaysBack, state.epgCachedDaysBack)
    // Extent: a fixed Guide Days setting drives both directions from the
    // setting; All Available (and non-Dispatcharr sources) follow the guide
    // that is actually loaded.
    // THE EXTENT FOLLOWS THE CONFIGURED GUIDE DAYS ON EVERY SOURCE (Logan
    // 2026-09-19, Apple GuideStore.activeForwardDays / activeRetentionDays).
    // It used to follow the setting only for Dispatcharr 0.30 and above and
    // otherwise follow the LOADED extent, which at launch is about one day:
    // forward scrolling simply stopped after roughly 24 hours no matter what
    // Guide Days said. Now a numeric Guide Days means that many days in both
    // directions for ANY source, All Available means the same ceilings Apple
    // uses (60 ahead / 30 back), and with no active playlist yet the window
    // falls back to the PlaylistEntity default of 7 days. The scroll bounds
    // are still owned by the grid's clamp against this window, so the TV
    // focus model is untouched; the days beyond what is loaded are one hole
    // cell per row until the on-demand fetch below fills them in.
    val activePlaylist = state.playlist
    // null with a playlist loaded = All Available; null with no playlist yet
    // is the default, handled below.
    val configuredGuideDays = activePlaylist?.let { resolveGuideDays(it.epgRetentionDays) }
    val forwardDays = configuredGuideDays
        ?: if (activePlaylist == null) GUIDE_DAYS_DEFAULT else GUIDE_DAYS_ALL_MAX_AHEAD
    val backDays = configuredGuideDays
        ?: if (activePlaylist == null) GUIDE_DAYS_DEFAULT else GUIDE_DAYS_ALL_MAX_BACK
    val historyHours = (backDays * 24).coerceAtLeast(1)
    val forwardHours = (forwardDays * 24).coerceAtLeast(3)
    // Guide jump-to-day (Roman via Discord 2026-09-06; Apple parity): the
    // target instant while a jump is active. The window grows to hold it
    // (plus three hours of room), the view model fetches the missing days,
    // and the jump ends on its own once the now line scrolls back on screen.
    var jumpTargetMs by remember { mutableStateOf<Long?>(null) }
    var pendingJumpScroll by remember { mutableStateOf(false) }
    var showJumpSheet by remember { mutableStateOf(false) }
    val jumpWindowEnd = jumpTargetMs?.let { (it + 3 * 3_600_000L) / QUANTUM_MS * QUANTUM_MS + QUANTUM_MS }
    // A jump backwards has to widen the window and the catalog the same way a
    // forward one does: launch only decodes today plus/minus a day
    // (PlaylistViewModel guideLaunchSpanDays), so the cached day the user
    // picked is in Room but not yet in memory.
    val jumpWindowStart = jumpTargetMs?.let { (it - 3 * 3_600_000L) / QUANTUM_MS * QUANTUM_MS }
    // Quantized to 15 min so re-entering the tab within that window reuses
    // the memoized rows instead of rebuilding them for a new "now".
    // Keyed on the 15-min "now" quantum too (Logan 2026-10-10: the guide
    // opened hours behind). The guide composition outlives the app going to
    // the background (kept tabs), so a window computed once at composition
    // stayed pinned to that hour and the viewport clamped into it.
    val nowQuantum = nowMs / QUANTUM_MS
    val windowStartMs = remember(historyHours, jumpWindowStart, nowQuantum) {
        minOf(
            (System.currentTimeMillis() - historyHours * 3_600_000L) / QUANTUM_MS * QUANTUM_MS,
            jumpWindowStart ?: Long.MAX_VALUE,
        )
    }
    val windowEndMs = remember(forwardHours, jumpWindowEnd, nowQuantum) {
        maxOf(
            (System.currentTimeMillis() + forwardHours * 3_600_000L) / QUANTUM_MS * QUANTUM_MS + QUANTUM_MS,
            jumpWindowEnd ?: 0L,
        )
    }
    LaunchedEffect(jumpWindowStart, jumpWindowEnd) {
        if (jumpWindowStart != null || jumpWindowEnd != null) {
            viewModel.ensureGuideRange(jumpWindowStart ?: 0L, jumpWindowEnd ?: 0L)
        }
    }
    // Retained across the player round trip (the player route disposes the
    // guide): a fresh state composed the grid empty and then installed the
    // whole window, the 800 to 1360 ms frames on return. The retained state
    // is reset to exactly what a new one holds, so focus and viewport land
    // as before; only the rows survive.
    val grid = remember { RetainedGuideGrid.take(favoritesOnly, System.currentTimeMillis() - GuideGridState.DEFAULT_LEAD_MS) }
    androidx.compose.runtime.DisposableEffect(grid) { onDispose { RetainedGuideGrid.give(favoritesOnly, grid) } }
    // Hoisted so a group change can read and set the rows viewport.
    val gridListState = rememberLazyListState()
    val groupViewport = remember { GuideGroupViewport() }
    // LOAD ON DEMAND WHILE SCROLLING FORWARD (Logan 2026-09-19). The window
    // now reaches as far as Guide Days allows, but only the launch span is in
    // memory, so scrolling toward the loaded edge has to pull the next window
    // in. Keyed on the viewport END quantized to the DAY, so a pan inside one
    // day asks for nothing, and debounced so holding Right does not fire a
    // fetch per step. ensureGuideForward is the same entry point jump-to-day
    // uses and is itself a no-op when the catalog already reaches that far.
    LaunchedEffect(grid, state.playlist?.id) {
        val day = 86_400_000L
        androidx.compose.runtime.snapshotFlow { (grid.viewportEndMs + 6 * 3_600_000L) / day }
            .distinctUntilChanged()
            .collectLatest { edgeDay ->
                delay(400L)
                viewModel.ensureGuideForward((edgeDay + 1) * day)
            }
    }
    // Window-roll reuse (perf 2026-10-03, Streamer perf4): the window start
    // is quantized to 15 min, so a channel played for a while comes back to a
    // window that rolled one or more quanta, and a new rows object reinstalled
    // all 799 rows (reused=false, 785 ms Davey). When the retained rows are
    // for the SAME channel list (by content: the list is recomputed on entry,
    // and again when the recents change after a play) and the same catalog,
    // and the window stayed put or only advanced by the same amount at both
    // ends (at most WINDOW_ROLL_REUSE_MAX_MS), keep
    // them: they cover the new window's start (plus that much extra past),
    // the far edge is a week out and the forward loader extends it anyway,
    // and the retained state already took the new viewport start in
    // resetForEntry. Anything else (new channels, new EPG, a jump, a Guide
    // Days change, a long absence) builds new rows as before. TV only; the
    // phone keeps building fresh rows.
    // Plain holder, not state: written by the rows calc, read by the install log.
    val windowRoll = remember { LongArray(1) }
    val rows = remember(displayChannels, state.epgByChannel, windowStartMs, windowEndMs) {
        val held = grid.rows
        val roll = windowStartMs - held.windowStartMs
        if (isTv && !held.isEmpty &&
            held.catalog === (state.epgByChannel as? GuideCatalog) &&
            roll >= 0L && roll <= WINDOW_ROLL_REUSE_MAX_MS &&
            windowEndMs - held.windowEndMs == roll &&
            (held.channels === displayChannels || held.channels == displayChannels)
        ) {
            windowRoll[0] = roll
            held
        } else {
            windowRoll[0] = 0L
            if (isTv && !held.isEmpty) com.aeriotv.android.ui.tv.TvFocusTrace.guide(
                "rows-reuse miss channelsSame=${held.channels == displayChannels} " +
                    "catalogSame=${held.catalog === (state.epgByChannel as? GuideCatalog)} roll=$roll " +
                    "endRoll=${windowEndMs - held.windowEndMs}",
            )
            com.aeriotv.android.feature.livetv.GuideMemo.get(
                "rows",
                listOf(
                    com.aeriotv.android.feature.livetv.GuideMemo.Ref(displayChannels),
                    com.aeriotv.android.feature.livetv.GuideMemo.Ref(state.epgByChannel),
                    windowStartMs, windowEndMs,
                ),
            ) { GuideGridRows(displayChannels, state.epgByChannel as? GuideCatalog, windowStartMs, windowEndMs) }
        }
    }
    // Streamer empty-guide-at-launch diagnosis: once per process, state at
    // the first non-empty row install (catalog, coverage of now, window).
    LaunchedEffect(rows) {
        if (rows.isEmpty) return@LaunchedEffect
        val cat = state.epgByChannel
        // Two one-shot lines: the first row install (may precede the cached
        // catalog by about 1.5 s on the Streamer) and the first with programs.
        val label = when {
            RetainedGuideGrid.markFirstPaintLogged() -> "first paint"
            cat is GuideCatalog && RetainedGuideGrid.markFirstCatalogPaintLogged() -> "first paint with programs"
            else -> return@LaunchedEffect
        }
        val now = System.currentTimeMillis()
        val withNow = rows.channels.count { ch ->
            cat[ch.guideMatchKey]?.any { now >= it.startMillis && now < it.endMillis } == true
        }
        android.util.Log.i(
            "AerioTV",
            "[GUIDE] $label: catalog=${if (cat is GuideCatalog) "built" else "none"} " +
                "catalogChannels=${cat.size} rows=${rows.size} rowsWithNow=$withNow " +
                "windowStart=${rows.windowStartMs} windowEnd=${rows.windowEndMs} " +
                "viewportStart=${grid.viewportStartMs} now=$now " +
                "windowCoversNow=${now >= rows.windowStartMs && now < rows.windowEndMs}",
        )
    }
    LaunchedEffect(rows) {
        // Same rows object as the retained state already holds: the install
        // only lands focus (cheap, no row invalidation); log which it was.
        val reused = grid.rows === rows
        // GROUP SWITCH VIEWPORT (Logan 2026-10-04, Onn tablet): All, a group,
        // back to All landed "in the thousands". installRows keeps focus on
        // the focused CHANNEL across a row swap and the lazy list keeps its
        // first visible item by KEY, so the group's first channel (focused by
        // the clamp to row 0) was found again deep in All and the list
        // scrolled to it. A group change is now its own install: entering a
        // group starts at its top; returning to All restores the first
        // visible channel (and the focus, when it was on screen) All had.
        val toGroup = state.selectedGroup
        val fromGroup = groupViewport.installedGroup
        val groupChanged = fromGroup != null && fromGroup != toGroup
        groupViewport.installedGroup = toGroup
        var restore: GuideGroupViewport.Saved? = null
        if (groupChanged) {
            val old = grid.rows
            val firstIdx = gridListState.firstVisibleItemIndex
            if (!old.isEmpty && firstIdx in 0 until old.size) {
                val firstId = old.channel(firstIdx).id
                val focusIdx = grid.focusChannelId?.let { old.indexOfChannel(it) } ?: -1
                // Focus is kept only inside the lane band, so the lane effect
                // does not move the restored first row to reach it.
                val focusId = if (focusIdx in firstIdx..(firstIdx + GROUP_RESTORE_LANE_ROWS)) old.channel(focusIdx).id else firstId
                groupViewport.saved[fromGroup!!] = GuideGroupViewport.Saved(firstId, gridListState.firstVisibleItemScrollOffset, focusId)
            }
            if (toGroup == com.aeriotv.android.feature.playlist.PlaylistViewModel.ALL_GROUPS) {
                restore = groupViewport.saved[toGroup]?.takeIf { rows.indexOfChannel(it.firstChannelId) >= 0 }
            }
        }
        if (groupChanged) grid.installRowsForGroup(rows, restore?.focusChannelId) else grid.installRows(rows)
        val firstNow = gridListState.firstVisibleItemIndex
        com.aeriotv.android.ui.tv.TvFocusTrace.guide(
            "rows-install reused=$reused windowRollMs=${windowRoll[0]} windowStartMs=${rows.windowStartMs} windowEndMs=${rows.windowEndMs}" +
                " forwardHours=$forwardHours viewportStart=${grid.viewportStartMs} drawStart=${grid.drawViewportStartMs}" +
                " group=$toGroup count=${rows.size} firstRow=$firstNow firstChannel=${if (firstNow in 0 until rows.size) rows.channel(firstNow).name else "-"}" +
                " focusRow=${grid.focusRow} focusChannel=${grid.focusRow.takeIf { it in 0 until rows.size }?.let { rows.channel(it).name } ?: "-"}",
        )
        if (groupChanged) {
            android.util.Log.d(
                "GuideGroup",
                "GuideGroup: filter group=$toGroup raw=${state.channels.size} rows=${rows.size} first=${rows.channels.firstOrNull()?.name ?: "none"}",
            )
            val anchorRow = restore?.let { rows.indexOfChannel(it.firstChannelId) } ?: 0
            com.aeriotv.android.ui.tv.TvFocusTrace.guide(
                "group change from=$fromGroup to=$toGroup anchorChannel=${restore?.firstChannelId ?: rows.channels.firstOrNull()?.id ?: "-"} " +
                    "anchorRow=$anchorRow restored=${restore != null}",
            )
            if (!rows.isEmpty) {
                // Wait for the list to measure the new rows; a scroll requested
                // against the old item count is clamped to it.
                kotlinx.coroutines.withTimeoutOrNull(1_000L) {
                    androidx.compose.runtime.snapshotFlow { gridListState.layoutInfo.totalItemsCount }.first { it == rows.size }
                }
                gridListState.scrollToItem(anchorRow, if (restore != null) restore.offsetPx else 0)
            }
        }
        if (!rows.isEmpty) {
            kotlinx.coroutines.withTimeoutOrNull(1_500L) {
                androidx.compose.runtime.snapshotFlow { gridListState.layoutInfo.totalItemsCount == rows.size && !gridListState.isScrollInProgress }.first { it }
            }
            androidx.compose.runtime.withFrameNanos { }
            val landed = gridListState.firstVisibleItemIndex
            com.aeriotv.android.ui.tv.TvFocusTrace.guide(
                "viewport landed firstRow=$landed/${rows.size} channel=${if (landed in 0 until rows.size) rows.channel(landed).name else "-"}" +
                    " focusRow=${grid.focusRow}",
            )
        }
        // Land the jump once the rows reach far enough to hold it.
        val target = jumpTargetMs
        // Both edges, now that a backward jump also widens the window.
        if (pendingJumpScroll && target != null &&
            rows.windowEndMs >= target && rows.windowStartMs <= target
        ) {
            grid.scrollViewportTo(target - grid.leadMs)
            pendingJumpScroll = false
        }
    }
    // Auto-end (Logan's rule): scrolling back until now is on screen ends the jump.
    LaunchedEffect(jumpTargetMs) {
        if (jumpTargetMs == null) return@LaunchedEffect
        androidx.compose.runtime.snapshotFlow { grid.viewportStartMs }.collect { vs ->
            if (!pendingJumpScroll) {
                val now = System.currentTimeMillis()
                if (now in vs..(vs + grid.viewportDurationMs)) jumpTargetMs = null
            }
        }
    }
    val jumpLabel = remember(jumpTargetMs) {
        jumpTargetMs?.let { java.text.SimpleDateFormat("EEE h:mm a", java.util.Locale.getDefault()).format(java.util.Date(it)) }
    }
    val startJump: (Long) -> Unit = { target ->
        jumpTargetMs = target
        pendingJumpScroll = true
        if (grid.rows.windowEndMs >= target && grid.rows.windowStartMs <= target) {
            grid.scrollViewportTo(target - grid.leadMs); pendingJumpScroll = false
        }
    }
    val snapToNow: () -> Unit = { jumpTargetMs = null; pendingJumpScroll = false; grid.anchorToNow(System.currentTimeMillis()) }

    // The guide always opens and resumes at now (Logan 2026-10-10). The
    // composition (and the retained grid) survives the app being backgrounded
    // and the tab being hidden, so neither path went through resetForEntry:
    // coming back after a long idle showed the hours-old viewport. On every
    // foreground start and every tab re-entry, refresh the clock and anchor
    // at now, unless a catch-up return is restoring its own timeline.
    val guideLifecycle = androidx.lifecycle.compose.LocalLifecycleOwner.current.lifecycle
    var foregroundStarts by remember { androidx.compose.runtime.mutableIntStateOf(0) }
    androidx.compose.runtime.DisposableEffect(guideLifecycle) {
        // Only an ON_START that follows an ON_STOP is a resume. Adding the
        // observer replays ON_START for an already started owner; that first
        // entry is resetForEntry's job, not ours.
        var stopped = false
        val obs = androidx.lifecycle.LifecycleEventObserver { _, e ->
            when (e) {
                androidx.lifecycle.Lifecycle.Event.ON_STOP -> stopped = true
                androidx.lifecycle.Lifecycle.Event.ON_START -> if (stopped) { stopped = false; foregroundStarts++ }
                else -> Unit
            }
        }
        guideLifecycle.addObserver(obs)
        onDispose { guideLifecycle.removeObserver(obs) }
    }
    // Tab re-entry: a false -> true flip of tabActive after this composition
    // has already been shown once.
    var tabEntries by remember { androidx.compose.runtime.mutableIntStateOf(0) }
    val lastTabActive = remember { booleanArrayOf(tabActive) }
    LaunchedEffect(tabActive) {
        if (tabActive && !lastTabActive[0]) tabEntries++
        lastTabActive[0] = tabActive
    }
    LaunchedEffect(foregroundStarts, tabEntries) {
        if (foregroundStarts == 0 && tabEntries == 0) return@LaunchedEffect
        // Empty rows: the window is unset (a fresh state already sits at now).
        if (!tabActive || GuideCatchupReturn.pending() || grid.rows.isEmpty) return@LaunchedEffect
        val now = System.currentTimeMillis()
        val before = grid.viewportStartMs
        nowMs = now
        jumpTargetMs = null
        pendingJumpScroll = false
        grid.anchorToNow(now)
        com.aeriotv.android.ui.tv.TvFocusTrace.guide(
            "anchor-at-now resumes=$foregroundStarts tabEntries=$tabEntries viewportBefore=$before " +
                "viewportAfter=${grid.viewportStartMs} behindMin=${(now - before) / 60_000L} rows=${grid.rows.size}",
        )
    }

    val gridFocus = remember { FocusRequester() }
    val pillsFocus = remember { FocusRequester() }
    val bannerFocus = remember { FocusRequester() }
    val stagingPlayFocus = remember { FocusRequester() }
    var clockSelectTrigger by remember { androidx.compose.runtime.mutableIntStateOf(0) }
    val previewProgram: EPGProgramme? = if (previewMode) grid.focusedCell() else null
    val previewChannel: M3UChannel? = if (previewMode && grid.focusRow in 0 until grid.rows.size) grid.rows.channel(grid.focusRow) else null
    if (previewMode) {
        val pl = state.playlist
        com.aeriotv.android.feature.livetv.grid.ActivePlaylistBase.baseUrl = pl?.urlString
        com.aeriotv.android.feature.livetv.grid.ActivePlaylistBase.playlistId = pl?.id
    }
    var programInfoTarget by remember { mutableStateOf<ProgramInfoTarget?>(null) }
    var recordTarget by remember { mutableStateOf<ProgramInfoTarget?>(null) }
    var menuFor by remember { mutableStateOf<Pair<M3UChannel, EPGProgramme>?>(null) }
    val menuGuard = rememberTvMenuGuard()
    // Start catch-up playback of one already-aired cell. Shared by the grid's
    // primary action (single tap / OK) and the long-press menu's "Watch from
    // Start", so both go through one resolve + navigate path.
    val startCatchup: (M3UChannel, EPGProgramme) -> Unit = { channel, cell ->
        viewModel.playCatchup(channel, cell) { result ->
            result.onFailure { android.util.Log.w("GuideGrid", "[GUIDE] catch-up resolve failed: ${it.message}") }
            result.onSuccess { r ->
                // TV: remember the launched cell and the timeline so the
                // guide that composes again after the replay lands back here.
                if (isTv) GuideCatchupReturn.set(channel.id, cell.startMillis, grid.viewportStartMs)
                onPlayCatchup(channel.id, r.url, cell.title, cell.startMillis, cell.endMillis, r.panelTimeZoneId, r.channelUuid.orEmpty())
            }
        }
    }
    val guideFocusManager = androidx.compose.ui.platform.LocalFocusManager.current

    // Land focus on the grid on entry (TV).
    // Launch focus belongs to the grid. The tab host places its own initial
    // focus on the nav pill a beat after we compose (it used to lose that race
    // only because the old guide composed first), so keep asking for about a
    // second until the grid actually holds focus.
    var gridHasFocus by remember { mutableStateOf(false) }
    // Wall time of the last key pressed inside the guide (boundary refocus idle gate).
    val lastGuideKeyAt = remember { longArrayOf(0L) }
    // True while ANYTHING inside the guide holds focus (grid, pills, banner,
    // sidebar pane). The stranded-focus watchdog below keys off this, not off
    // gridHasFocus, so it can never steal focus from the guide's own chrome
    // (that is the GH #185 runaway shape).
    var guideHasFocus by remember { mutableStateOf(false) }
    val topNavHasFocus = com.aeriotv.android.feature.main.LocalTvTopNavHasFocus.current
    // Trace (AerioFocus): every gate that can keep focus out of the grid or
    // block a vertical step, as one string. Logged on change (a [GUIDE] gates
    // line) and appended to the grid's [KEY] and focus lines.
    val traceContext = androidx.compose.ui.platform.LocalContext.current
    val exoWindowModeFlow = remember {
        dagger.hilt.android.EntryPointAccessors.fromApplication(
            traceContext.applicationContext,
            com.aeriotv.android.feature.main.MainScaffoldEntryPoint::class.java,
        ).exoWindowState().mode
    }
    val exoWindowMode by exoWindowModeFlow.collectAsStateWithLifecycle()
    val traceGates: () -> String = {
        "gates[tabActive=$tabActive gridHasFocus=$gridHasFocus" +
            " sidebarOpen=$groupSidebarOpen sidebarMode=$sidebarGroupMode layout=${if (sidebarShiftMode) "shift" else "overlay"}" +
            " gridFocusEnabled=${!(sidebarShiftMode && groupSidebarOpen && !gridHasFocus)}" +
            " manageGroups=$showManageGroups menu=${menuFor != null} info=${programInfoTarget != null} record=${recordTarget != null}" +
            " jump=$showJumpSheet collectionPicker=${collectionPickerFor != null} search=$searchActive" +
            " mini=$miniActive exoWindow=$exoWindowMode clockTrigger=$clockSelectTrigger" +
            " rows=${rows.size} focusRow=${grid.focusRow} topNavHasFocus=${topNavHasFocus.value}" +
            " guideHasFocus=$guideHasFocus]"
    }
    if (isTv) {
        val gateKey = traceGates().substringBefore(" rows=")
        LaunchedEffect(gateKey) { com.aeriotv.android.ui.tv.TvFocusTrace.guide("gates ${traceGates()}") }
    }
    LaunchedEffect(isTv, rows.isEmpty, tabActive) {
        if (!tabActive) return@LaunchedEffect
        if (isTv && !rows.isEmpty) {
            // Cold launch: the top bar's one-shot pull owns first focus (the
            // landing tab's pill). Wait for it instead of focusing row 0 first
            // and being pulled off a frame later (the visible flash). Bounded
            // so a pull that never runs cannot strand the guide.
            if (com.aeriotv.android.ui.tv.TvColdStartFocus.pending) {
                var waited = 0
                while (com.aeriotv.android.ui.tv.TvColdStartFocus.pending && waited < 3_000) { delay(50L); waited += 50 }
                com.aeriotv.android.ui.tv.TvFocusTrace.guide("refocus after=launch-loop waited-for-cold-start-pull ms=$waited")
                delay(100L)
            }
            repeat(12) { attempt ->
                if (gridHasFocus) {
                    if (attempt > 0) com.aeriotv.android.ui.tv.TvFocusTrace.guide("refocus after=launch-loop result=success attempts=$attempt")
                    return@LaunchedEffect
                }
                // The user is walking the tab bar (selection follows focus
                // there): leave focus in the bar; Down brings them in.
                if (topNavHasFocus.value) {
                    com.aeriotv.android.ui.tv.TvFocusTrace.guide("refocus after=launch-loop result=skipped reason=topNavHasFocus attempts=$attempt")
                    return@LaunchedEffect
                }
                // GH #90: a held Left that minimized the player also opened
                // the group sidebar as the guide composed; the sidebar owns
                // focus then, and this loop must not pull it back to the grid.
                if (groupSidebarOpen) {
                    com.aeriotv.android.ui.tv.TvFocusTrace.guide("refocus after=launch-loop result=skipped reason=sidebarOpen attempts=$attempt")
                    return@LaunchedEffect
                }
                runCatching { gridFocus.requestFocus() }
                delay(100L)
            }
            com.aeriotv.android.ui.tv.TvFocusTrace.guide("refocus after=launch-loop result=${if (gridHasFocus) "success" else "failure"} attempts=12 ${traceGates()}")
        }
    }
    // Down out of the top nav has to land somewhere deterministic. The bar's
    // onExit only cancels the default geometric move when the tab published an
    // entry point, and Live TV never did: the guide fills the screen UNDER the
    // overlaid bar, so its focus rect is not "below" the bar and the geometric
    // search found nothing. Frankie B. 2026-09-15: Down from tab:LiveTV was
    // declined twice in a row (guide-screen(focus-not-in-grid)) with focus
    // stuck in the bar. Publish the guide's entry point, mirroring the Up
    // chain: the pill row when it is there, otherwise the grid itself.
    val tabEntryFocus = com.aeriotv.android.feature.main.LocalTvTabEntryFocus.current
    val pillsShownForEntry = isTv && !sidebarGroupMode && !favoritesOnly && pillItems.isNotEmpty()
    androidx.compose.runtime.DisposableEffect(isTv, tabActive, pillsShownForEntry) {
        if (isTv && tabActive) tabEntryFocus.value = if (pillsShownForEntry) pillsFocus else gridFocus
        onDispose { if (tabEntryFocus.value === pillsFocus || tabEntryFocus.value === gridFocus) tabEntryFocus.value = null }
    }

    // Stranded-focus watchdog (Frankie B. 2026-09-15). A failed hand-off out of
    // the grid (Up from the clock when the pill requester is unattached and the
    // bar's onEnter lands nowhere), or a rows rebuild that disposes the focused
    // node, can leave focus on NOTHING: [FOCUS] grid:r0 -> none with no owner
    // after it, and from there every D-pad key is declined. Reclaim only when
    // focus is outside the guide AND outside the nav, i.e. genuinely nowhere,
    // and only while no overlay is up, so this never fights the single-owner
    // model or pulls focus off chrome that legitimately has it.
    // GH #138: the route must also be RESUMED. Play on the staging banner
    // navigates to Multiview and the banner leaves with focus on it; while
    // MAIN is still composed for the exit transition (STARTED, no longer
    // RESUMED) this watchdog used to fire, pull focus back to a guide cell
    // and strand it on "none" when MAIN left, stealing it from the
    // Multiview grid host so no key reached the tiles.
    val guideResumed by androidx.compose.runtime.produceState(guideLifecycle.currentState, guideLifecycle) { guideLifecycle.currentStateFlow.collect { value = it } }
    if (isTv) {
        val stranded = guideResumed.isAtLeast(androidx.lifecycle.Lifecycle.State.RESUMED) &&
            tabActive && !rows.isEmpty && !guideHasFocus && !topNavHasFocus.value &&
            !groupSidebarOpen && !showManageGroups && !showJumpSheet && !searchActive &&
            menuFor == null && programInfoTarget == null && recordTarget == null && collectionPickerFor == null
        LaunchedEffect(stranded) {
            if (!stranded) return@LaunchedEffect
            // Let a legitimate hand-off (dialog opening, route change, the
            // bar claiming focus a frame later) settle before assuming a trap.
            delay(350L)
            while (com.aeriotv.android.ui.tv.TvColdStartFocus.pending) delay(50L)
            if (guideHasFocus || topNavHasFocus.value) return@LaunchedEffect
            if (!guideLifecycle.currentState.isAtLeast(androidx.lifecycle.Lifecycle.State.RESUMED)) {
                com.aeriotv.android.ui.tv.TvFocusTrace.guide("refocus skipped=not-resumed state=${guideLifecycle.currentState}")
                return@LaunchedEffect
            }
            val ok = runCatching { gridFocus.requestFocus() }.getOrDefault(false)
            com.aeriotv.android.ui.tv.TvFocusTrace.guide("refocus after=stranded result=$ok ${traceGates()}")
        }
    }

    // Idle boundary refocus (Logan 2026-10-03): when the focused program ends
    // while the guide sits idle, focus moves to the program now airing on the
    // same row, so Select tunes instead of opening Program Info for a show
    // that is over. Runs on the 30 s clock tick; only the cell on the row
    // changes (the locked Left/Right/clock model and the viewport are
    // untouched). Skipped after a recent key, with any sheet or menu up, and
    // whenever the grid does not hold focus.
    if (isTv) {
        val previousTick = remember { longArrayOf(nowMs) }
        LaunchedEffect(nowMs) {
            val prevTickMs = previousTick[0]
            previousTick[0] = nowMs
            if (!tabActive || !gridHasFocus || rows.isEmpty) return@LaunchedEffect
            if (System.currentTimeMillis() - lastGuideKeyAt[0] < 5_000L) return@LaunchedEffect
            if (groupSidebarOpen || showManageGroups || showJumpSheet || searchActive || menuFor != null ||
                programInfoTarget != null || recordTarget != null || collectionPickerFor != null) return@LaunchedEffect
            val row = grid.focusRow
            val moved = grid.boundaryRetarget(nowMs, prevTickMs) ?: return@LaunchedEffect
            com.aeriotv.android.ui.tv.TvFocusTrace.guide("boundary refocus row=$row from=${moved.first.title} to=${moved.second.title}")
        }
    }

    // Logan 2026-09-02: backing out of a full-screen channel lands the guide
    // on the channel that is still playing (now in the mini player), not
    // wherever the grid was before. Keyed on the mini's channel so it fires
    // on the fullscreen -> mini hand-off and stays quiet otherwise.
    var miniAnchoredFor by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(miniChannelId, rows.isEmpty, tabActive) {
        if (miniChannelId == null) miniAnchoredFor = null
        if (!tabActive) return@LaunchedEffect
        val id = miniChannelId ?: return@LaunchedEffect
        if (!isTv || rows.isEmpty) return@LaunchedEffect
        // GH #128: the guide opened from fullscreen lands on NOW as well as
        // the playing channel (a held Left used to leave it panned back).
        // A catch-up return restores its own timeline in the effect below.
        if (id != miniAnchoredFor && !GuideCatchupReturn.pending()) grid.anchorToNow(nowMs)
        miniAnchoredFor = id
        val found = grid.focusChannel(id)
        val requested = if (found) runCatching { gridFocus.requestFocus() }.getOrDefault(false) else false
        if (isTv) {
            androidx.compose.runtime.withFrameNanos { }
            com.aeriotv.android.ui.tv.TvFocusTrace.guide("refocus after=mini-channel channel=$id found=$found requested=$requested gridHasFocus=$gridHasFocus cell=${guideTraceCell(grid)} ${traceGates()}")
        }
    }

    // Returning from a catch-up replay launched from this guide: the player
    // route disposed the guide, so the grid state above is fresh (row 0, now).
    // Put the launched cell and the panned timeline back, snapped (no ease),
    // and hold grid focus against the tab bar's one-shot initial pill pull,
    // which lands a few frames after the guide recomposes.
    LaunchedEffect(rows.isEmpty, tabActive) {
        if (!isTv || !tabActive || rows.isEmpty) return@LaunchedEffect
        val ret = GuideCatchupReturn.consume() ?: return@LaunchedEffect
        val row = grid.rows.indexOfChannel(ret.channelId)
        if (row < 0) {
            com.aeriotv.android.ui.tv.TvFocusTrace.guide("refocus after=catchup-return channel=${ret.channelId} found=false ${traceGates()}")
            return@LaunchedEffect
        }
        // The played program may have aged out of the rows window (or the
        // EPG moved): fall back to the program airing now on that row.
        val playedCell = grid.rows.cellAt(row, ret.cellStartMs)
        if (playedCell != null && playedCell.startMillis == ret.cellStartMs) {
            grid.scrollViewportTo(ret.viewportStartMs, animated = false)
            grid.focusRowAt(row, ret.cellStartMs)
        } else {
            val nowCell = grid.rows.cellAt(row, System.currentTimeMillis())
            com.aeriotv.android.ui.tv.TvFocusTrace.guide("refocus after=catchup-return channel=${ret.channelId} played-cell-missing fallback=now")
            grid.focusRowAt(row, nowCell?.startMillis)
        }
        var held = 0
        var attempts = 0
        while (attempts < 20 && held < 6) {
            if (gridHasFocus) {
                held++
            } else {
                held = 0
                runCatching { gridFocus.requestFocus() }
            }
            attempts++
            delay(100L)
        }
        com.aeriotv.android.ui.tv.TvFocusTrace.guide("refocus after=catchup-return channel=${ret.channelId} found=true result=${if (gridHasFocus) "success" else "failure"} attempts=$attempts cell=${guideTraceCell(grid)} viewportStart=${grid.viewportStartMs} ${traceGates()}")
    }

    val collectionPillItem: @Composable (ChannelCollection) -> Unit = { c ->
        val token = ChannelCollection.token(c.id)
        CollectionPill(
            collection = c,
            selected = state.selectedGroup == token,
            isTv = isTv,
            onSelect = { viewModel.onGroupSelected(token) },
            onSetPlacement = { p -> collectionsVm.setPlacement(c.id, p) },
            onDelete = {
                if (state.selectedGroup == token) viewModel.onGroupSelected(fallbackGroup)
                collectionsVm.delete(c.id)
            },
        )
    }
    val openGroupMenu: () -> Boolean = {
        if (favoritesOnly) false
        else if (sidebarGroupMode) {
            sidebarOriginalGroup = state.selectedGroup
            groupSidebarOpen = true
            true
        } else runCatching { pillsFocus.requestFocus() }.getOrDefault(false)
    }
    val hostAction: (com.aeriotv.android.core.remote.GuideRemoteAction) -> Boolean = { action ->
        when (action) {
            com.aeriotv.android.core.remote.GuideRemoteAction.FOCUS_GROUP_PILLS -> openGroupMenu()
            com.aeriotv.android.core.remote.GuideRemoteAction.RESUME_PLAYER -> {
                // A Multiview left with Back to Guide: Play/Pause returns to it.
                if (isTv && com.aeriotv.android.feature.multiview.MultiviewBackground.state.value != null) onLaunchMultiview()
                else if (miniActive) miniPlayerVm.session.requestResume()
                true
            }
            com.aeriotv.android.core.remote.GuideRemoteAction.CLOSE_MINI_PLAYER -> {
                // Same close (and keep-live decision) as hold-Right in MainActivity.
                if (miniActive) {
                    (context as? com.aeriotv.android.MainActivity)?.closeTvMini("guide-action")
                        ?: miniPlayerVm.session.dismiss()
                }
                true
            }
            com.aeriotv.android.core.remote.GuideRemoteAction.PROGRAM_INFO -> {
                val row = grid.focusRow; val cell = grid.focusedCell()
                if (row >= 0 && cell != null && !cell.isPlaceholder) {
                    val ch = grid.rows.channel(row)
                    programInfoTarget = cell.toInfoTarget(ch.name, ch.dispatcharrChannelId)
                }
                true
            }
            com.aeriotv.android.core.remote.GuideRemoteAction.RECORD -> {
                val row = grid.focusRow; val cell = grid.focusedCell()
                // Same gate as the program menu's Record item.
                if (row >= 0 && cell != null && !cell.isPlaceholder && cell.endMillis > nowMs &&
                    (nowMs in cell.startMillis until cell.endMillis || canRecordToServer)
                ) {
                    val ch = grid.rows.channel(row)
                    recordTarget = cell.toInfoTarget(ch.name, ch.dispatcharrChannelId)
                }
                true
            }
            com.aeriotv.android.core.remote.GuideRemoteAction.OPEN_SEARCH -> { onOpenSearch(); true }
            com.aeriotv.android.core.remote.GuideRemoteAction.JUMP_TO_DAY -> { showJumpSheet = true; true }
            else -> false
        }
    }
    // Sidebar group selection (Logan 2026-09-14, Apple TV parity with
    // ChannelListView dismissGuideSidebar): focus PREVIEWS a group in memory
    // (persist = false). OK or Right commits (persists) and closes. Every
    // non-commit close (Back, Manage Groups dismissal, tab change, focus
    // leaving) puts back the group the sidebar opened with. Opening Manage
    // Groups does NOT restore: like Apple the preview stays behind the sheet
    // and the restore waits for the sidebar to actually close.
    val restoreSidebarGroup: () -> Unit = {
        sidebarOriginalGroup?.takeIf { it != state.selectedGroup }?.let { viewModel.onGroupSelected(it, persist = false) }
    }
    val previewSidebarGroup: (String) -> Unit = { token ->
        // A debounce that lands after close or commit, or while the Manage
        // Groups sheet is up, must not apply a group.
        if (groupSidebarOpen && !showManageGroups && sidebarOriginalGroup != null && token != state.selectedGroup) {
            viewModel.onGroupSelected(token, persist = false)
        }
    }
    val commitSidebarGroup: (String) -> Unit = { token ->
        sidebarOriginalGroup = null
        // Always persist: an equal token may only have been previewed.
        viewModel.onGroupSelected(token)
        groupSidebarOpen = false
        runCatching { gridFocus.requestFocus() }
    }
    val openSidebarManageGroups: () -> Unit = {
        manageGroupsFromSidebar = true
        showManageGroups = true
    }
    // Row the sidebar refocuses after Manage Groups: the committed group, or
    // All-style fallback when that group was just hidden (Apple
    // manageGroupsSheet onDismiss resets to fallbackGroup the same way).
    val sidebarActiveToken = (sidebarOriginalGroup ?: state.selectedGroup).let { token ->
        if (token in groups || token.startsWith(ChannelCollection.TOKEN_PREFIX)) token else fallbackGroup
    }
    LaunchedEffect(sidebarActiveToken) {
        // Keep Back's restore target in step with a hidden-group fallback.
        if (sidebarOriginalGroup != null && sidebarOriginalGroup != sidebarActiveToken && allGroupNames.isNotEmpty()) {
            sidebarOriginalGroup = sidebarActiveToken
        }
    }
    // Safety net for every non-commit close: restore, then drop the snapshot.
    LaunchedEffect(groupSidebarOpen) {
        if (groupSidebarOpen) return@LaunchedEffect
        manageGroupsFromSidebar = false
        restoreSidebarGroup()
        sidebarOriginalGroup = null
    }
    LaunchedEffect(tabActive) {
        if (!tabActive && groupSidebarOpen) groupSidebarOpen = false
    }
    val sidebarPlaylistId = state.playlist?.id
    LaunchedEffect(sidebarPlaylistId) {
        // The new playlist restores its own saved group; the old snapshot
        // belongs to the previous playlist and must not be put back.
        if (groupSidebarOpen) { sidebarOriginalGroup = null; groupSidebarOpen = false }
    }
    // Android#137: double Back on the TV mini emits guideTopRequests
    // (Navigation.kt TvMiniPlayerOverlay onJumpToTop), but the guide rebuild
    // (fd886fab) dropped the only collector, so the request went nowhere in
    // every Play Channels In mode. Land now + the top channel; the mini keeps
    // playing.
    val tuneModeVm: com.aeriotv.android.feature.settings.SettingsViewModel = hiltViewModel()
    val tuneInMiniMode by tuneModeVm.guideTuneInMini.collectAsStateWithLifecycle(initialValue = false)
    val tabActiveNow by androidx.compose.runtime.rememberUpdatedState(tabActive)
    val miniActiveNow by androidx.compose.runtime.rememberUpdatedState(miniActive)
    LaunchedEffect(miniPlayerVm.session) {
        miniPlayerVm.session.guideTopRequests.collect {
            if (!tabActiveNow) return@collect
            android.util.Log.i(
                "AerioTV",
                "[GUIDE] double Back -> top channel (window=${if (miniActiveNow) "mini" else "fullscreen"} tuneIn=${if (tuneInMiniMode) "mini" else "fullscreen"})",
            )
            grid.back(System.currentTimeMillis())
            runCatching { gridListState.scrollToItem(0) }
            runCatching { gridFocus.requestFocus() }
        }
    }
    BackHandler(enabled = tabActive && groupSidebarOpen) {
        restoreSidebarGroup()
        sidebarOriginalGroup = null
        groupSidebarOpen = false
        runCatching { gridFocus.requestFocus() }
    }

    // With a mini player up on TV, Back belongs to the player host
    // (TvMiniPlayerOverlay: expand / double-Back to top), exactly as the old
    // guide. Phone and tablet have no mini Back host, so the ladder stays
    // installed there: a Back after the player minimized fell through to the
    // Activity and closed AerioTV (onn tablet 2026-10-14, audio-only mini).
    val uiModeTv = (androidx.compose.ui.platform.LocalConfiguration.current.uiMode and
        android.content.res.Configuration.UI_MODE_TYPE_MASK) ==
        android.content.res.Configuration.UI_MODE_TYPE_TELEVISION
    // Radio Mode double Back (Logan 2026-10-14, Apple TV parity): on TV a
    // second Back inside PlayerDoubleBack.WINDOW_MS stops Radio Mode, as
    // Back twice closes the full-screen player. As on tvOS, the first Back
    // only opens the window: its single-Back action (jump to the top channel,
    // or Exit AerioTV? at the top) runs when the window lapses, so a Back
    // twice leaves the guide focus where it was. Outside Radio Mode the
    // ladder runs at once, as before.
    val radioBackScope = androidx.compose.runtime.rememberCoroutineScope()
    val radioPendingBack = remember { arrayOfNulls<kotlinx.coroutines.Job>(1) }
    // Radio stop focus restore (Apple TV parity, Streamer 2026-10-15): the
    // cell focused when Radio Mode started or at a stop trigger's press-down
    // (double Back, hold Right, banner Stop) gets focus back after the stop,
    // instead of focus falling to Search when the banner leaves.
    val radioFocusAnchor = remember { arrayOfNulls<Pair<String, Long>>(1) }
    val radioCaptureFocus: () -> Unit = {
        val row = grid.focusRow
        if (row in 0 until grid.rows.size) {
            radioFocusAnchor[0] = grid.rows.channel(row).id to grid.focusCellStartMs
        }
    }
    val radioSessionNow by com.aeriotv.android.feature.player.RadioMode.state.collectAsStateWithLifecycle()
    // Origin cell at Radio Mode start: banner Stop restores here (tvOS
    // parity 2026-10-15); presses on the way to the banner never move it.
    val radioOriginAnchor = remember { arrayOfNulls<Pair<String, Long>>(1) }
    LaunchedEffect(radioSessionNow != null) {
        if (radioSessionNow != null && isTv) {
            radioCaptureFocus()
            radioOriginAnchor[0] = radioFocusAnchor[0]
        }
    }
    DisposableEffect(Unit) {
        com.aeriotv.android.feature.player.RadioMode.captureGuideFocus = { radioCaptureFocus() }
        onDispose { com.aeriotv.android.feature.player.RadioMode.captureGuideFocus = null }
    }
    LaunchedEffect(Unit) {
        com.aeriotv.android.feature.player.RadioMode.stops.collect { reason ->
            if (!isTv || !tabActive) return@collect
            if (reason != "double Back" && reason != "hold-right" && reason != "card") return@collect
            val anchor = if (reason == "card") radioOriginAnchor[0] ?: radioFocusAnchor[0] else radioFocusAnchor[0]
            radioFocusAnchor[0] = null
            radioOriginAnchor[0] = null
            if (grid.rows.size == 0) return@collect
            val row = anchor?.let { grid.rows.indexOfChannel(it.first) } ?: -1
            val how: String
            if (row >= 0) {
                val cell = grid.rows.cellAt(row, anchor!!.second)
                if (cell != null && cell.startMillis == anchor.second) {
                    grid.focusRowAt(row, anchor.second)
                    how = "cell"
                } else {
                    grid.focusRowAt(row, grid.rows.cellAt(row, System.currentTimeMillis())?.startMillis)
                    how = "airing"
                }
            } else {
                grid.focusRowAt(0, grid.rows.cellAt(0, System.currentTimeMillis())?.startMillis)
                how = "top"
            }
            // Hold grid focus while the banner leaves and its focus falls.
            var held = 0
            var attempts = 0
            while (attempts < 20 && held < 6) {
                if (gridHasFocus) held++ else { held = 0; runCatching { gridFocus.requestFocus() } }
                attempts++
                delay(100L)
            }
            android.util.Log.i(com.aeriotv.android.ui.tv.TvFocusTrace.TAG, "[FOCUS] radio stop restore -> ${guideTraceCell(grid)} via=$how reason=$reason result=${if (gridHasFocus) "success" else "failure"} attempts=$attempts")
        }
    }
    val runGuideBackLadder: () -> Unit = {
        when (grid.back(nowMs)) {
            GuideGridState.BackStep.RESTORED_NOW_AND_TOP, GuideGridState.BackStep.TOP -> Unit
            GuideGridState.BackStep.NONE -> {
                // Logan 2026-09-01: Back at the top of the guide never closes
                // the app silently; the group stays as picked. Since 2026-10-14
                // the end of the ladder raises the Exit AerioTV? confirm (the
                // same one the Activity's root Back fallback shows).
                (context.findActivity() as? com.aeriotv.android.MainActivity)
                    ?.requestExitPrompt("guide-top")
            }
        }
    }
    // Remote Control map, guide Back (Logan 2026-10-15): on TV a single Back
    // runs the guide map's backShort slot (default BACK_LADDER, the ladder
    // above). Phone and tablet keep the ladder; their Back is not a remote.
    val gridRunner = remember { arrayOfNulls<(com.aeriotv.android.core.remote.GuideRemoteAction) -> Boolean>(1) }
    val runGuideMapped: (com.aeriotv.android.core.remote.GuideRemoteAction, String) -> Unit = { action, press ->
        android.util.Log.i("AerioTV", "[GUIDE] $press Back -> ${action.wire}")
        when (action) {
            com.aeriotv.android.core.remote.GuideRemoteAction.BACK_LADDER -> runGuideBackLadder()
            com.aeriotv.android.core.remote.GuideRemoteAction.NONE -> Unit
            else -> { (gridRunner[0] ?: hostAction)(action) }
        }
    }
    val runMappedBack: () -> Unit = {
        if (uiModeTv) {
            runGuideMapped(remoteMap.guideAction(com.aeriotv.android.core.remote.RemoteSlot.BACK_SHORT, sidebarGroupMode), "single")
        } else {
            runGuideBackLadder()
        }
    }
    val guideBackEnabled = tabActive && !(miniActive && uiModeTv) && !groupSidebarOpen && menuFor == null && programInfoTarget == null && recordTarget == null
    BackHandler(enabled = guideBackEnabled) {
        if (miniActive) android.util.Log.i("AerioTV", "[GUIDE] Back with mini up (touch): guide ladder, app stays open")
        if (miniPlayerVm.session.expandInFlight()) {
            android.util.Log.i("AerioTV", "[GUIDE] Back ignored: mini expand in flight")
            return@BackHandler
        }
        val pending = radioPendingBack[0]
        if (pending != null && pending.isActive) {
            // Second Back inside the window: drop the deferred single Back.
            pending.cancel()
            radioPendingBack[0] = null
            if (com.aeriotv.android.feature.player.RadioMode.isActive) {
                com.aeriotv.android.feature.player.RadioMode.stop(context, "double Back")
            }
            return@BackHandler
        }
        val radioTv = uiModeTv && com.aeriotv.android.feature.player.RadioMode.isActive
        if (radioTv) {
            // First Back of a possible double: anchor the cell at press-down.
            radioCaptureFocus()
            radioPendingBack[0] = radioBackScope.launch {
                kotlinx.coroutines.delay(com.aeriotv.android.feature.player.PlayerDoubleBack.WINDOW_MS)
                radioPendingBack[0] = null
                runMappedBack()
            }
        } else {
            runMappedBack()
        }
    }
    // Hold Back (guide map backLong, Logan 2026-10-15). Registered with the
    // Activity only while this guide owns Back on TV and the slot is mapped;
    // MainActivity then runs it on a hold released before the exit-prompt
    // hold (EXIT_PROMPT_HOLD_MS), and a longer hold still raises Exit AerioTV?.
    val backLongAction = remoteMap.guideAction(com.aeriotv.android.core.remote.RemoteSlot.BACK_LONG, sidebarGroupMode)
    val holdBackOwned = uiModeTv && guideBackEnabled &&
        backLongAction != com.aeriotv.android.core.remote.GuideRemoteAction.NONE
    val latestBackLong = androidx.compose.runtime.rememberUpdatedState(backLongAction)
    androidx.compose.runtime.DisposableEffect(holdBackOwned) {
        val activity = context.findActivity() as? com.aeriotv.android.MainActivity
        val hook: () -> Unit = { runGuideMapped(latestBackLong.value, "hold") }
        if (holdBackOwned) activity?.guideHoldBackAction = hook
        onDispose { if (activity?.guideHoldBackAction === hook) activity.guideHoldBackAction = null }
    }

    // Phone drawer rows: collections where their pill placement puts them,
    // around the Favorites / All / group tokens (Apple PhoneGroupDrawer).
    val groupLabelFor: (String) -> String = { token ->
        ChannelCollection.idFromToken(token)
            ?.let { id -> collections.firstOrNull { it.id == id }?.name }
            ?: com.aeriotv.android.feature.livetv.groupSidebarLabel(token)
    }

    var guideTopPx by remember { androidx.compose.runtime.mutableFloatStateOf(0f) }
    Box(modifier = modifier.fillMaxSize().onGloballyPositioned { guideTopPx = it.positionInRoot().y }
        .onFocusChanged { guideHasFocus = it.hasFocus }
        .onPreviewKeyEvent { e ->
            if (e.type == KeyEventType.KeyDown) lastGuideKeyAt[0] = System.currentTimeMillis()
            // Trace only, never consumes: a D-pad key inside the guide that the
            // grid node will not see (focus is on the banner, pills, sidebar...).
            if (isTv && !gridHasFocus && e.type == KeyEventType.KeyDown) {
                val name = when (e.key) {
                    Key.DirectionCenter, Key.Enter, Key.NumPadEnter -> "Center"
                    else -> com.aeriotv.android.ui.tv.TvFocusTrace.nameOf(e)
                }
                if (name != null) com.aeriotv.android.ui.tv.TvFocusTrace.key(name, false, "guide-screen(focus-not-in-grid) ${traceGates()}")
            }
            false
        }) {
    Row(modifier = Modifier.fillMaxSize()) {
    if (groupSidebarOpen && !isTv) {
        GuideGroupSidebarPane(
            groups = groups,
            selectedToken = state.selectedGroup,
            defaultToken = defaultGroupToken,
            onSetDefault = viewModel::setDefaultGroup,
            topOffset = 0.dp,
            onCommit = commitSidebarGroup,
            onManageGroups = openSidebarManageGroups,
            hiddenGroupCount = hiddenGroups.size,
        )
    }
    Column(modifier = Modifier.weight(1f).fillMaxSize().then(if (isTv) Modifier else Modifier.statusBarsPadding())) {
        if (!isTv) {
            // Phone / tablet: NO title bar (Logan 2026-09-05, Apple parity).
            // The header row carries the groups control, the pills or the
            // active group name + count, Search, Sort and the List / Guide
            // toggle; the Column above already applies the status-bar inset.
            LiveTvPhoneHeaderRow(
                sidebarMode = phoneSidebarMode,
                activeGroupLabel = groupLabelFor(state.selectedGroup),
                channelCount = displayChannels.size,
                onOpenGroups = { phoneDrawerOpen = true },
                hiddenGroupsCount = hiddenGroups.size,
                onManageGroups = { showManageGroups = true },
                showPills = !favoritesOnly && (groups.size > 1 || collections.isNotEmpty() || hiddenGroups.isNotEmpty()),
                groups = groups,
                selectedGroup = state.selectedGroup,
                onSelectGroup = { viewModel.onGroupSelected(it) },
                defaultToken = defaultGroupToken,
                onSetDefault = viewModel::setDefaultGroup,
                collections = collections,
                collectionPillItem = collectionPillItem,
                searchActive = searchActive,
                onToggleSearch = { searchActive = !searchActive; if (!searchActive) viewModel.onSearchQueryChange("") },
                sortMode = state.sortMode,
                onSortModeChange = viewModel::onSortModeChange,
                onJumpToDay = { showJumpSheet = true },
                canToggleViewMode = canToggleViewMode,
                showingGuide = viewMode == LiveTVViewMode.Guide,
                onToggleViewMode = onToggleViewMode,
            )
            if (searchActive) {
                OutlinedTextField(
                    value = state.searchQuery,
                    onValueChange = viewModel::onSearchQueryChange,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                    singleLine = true,
                    placeholder = { Text("Search channels") },
                    leadingIcon = { Icon(Icons.Outlined.Search, contentDescription = null) },
                    trailingIcon = if (state.searchQuery.isNotEmpty()) {
                        { IconButton(onClick = { viewModel.onSearchQueryChange("") }) { Icon(Icons.Filled.Close, contentDescription = "Clear search") } }
                    } else null,
                    shape = RoundedCornerShape(14.dp),
                    keyboardOptions = com.aeriotv.android.ui.textfield.aerioTextFieldKeyboardOptions(imeAction = ImeAction.Search),
                )
            }
        }
        val previewBanner: @Composable () -> Unit = {
            if (previewMode) {
                val topNav = com.aeriotv.android.feature.main.LocalTvTopNavFocusRequester.current
                val pillsShown = !sidebarGroupMode && !favoritesOnly
                GuidePreviewBanner(
                    program = previewProgram,
                    channel = previewChannel,
                    nowMs = nowMs,
                    onOpenInfo = {
                        previewProgram?.let { cell ->
                            programInfoTarget = cell.toInfoTarget(previewChannel?.name ?: "", previewChannel?.dispatcharrChannelId)
                        }
                    },
                    descriptionFocus = bannerFocus,
                    downTarget = if (queGuide) gridFocus else if (pillsShown) pillsFocus else gridFocus,
                    upTarget = if (queGuide && pillsShown) pillsFocus else topNav,
                    // tvOS: Down from the description lands on the clock when
                    // there is no pill row between them.
                    onDown = if (!queGuide && pillsShown) null else ({ clockSelectTrigger += 1; true }),
                    miniActive = miniActive,
                    // tvOS pulls the banner 28 pt up under the tab bar so eight
                    // rows still fit (ChannelListView, Logan 2026-09-05); halved.
                    modifier = if (queGuide) Modifier else Modifier.layout { measurable, constraints ->
                        val lift = GuidePreviewBanner.tvLift.roundToPx()
                        val placeable = measurable.measure(constraints)
                        layout(placeable.width, (placeable.height - lift).coerceAtLeast(0)) { placeable.placeRelative(0, -lift) }
                    },
                )
            }
        }
        val groupPills: @Composable () -> Unit = {
            val pillsContext = androidx.compose.ui.platform.LocalContext.current
            if (isTv && !sidebarGroupMode && !favoritesOnly) GroupPills(
                onManageGroups = { showManageGroups = true },
                hiddenGroupCount = hiddenGroups.size,
                defaultToken = defaultGroupToken,
                onSetDefault = { token ->
                    // Brief confirmation (Logan 2026-10-10); the pin on the pill
                    // is the lasting mark. Same toggle as the sidebar rows:
                    // holding the current default clears it.
                    val clearing = token == defaultGroupToken
                    val label = pillItems.firstOrNull { it.first == token }?.second ?: token
                    com.aeriotv.android.ui.tv.TvFocusTrace.guide("default group ${if (clearing) "cleared" else "set"} token=$token")
                    android.widget.Toast.makeText(
                        pillsContext,
                        if (clearing) "Default group cleared" else "Live TV opens on $label",
                        android.widget.Toast.LENGTH_SHORT,
                    ).show()
                    viewModel.setDefaultGroup(token)
                },
                items = pillItems,
                selected = state.selectedGroup,
                onSelect = { viewModel.onGroupSelected(it) },
                rowFocus = pillsFocus,
                onDown = {
                    val target = if (queGuide && previewProgram?.description?.isNotBlank() == true) bannerFocus else gridFocus
                    runCatching { target.requestFocus() }.getOrDefault(false)
                },
                leadInset = if (queGuide) 16.dp else railWidth,
                queStyle = queGuide,
            )
        }
        if (queGuide) {
            groupPills()
            previewBanner()
        } else {
            previewBanner()
            groupPills()
        }
        // Multiview staging banner (iOS EPGGuideView.stagingBanner), shared
        // with the List, below the header / pills and above the grid (iOS
        // placement); restored after the guide rebuild dropped it.
        // Phones and tablets show the Multiview dock card above the nav bar
        // instead (MainScaffold); only TV keeps this in-view banner.
        if (isTv) com.aeriotv.android.feature.multiview.MultiviewStagingBanner(
            store = multiviewStore,
            isTv = isTv,
            onLaunchMultiview = onLaunchMultiview,
            // The grid restores the cell it last focused.
            onReturnFocus = { runCatching { gridFocus.requestFocus() }.getOrDefault(false) },
            playFocusRequester = stagingPlayFocus,
            upTarget = if (!sidebarGroupMode && !favoritesOnly && pillItems.isNotEmpty()) pillsFocus else null,
            downTarget = gridFocus,
            // Radio start keeps focus on the chosen cell (Logan 2026-10-15).
            radioKeepFocus = {
                val held = gridHasFocus ||
                    runCatching { gridFocus.requestFocus() }.getOrDefault(false)
                android.util.Log.d(com.aeriotv.android.ui.tv.TvFocusTrace.TAG, "[FOCUS] radio start keep -> ${guideTraceCell(grid)} result=${if (held) "success" else "failure"}")
            },
        )
        // Channel Preview OFF + corner mini Active: the mini has no banner art
        // card to share a baseline with, so it gets its OWN slot here -- a
        // reserved band immediately above the time header whose measured bottom
        // IS the timeline top. The mini's bottom edge is anchored to that
        // (published below), so the timeline and every channel row start below
        // the mini instead of being drawn under it (Logan 2026-09-13).
        val reserveMiniSlot = isTv && !previewMode && miniActive
        if (reserveMiniSlot) {
            Spacer(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(MiniPlayerChrome.miniHeight + MiniPlayerChrome.miniGap)
                    .onGloballyPositioned {
                        MiniPlayerChrome.timelineTopPx.value = it.boundsInRoot().bottom
                    },
            )
        }
        androidx.compose.runtime.DisposableEffect(reserveMiniSlot) {
            onDispose { if (reserveMiniSlot) MiniPlayerChrome.timelineTopPx.value = 0f }
        }
        // Shift guide: the pane docks at the grid's top edge and only the
        // grid (time header + rows) narrows; the banner, pills and mini slot
        // above keep the full width. The pane slides in over its own slot, so
        // the grid width changes once instead of re-laying rows every frame.
        Row(modifier = Modifier.fillMaxSize()) {
        androidx.compose.animation.AnimatedVisibility(
            visible = sidebarShiftMode && groupSidebarOpen,
            enter = androidx.compose.animation.slideInHorizontally(
                animationSpec = androidx.compose.animation.core.tween(180),
            ) { -it },
            exit = androidx.compose.animation.ExitTransition.None,
        ) {
            GuideGroupSidebarPane(
                groups = groups,
                selectedToken = state.selectedGroup,
                defaultToken = defaultGroupToken,
                onSetDefault = viewModel::setDefaultGroup,
                topOffset = 0.dp,
                onPreview = previewSidebarGroup,
                onCommit = commitSidebarGroup,
                refocusToken = sidebarActiveToken,
                refocusRequest = sidebarRefocusRequest,
                onManageGroups = openSidebarManageGroups,
                hiddenGroupCount = hiddenGroups.size,
            )
        }
        Box(modifier = Modifier.weight(1f).fillMaxSize()) {
        if (rows.isEmpty && favoritesOnly && favoritesOrNull == null) {
            // Favorites not loaded yet: draw nothing rather than flash the
            // empty-group notice for a frame (Streamer 2026-09-03).
        } else if (rows.isEmpty) {
            EmptyGroupNotice(
                isSearching = state.searchQuery.isNotBlank(),
                onShowAllChannels = { viewModel.onGroupSelected(fallbackGroup) },
                modifier = Modifier.fillMaxSize(),
            )
        } else {
            val gridContent: @Composable () -> Unit = {
            androidx.compose.runtime.CompositionLocalProvider(
                com.aeriotv.android.core.category.LocalCategoryPalette provides categoryPalette,
            ) {
            GuideGrid(
                state = grid,
                listState = gridListState,
                nowMs = nowMs,
                hourWidth = hourWidth,
                rowHeight = rowHeight,
                railWidth = railWidth,
                headerHeight = headerHeight,
                favoriteIds = favoriteIds,
                recordingWindows = recordingWindows,
                isTv = isTv,
                onPlay = { channel, cell ->
                    // Already-aired + within the catch-up window: play it from
                    // the start right away (no menu first). The rail tap hands
                    // us the cell airing NOW, so tapping the logo still tunes live.
                    if (!cell.isPlaceholder && channel.canReplay(cell, nowMs)) {
                        android.util.Log.i("GuideGrid", "[GUIDE] select on aired cell -> catch-up from start (${channel.name} @${cell.startMillis})")
                        startCatchup(channel, cell)
                    }
                    // OK on the channel already in the corner mini promotes the
                    // mini to fullscreen instead of re-tuning the same stream.
                    else if (isTv && miniChannelId == channel.id) miniPlayerVm.session.requestResume()
                    else onChannelClick(channel)
                },
                onOpenMenu = { channel, cell -> menuFor = channel to cell; menuGuard.arm() },
                jumpLabel = jumpLabel,
                onClockTap = snapToNow,
                onOpenJumpToDay = { showJumpSheet = true },
                // Favorites (TV): no pills above the grid, so UP must leave
                // through the content group's exit redirect (which lands on
                // the SELECTED tab's pill); a direct request on the bar's
                // requester landed on the leftmost pill and, with
                // selection-follows-focus, switched to Live TV.
                onLeaveTop = {
                    // The background Multiview banner shares the Play slot.
                    val bannerUp = (stagingOn && stagedMultiview.isNotEmpty()) ||
                        com.aeriotv.android.feature.multiview.MultiviewBackground.state.value != null ||
                        com.aeriotv.android.feature.player.RadioMode.isActive
                    val stagingUp = isTv && bannerUp &&
                        runCatching { stagingPlayFocus.requestFocus() }.getOrDefault(false)
                    com.aeriotv.android.ui.tv.TvFocusTrace.guide("leave-top staging-banner=$stagingUp")
                    if (stagingUp) true else when {
                        // Channel Preview with no pill row: the banner's
                        // description is the next stop above the clock.
                        previewMode && (queGuide || favoritesOnly || sidebarGroupMode) && previewProgram?.description?.isNotBlank() == true ->
                            runCatching { bannerFocus.requestFocus() }.getOrDefault(false)
                        favoritesOnly -> guideFocusManager.moveFocus(androidx.compose.ui.focus.FocusDirection.Up)
                        sidebarGroupMode -> false
                        else -> runCatching { pillsFocus.requestFocus() }.getOrDefault(false)
                    }
                },
                compact = previewMode,
                clockSelectTrigger = clockSelectTrigger,
                // GH #127: phone / tablet cell info button (TV has the long-press menu).
                programInfoButtonMode = programInfoButtonMode,
                onOpenProgramInfo = if (isTv) null else { channel, cell ->
                    programInfoTarget = cell.toInfoTarget(channel.name, channel.dispatcharrChannelId)
                },
                remoteAction = { slot -> remoteMap.guideAction(slot, sidebarGroupMode) },
                onHostAction = hostAction,
                onActionRunner = { gridRunner[0] = it },
                focusRequester = gridFocus,
                // Shift guide: the docked pane owns focus; the grid rejoins on
                // close. Disabled only once focus has left the grid, so turning
                // it off never clears focus onto the shell (the nav bar selects
                // on focus) before the pane's rows claim it.
                focusEnabled = !(sidebarShiftMode && groupSidebarOpen && !gridHasFocus),
                onGridFocusChanged = { gridHasFocus = it },
                traceGates = traceGates,
                modifier = Modifier.fillMaxSize(),
            )
            }
            }
            if (isTv) gridContent() else PullToRefreshBox(
                isRefreshing = state.isLoading,
                onRefresh = { viewModel.refreshPlaylist() },
                modifier = Modifier.fillMaxSize(),
            ) { gridContent() }
        }
        }
        }
    }
    }
    // tvOS drawer (ChannelListView 2026-09-05): the rail overlays the guide
    // under the time header, the rest of the tab dims 45%, the grid does not
    // shift. Right or OK commit, Back reverts (handlers unchanged). The Shift
    // guide sidebar layout docks the pane in the guide Column instead.
    if (isTv) {
        // Under the time header wherever it sits: below the Channel Preview
        // banner (lifted 14 dp under the bar) when that layout is on. Drawn
        // in the shell's full-screen slot so the scrim dims the whole screen,
        // nav bar included (tvOS); the pane is offset by the guide's own top.
        val drawerTop = headerHeight + when {
            queGuide -> QueGuidePreviewHeight + (if (favoritesOnly) 0.dp else 60.dp)
            previewMode -> GuidePreviewBanner.height - 14.dp
            else -> 0.dp
        }
        val density = androidx.compose.ui.platform.LocalDensity.current
        val guideTop = with(density) { guideTopPx.toDp() }
        val drawerSlot = com.aeriotv.android.feature.main.LocalTvFullScreenOverlay.current
        val drawerOverlay: @Composable () -> Unit = {
            Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.45f)))
            GuideGroupSidebarPane(
                groups = groups,
                selectedToken = state.selectedGroup,
                defaultToken = defaultGroupToken,
                onSetDefault = viewModel::setDefaultGroup,
                topOffset = guideTop + drawerTop,
                onPreview = previewSidebarGroup,
                onCommit = commitSidebarGroup,
                refocusToken = sidebarActiveToken,
                refocusRequest = sidebarRefocusRequest,
                onManageGroups = openSidebarManageGroups,
                hiddenGroupCount = hiddenGroups.size,
            )
        }
        if (drawerSlot != null || sidebarShiftMode) {
            // As with Jump To: the shell reseats focus (Refresh circle) once
            // the overlay is gone, after the commit asked for the grid. Shift
            // guide needs the same retry: the grid turns focusable again only
            // on the next composition, and its width settles (re-clamping the
            // viewport) before focus lands.
            var drawerWasOpen by remember { mutableStateOf(false) }
            LaunchedEffect(groupSidebarOpen) {
                if (groupSidebarOpen) { drawerWasOpen = true; return@LaunchedEffect }
                if (!drawerWasOpen) return@LaunchedEffect
                drawerWasOpen = false
                repeat(3) { androidx.compose.runtime.withFrameNanos { } }
                val requested = runCatching { gridFocus.requestFocus() }.getOrDefault(false)
                androidx.compose.runtime.withFrameNanos { }
                com.aeriotv.android.ui.tv.TvFocusTrace.guide("refocus after=sidebar-close requested=$requested result=${if (gridHasFocus) "success" else "failure"} ${traceGates()}")
            }
        }
        if (sidebarShiftMode) {
            // Docked beside the grid in the guide Column above; nothing here.
        } else if (drawerSlot != null) {
            androidx.compose.runtime.DisposableEffect(groupSidebarOpen) {
                if (groupSidebarOpen) drawerSlot.value = drawerOverlay
                else if (drawerSlot.value === drawerOverlay) drawerSlot.value = null
                onDispose { if (drawerSlot.value === drawerOverlay) drawerSlot.value = null }
            }
        } else if (groupSidebarOpen) {
            drawerOverlay()
        }
    }
    // TV Jump To: drawn in the shell's full-screen slot so the scrim covers
    // the tab bar too; drawn here when no shell provides one.
    val fullScreenSlot = com.aeriotv.android.feature.main.LocalTvFullScreenOverlay.current
    val jumpOverlay: @Composable () -> Unit = {
        com.aeriotv.android.feature.livetv.GuideJumpTvOverlay(
            daysBack = epgDaysBackOffered.coerceIn(0, 14),
            daysAhead = epgDaysAheadOffered.coerceIn(1, 14),
            onJump = startJump,
            onBackToNow = snapToNow,
            onDismiss = { showJumpSheet = false; runCatching { gridFocus.requestFocus() } },
        )
    }
    if (isTv && fullScreenSlot != null) {
        androidx.compose.runtime.DisposableEffect(showJumpSheet) {
            fullScreenSlot.value = if (showJumpSheet) jumpOverlay else null
            onDispose { if (fullScreenSlot.value === jumpOverlay) fullScreenSlot.value = null }
        }
        // The slot's teardown drops focus onto the shell's first focusable
        // (the Refresh circle) AFTER onDismiss asked for the grid; ask again
        // once the overlay is gone.
        var jumpWasOpen by remember { mutableStateOf(false) }
        LaunchedEffect(showJumpSheet) {
            if (showJumpSheet) { jumpWasOpen = true; return@LaunchedEffect }
            if (!jumpWasOpen) return@LaunchedEffect
            jumpWasOpen = false
            repeat(3) { androidx.compose.runtime.withFrameNanos { } }
            val requested = runCatching { gridFocus.requestFocus() }.getOrDefault(false)
            androidx.compose.runtime.withFrameNanos { }
            com.aeriotv.android.ui.tv.TvFocusTrace.guide("refocus after=jump-close requested=$requested result=${if (gridHasFocus) "success" else "failure"} ${traceGates()}")
        }
    } else if (showJumpSheet && isTv) {
        jumpOverlay()
    }
    if (!isTv) {
        val drawerTokens = remember(groups, collections) {
            collections.filter { it.placement == ChannelCollection.PLACEMENT_BEGINNING }.map { ChannelCollection.token(it.id) } +
                groups +
                collections.filter { it.placement != ChannelCollection.PLACEMENT_BEGINNING }.map { ChannelCollection.token(it.id) }
        }
        PhoneGroupDrawerHost(
            open = phoneDrawerOpen,
            onDismiss = { phoneDrawerOpen = false },
            tokens = drawerTokens,
            selected = state.selectedGroup,
            defaultToken = defaultGroupToken,
            labelFor = groupLabelFor,
            onSelect = { viewModel.onGroupSelected(it) },
            // A drag in the drawer is a manual order (the saved order is only
            // read in Manual mode), so the mode flips with the first drag.
            onReorder = { order ->
                settingsVm.setGroupSortMode(GroupSortMode.Manual.name)
                settingsVm.setGroupOrder(order)
            },
            onManageGroups = { phoneDrawerOpen = false; showManageGroups = true },
            onSetDefault = viewModel::setDefaultGroup,
            hiddenGroupCount = hiddenGroups.size,
        )
    }
    }

    collectionPickerFor?.let { (chId, chName) ->
        AddToCollectionFlow(
            channelId = chId,
            channelName = chName,
            isTv = isTv,
            collections = collections,
            onToggleMember = collectionsVm::toggleMember,
            onCreate = collectionsVm::create,
            onClose = { collectionPickerFor = null; runCatching { gridFocus.requestFocus() } },
        )
    }

    if (showManageGroups) {
        if (isTv) {
            TvGroupPicker(
                allGroups = allGroupNames, hiddenGroups = effectiveHidden,
                onDismiss = {
                    showManageGroups = false
                    if (manageGroupsFromSidebar && groupSidebarOpen) {
                        // Apple TV parity: only the sheet closes. The sidebar
                        // stays open with focus on the active group row; its
                        // own preview / commit / Back rules carry on from there.
                        manageGroupsFromSidebar = false
                        sidebarRefocusRequest++
                    } else {
                        // Opened elsewhere: close the sidebar too, since leaving
                        // it open with focus in the grid made a later held Left
                        // a no-op (already "open"). Logan 2026-09-02.
                        manageGroupsFromSidebar = false
                        restoreSidebarGroup(); sidebarOriginalGroup = null; groupSidebarOpen = false
                        runCatching { gridFocus.requestFocus() }
                    }
                },
                reorderEnabled = true, sortMode = groupSortMode,
                onSortModeChange = { settingsVm.setGroupSortMode(it.name) },
                // Only meaningful with the Sidebar Menu group selector.
                sidebarLayout = if (groupSelector == "sidebar") guideSidebarLayout else null,
                onSidebarLayoutChange = { settingsVm.setGuideSidebarLayout(it) },
                onCommit = { hidden, order ->
                    com.aeriotv.android.feature.livetv.applyManagedGroups(
                        hidden, hiddenGroups, recentGroupVisible,
                        setHiddenGroups = { settingsVm.setHiddenGroups(it) },
                        setRecentVisible = { settingsVm.setRecentGroupVisible(it) },
                    )
                    order?.let { settingsVm.setGroupOrder(it) }
                },
            )
        } else {
            ManageGroupsSheet(
                allGroups = allGroupNames, hiddenGroups = effectiveHidden,
                onSave = { committed ->
                    com.aeriotv.android.feature.livetv.applyManagedGroups(
                        committed, hiddenGroups, recentGroupVisible,
                        setHiddenGroups = { settingsVm.setHiddenGroups(it) },
                        setRecentVisible = { settingsVm.setRecentGroupVisible(it) },
                    )
                },
                onDismiss = { showManageGroups = false },
                reorderEnabled = true, sortMode = groupSortMode,
                onSortModeChange = { settingsVm.setGroupSortMode(it.name) },
                onReorder = { settingsVm.setGroupOrder(it) },
            )
        }
    }

    menuFor?.let { (channel, cell) ->
        val notEnded = cell.endMillis > nowMs
        val isLive = nowMs in cell.startMillis until cell.endMillis
        // Apple liveTVMultiviewMenuState (Logan 2026-10-11): the channel in
        // the mini player is already staged channel 1, so its item stays
        // "Add to Multiview", disabled; others stage on top of it.
        val mvMenu = com.aeriotv.android.feature.multiview.multiviewMenuState(
            channel.id, mvPlayingSeed?.id, stagedMultiview,
        )
        val inMultiview = mvMenu == com.aeriotv.android.feature.multiview.MultiviewMenuState.Remove
        val mvPlayingHere = mvMenu == com.aeriotv.android.feature.multiview.MultiviewMenuState.AddDisabled
        val key = reminderKey(channel.name, cell.title, cell.startMillis)
        val isFavorite = channel.id in favoriteIds
        val isRecent = channel.id in recentChannelIds
        // A Multiview running in the background takes adds up to its own
        // tile limit (MultiviewBackground.toggleTile), not the staging 4.
        val mvCap = if (com.aeriotv.android.feature.multiview.MultiviewBackground.state.value != null) {
            multiviewStore.maxTiles
        } else 4
        val atCap = stagedMultiview.size >= mvCap
        val canAddToMultiview = channel.url.isNotBlank() && (!atCap || inMultiview) && !mvPlayingHere
        val canRecord = notEnded && (isLive || canRecordToServer)
        val replayable = !cell.isPlaceholder && channel.canReplay(cell, nowMs)
        // Apple TV order (Logan 2026-09-02): Favorites, Multiview, Collection,
        // Program Info, Record from Now, then the Android-only extras.
        val watchFromStart: () -> Unit = { startCatchup(channel, cell) }
        val reminderSet = key in reminderKeys
        val toggleReminder: () -> Unit = {
            if (reminderSet) remindersVm.cancelReminder(key)
            else remindersVm.setReminder(channel.name, cell.title, cell.startMillis, cell.endMillis, channel.id)
        }
        if (!isTv) {
            // Phone and tablet: Material 3 modal bottom sheet (the platform's
            // long-press action surface; Logan 2026-09-09), items in the iPhone
            // context-menu order. Jump To lives on the clock cell here.
            val sheetActions = buildList {
                if (isLive && channel.url.isNotBlank()) add(TvMenuAction("Watch", Icons.Filled.PlayArrow) { com.aeriotv.android.feature.player.RadioSelect.watchAsVideo { onChannelClick(channel) } })
                else if (replayable) add(TvMenuAction("Watch from Start", Icons.Outlined.History, onClick = watchFromStart))
                com.aeriotv.android.feature.player.radioMenuAction(context, channel, if (isLive) cell.title else "") { miniPlayerVm.dismiss() }?.let { add(it) }
            com.aeriotv.android.feature.player.radioFlagMenuAction(context, channel, state.playlist, viewModel)?.let { add(it) }
                add(TvMenuAction(if (isFavorite) "Remove from Favorites" else "Add to Favorites", if (isFavorite) Icons.Outlined.StarOutline else Icons.Filled.Star) { favoritesVm.toggle(channel) })
                // GH #130 (Apple d051505): only while the channel is in Recently Watched.
                if (isRecent) add(TvMenuAction("Remove from Recently Watched", Icons.Outlined.History, destructive = true) { settingsVm.removeRecentChannel(channel.id) })
                add(TvMenuAction(if (inMultiview) "Remove from Multiview" else "Add to Multiview", Icons.Outlined.GridView, enabled = canAddToMultiview) { multiviewStore.stageToggle(channel) })
                add(TvMenuAction("Add Channel to Collection", Icons.Outlined.CreateNewFolder) { collectionPickerFor = channel.id to channel.name })
                if (!cell.isPlaceholder) {
                    add(TvMenuAction("Program Info", Icons.Outlined.Info) { programInfoTarget = cell.toInfoTarget(channel.name, channel.dispatcharrChannelId) })
                    if (canRecord) add(TvMenuAction(if (isLive) "Record from Now" else "Record", Icons.Outlined.FiberManualRecord) { recordTarget = cell.toInfoTarget(channel.name, channel.dispatcharrChannelId) })
                    if (cell.startMillis > nowMs) add(TvMenuAction(if (reminderSet) "Cancel Reminder" else "Set Reminder", Icons.Outlined.Notifications, onClick = toggleReminder))
                }
            }
            com.aeriotv.android.feature.livetv.LiveTvActionSheet(
                title = cell.title,
                subtitle = channel.name,
                actions = sheetActions,
                onDismiss = { menuFor = null },
            )
        } else {
        val actions = buildList {
            // Apple order on TV: Watch first only when a plain Select would
            // open Radio Mode (declared radio or Radio Mode by Default), then
            // Radio Mode.
            if (isLive && channel.url.isNotBlank() && com.aeriotv.android.feature.player.RadioSelect.picksOpenRadio(channel)) {
                add(TvMenuAction("Watch", Icons.Filled.PlayArrow) { com.aeriotv.android.feature.player.RadioSelect.watchAsVideo { onChannelClick(channel) } })
            }
            com.aeriotv.android.feature.player.radioMenuAction(context, channel, if (isLive) cell.title else "") { miniPlayerVm.dismiss() }?.let { add(it) }
            com.aeriotv.android.feature.player.radioFlagMenuAction(context, channel, state.playlist, viewModel)?.let { add(it) }
            add(TvMenuAction(if (isFavorite) "Remove from Favorites" else "Add to Favorites") { favoritesVm.toggle(channel) })
            if (isRecent) add(TvMenuAction("Remove from Recently Watched", destructive = true) { settingsVm.removeRecentChannel(channel.id) })
            add(TvMenuAction(if (inMultiview) "Remove from Multiview" else "Add to Multiview", enabled = canAddToMultiview) { multiviewStore.stageToggle(channel) })
            add(TvMenuAction("Add Channel to Collection") { collectionPickerFor = channel.id to channel.name })
            // Jump To and Back to Now live on the clock cell now (tvOS parity).
            if (!cell.isPlaceholder) {
                add(TvMenuAction("Program Info") { programInfoTarget = cell.toInfoTarget(channel.name, channel.dispatcharrChannelId) })
                if (canRecord) add(TvMenuAction(if (isLive) "Record from Now" else "Record") { recordTarget = cell.toInfoTarget(channel.name, channel.dispatcharrChannelId) })
                if (replayable) add(TvMenuAction("Watch from Start", onClick = watchFromStart))
                if (cell.startMillis > nowMs) {
                    add(TvMenuAction(if (reminderSet) "Cancel Reminder" else "Set Reminder", onClick = toggleReminder))
                }
            }
        }
        TvActionMenuDialog(title = cell.title, actions = actions, guard = menuGuard, onDismiss = { menuFor = null })
        }
    }
    if (showJumpSheet && !isTv) {
        com.aeriotv.android.feature.livetv.GuideJumpSheet(
            // Days follow the EPG that is actually loaded (Logan 2026-09-10),
            // back no further than the grid's own history window.
            daysBack = epgDaysBackOffered.coerceIn(0, 14),
            daysAhead = epgDaysAheadOffered.coerceIn(1, 14),
            onJump = startJump,
            onBackToNow = snapToNow,
            onDismiss = { showJumpSheet = false; runCatching { gridFocus.requestFocus() } },
        )
    }
    programInfoTarget?.let { target ->
        ProgramInfoSheet(target = target, onDismiss = { programInfoTarget = null; runCatching { gridFocus.requestFocus() } })
    }
    recordTarget?.let { target ->
        RecordProgramSheet(target = target, onDismiss = { recordTarget = null; runCatching { gridFocus.requestFocus() } })
    }
}

@Composable
private fun GroupPills(
    items: List<Pair<String, String>>,
    selected: String,
    onSelect: (String) -> Unit,
    /** Focus entry for the whole row: lands on the selected pill. */
    rowFocus: FocusRequester,
    onDown: () -> Boolean,
    /** Logan 2026-09-03: pills mode had no way to show/hide groups (the
     *  sidebar has its Manage button, the pill row had none). Trailing pill. */
    onManageGroups: () -> Unit = {},
    hiddenGroupCount: Int = 0,
    /** tvOS: the first pill's left edge sits on the program column. */
    leadInset: androidx.compose.ui.unit.Dp = 12.dp,
    /** GH #81 default group: long OK on a pill sets/clears it (the same
     *  toggle the sidebar rows use); the default pill carries a thumbtack. */
    defaultToken: String = "",
    onSetDefault: ((String) -> Unit)? = null,
    queStyle: Boolean = false,
) {
    val listState = rememberLazyListState()
    val topNav = com.aeriotv.android.feature.main.LocalTvTopNavFocusRequester.current
    com.aeriotv.android.feature.livetv.RevealPrependedGroups(listState, items.map { it.first }, leadingItems = if (queStyle) 0 else 1)
    // The row's focus entry used to be a requester on the FIRST pill only.
    // LazyRow disposes pills scrolled out of view, so once the user walked
    // right and picked a later group the first pill was gone, the requester
    // was unattached, and Up from the guide clock went nowhere (the user was
    // stuck on the clock). The requester now sits on the row itself (a focus
    // group) and entry is routed to the SELECTED pill, the tvOS behaviour.
    // LazyRow index: the Manage Groups circle is item 0, pills follow.
    val selectedIndex = items.indexOfFirst { it.first == selected }.let { if (it < 0) -1 else it + if (queStyle) 0 else 1 }
    val selectedPillFocus = remember { FocusRequester() }
    var rowHasFocus by remember { mutableStateOf(false) }
    // A selection made from OUTSIDE the row (sidebar, remote shortcut) glides
    // the new pill into view. The row is never scrolled when focus merely
    // leaves it: where the user left it is where it stays.
    LaunchedEffect(selectedIndex) {
        if (rowHasFocus || selectedIndex < 0) return@LaunchedEffect
        if (listState.layoutInfo.visibleItemsInfo.none { it.index == selectedIndex }) {
            val viewport = listState.layoutInfo.viewportEndOffset
            listState.animateScrollToItem(selectedIndex, scrollOffset = -(viewport / 3))
        }
    }
    LazyRow(
        state = listState,
        contentPadding = PaddingValues(
            start = leadInset,
            end = 12.dp,
            top = if (queStyle) 12.dp else 6.dp,
            bottom = if (queStyle) 8.dp else 6.dp,
        ),
        // The 22dp Manage Groups circle sat on the row's top edge, above the
        // taller pills' center (Streamer 2026-10-11); every item centers.
        verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = if (queStyle) 60.dp else 44.dp)
            .focusRequester(rowFocus)
            .onFocusChanged { rowHasFocus = it.hasFocus }
            .onPreviewKeyEvent { event ->
                if (queStyle && event.type == KeyEventType.KeyDown && event.key == Key.Menu) {
                    onManageGroups()
                    true
                } else false
            }
            // focusProperties must precede focusGroup() to apply to the group.
            .focusProperties {
                if (topNav != null) up = topNav
                onEnter = {
                    // Selected pill when it is in view; otherwise the default
                    // search picks the first visible pill, so entry always
                    // lands inside the row as the user left it.
                    if (listState.layoutInfo.visibleItemsInfo.any { it.index == selectedIndex }) {
                        selectedPillFocus.requestFocus()
                    }
                }
            }
            .focusGroup(),
    ) {
        // Logan 2026-10-10 (explicit decision): the round Manage Groups
        // button sits to the LEFT of the first group pill on every pill row.
        // Entry focus still goes to the SELECTED pill (selectedPillFocus);
        // Left from the first pill lands here.
        if (!queStyle) item(key = "__manage__") {
            com.aeriotv.android.feature.livetv.TvManageGroupsCircle(
                hiddenGroupsCount = hiddenGroupCount,
                onClick = onManageGroups,
                modifier = Modifier
                    .padding(end = 8.dp)
                    .onPreviewKeyEvent { e ->
                        if (e.type == KeyEventType.KeyDown && e.key == Key.DirectionDown) onDown() else false
                    },
            )
        }
        items(items, key = { it.first }) { (group, label) ->
            // TV chrome canon (ui/tv/TvChrome.kt): capsule, accent fill when
            // selected, white ring focused+selected / accent ring focused+
            // unselected. One focus target only (clickable() inside TvPill).
            val interaction = remember { MutableInteractionSource() }
            val pillModifier = Modifier
                .padding(end = 8.dp)
                .then(if (group == selected) Modifier.focusRequester(selectedPillFocus) else Modifier)
                .onPreviewKeyEvent { e ->
                    if (e.type == KeyEventType.KeyDown && e.key == Key.DirectionDown) onDown() else false
                }
            if (queStyle) {
                QueGuideGroupPill(
                    label = when (group) {
                        com.aeriotv.android.feature.playlist.PlaylistViewModel.ALL_GROUPS -> "All channels"
                        com.aeriotv.android.feature.playlist.PlaylistViewModel.FAVORITES_GROUP -> "Favourites"
                        else -> label
                    },
                    selected = group == selected,
                    favorite = group == com.aeriotv.android.feature.playlist.PlaylistViewModel.FAVORITES_GROUP,
                    onClick = { onSelect(group) },
                    onLongClick = onSetDefault?.let { set -> { set(group) } },
                    interactionSource = interaction,
                    modifier = pillModifier,
                )
            } else {
                com.aeriotv.android.ui.tv.TvPill(
                    label = label,
                    selected = group == selected,
                    onClick = { onSelect(group) },
                    icon = if (group == com.aeriotv.android.feature.playlist.PlaylistViewModel.FAVORITES_GROUP) Icons.Filled.Star else null,
                    interactionSource = interaction,
                    onLongClick = onSetDefault?.let { set -> { set(group) } },
                    trailingPin = group == defaultToken ||
                        (group == com.aeriotv.android.feature.playlist.PlaylistViewModel.ALL_GROUPS && defaultToken.isBlank()),
                    modifier = pillModifier,
                )
            }
        }
        if (queStyle) item(key = "__manage__") {
            // Keep management available while navigating the categories;
            // the program-focused view keeps the reference's clean pill row.
            if (rowHasFocus) {
                com.aeriotv.android.feature.livetv.TvManageGroupsCircle(
                    hiddenGroupsCount = hiddenGroupCount,
                    onClick = onManageGroups,
                    modifier = Modifier.onPreviewKeyEvent { event ->
                        event.type == KeyEventType.KeyDown && event.key == Key.DirectionDown && onDown()
                    },
                )
            }
        }
    }
}

/** The guide's 40dp category capsules follow the reference's larger TV type. */
@Composable
private fun QueGuideGroupPill(
    label: String,
    selected: Boolean,
    favorite: Boolean,
    onClick: () -> Unit,
    onLongClick: (() -> Unit)?,
    interactionSource: MutableInteractionSource,
    modifier: Modifier = Modifier,
) {
    val focused by interactionSource.collectIsFocusedAsState()
    val guard = rememberTvMenuGuard()
    val fill = when {
        focused -> RoyalBlueFocus
        selected -> RoyalBlueRaised
        else -> RoyalBlueSurface
    }
    Row(
        modifier = modifier
            .height(40.dp)
            .clip(CircleShape)
            .background(fill)
            .border(2.dp, if (focused) Color.White else Color.Transparent, CircleShape)
            .combinedClickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = guard.wrap(onClick),
                onLongClick = onLongClick?.let { action -> { action(); guard.arm() } },
            )
            .padding(horizontal = 16.dp),
        verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
        horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(6.dp),
    ) {
        if (favorite) Icon(Icons.Filled.Star, null, tint = Color.White, modifier = Modifier.size(18.dp))
        Text(label, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}

private const val QUANTUM_MS = 15 * 60_000L

/**
 * Guide extent before a playlist is loaded, matching PlaylistEntity's own
 * epgRetentionDays default.
 */
private const val GUIDE_DAYS_DEFAULT = 7

/**
 * The guide cell a TV catch-up replay was launched from, plus the timeline
 * start at launch. Set just before the player route opens and consumed once
 * by the guide that composes after it pops. Process memory only.
 */
internal object GuideCatchupReturn {
    data class Target(val channelId: String, val cellStartMs: Long, val viewportStartMs: Long)

    @Volatile private var pending: Target? = null

    fun set(channelId: String, cellStartMs: Long, viewportStartMs: Long) {
        pending = Target(channelId, cellStartMs, viewportStartMs)
    }

    fun consume(): Target? = pending.also { pending = null }

    fun pending(): Boolean = pending != null
}

/** Share of a phone guide row (98dp) taken by secondary lines; drives Subtext Size growth. */
internal const val GUIDE_PHONE_SUBTEXT_SHARE = 0.6f

/** Share of a tablet / TV guide row taken by secondary lines. */
internal const val GUIDE_SUBTEXT_SHARE = 0.45f

/**
 * Holds the guide's [GuideGridState] while the guide is out of composition
 * (player route), one per guide flavour (Live TV, Favorites). [take] hands it
 * to exactly one live composition and resets it for entry; [give] returns it
 * on dispose.
 */
/** Largest window roll [GuideScreen] absorbs by keeping the retained rows. */
private const val WINDOW_ROLL_REUSE_MAX_MS = 2 * 3_600_000L

internal object RetainedGuideGrid {
    private val held = HashMap<Boolean, GuideGridState>()
    private val firstPaintLogged = java.util.concurrent.atomic.AtomicBoolean(false)

    /** True exactly once per process. */
    fun markFirstPaintLogged(): Boolean = firstPaintLogged.compareAndSet(false, true)
    private val firstCatalogPaintLogged = java.util.concurrent.atomic.AtomicBoolean(false)

    /** True exactly once per process. */
    fun markFirstCatalogPaintLogged(): Boolean = firstCatalogPaintLogged.compareAndSet(false, true)

    fun take(favoritesOnly: Boolean, initialViewportStartMs: Long): GuideGridState {
        val kept = synchronized(held) { held.remove(favoritesOnly) }
        return kept?.also { it.resetForEntry(initialViewportStartMs) }
            ?: GuideGridState(initialViewportStartMs = initialViewportStartMs)
    }

    fun give(favoritesOnly: Boolean, state: GuideGridState) {
        synchronized(held) { held[favoritesOnly] = state }
    }
}

/** Per-group rows viewport for the guide's group switch (Logan 2026-10-04). */
internal class GuideGroupViewport {
    data class Saved(val firstChannelId: String, val offsetPx: Int, val focusChannelId: String)
    var installedGroup: String? = null
    val saved = HashMap<String, Saved>()
}

/** Matches GuideGrid's LANE_ROWS: focus deeper than this would move the restored first row. */
private const val GROUP_RESTORE_LANE_ROWS = 6
