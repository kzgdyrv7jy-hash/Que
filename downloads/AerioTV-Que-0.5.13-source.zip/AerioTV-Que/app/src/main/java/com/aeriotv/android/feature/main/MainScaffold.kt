package com.aeriotv.android.feature.main

import com.aeriotv.android.core.data.db.entity.canSwitchStream
import com.aeriotv.android.ui.theme.textAccent
import com.aeriotv.android.ui.theme.AppTheme
import com.aeriotv.android.ui.theme.LocalAppTheme
import com.aeriotv.android.ui.theme.LocalIsDarkTheme
import com.aeriotv.android.ui.theme.LocalTrueBlack
import com.aeriotv.android.ui.theme.appBackground
import kotlinx.coroutines.launch
import com.aeriotv.android.core.data.db.entity.dispatcharrCanViewDvr
import com.aeriotv.android.core.data.db.entity.dispatcharrCanViewVod
import com.aeriotv.android.core.data.db.entity.dispatcharrCanViewSeries
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.togetherWith
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.focusGroup
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.dropShadow
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FiberSmartRecord
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Cast
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusProperties
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.layout.layout
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.zIndex
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.lifecycle.repeatOnLifecycle
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.invisibleToUser
import androidx.compose.runtime.toMutableStateList
import androidx.compose.runtime.mutableStateListOf
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import com.aeriotv.android.core.data.M3UChannel
import com.aeriotv.android.core.data.guideMatchKey
import com.aeriotv.android.core.playback.AerioExoPlayerHolder
import com.aeriotv.android.feature.dvr.DvrTabContent
import com.aeriotv.android.feature.dvr.DvrViewModel
import com.aeriotv.android.feature.favorites.FavoritesTabContent
import com.aeriotv.android.feature.favorites.FavoritesViewModel
import com.aeriotv.android.feature.livetv.LiveTVTabContent
import com.aeriotv.android.feature.livetv.LiveTVViewMode
import com.aeriotv.android.feature.livetv.LocalLiveTvSessionMode
import com.aeriotv.android.feature.livetv.rememberLiveTvFormFactor
import com.aeriotv.android.feature.miniplayer.MiniPlayerRow
import com.aeriotv.android.feature.miniplayer.MiniPlayerSession
import com.aeriotv.android.feature.miniplayer.MiniPlayerViewModel
import com.aeriotv.android.feature.onboarding.ChooseSourceTypeScreen
import com.aeriotv.android.feature.onboarding.ConfigureSourceScreen
import com.aeriotv.android.feature.ondemand.OnDemandTabContent
import com.aeriotv.android.feature.ondemand.OnDemandViewModel
import com.aeriotv.android.feature.playlist.PlaylistViewModel
import com.aeriotv.android.feature.playlist.nowPlaying
import com.aeriotv.android.feature.settings.AddMoreCategoriesScreen
import com.aeriotv.android.feature.settings.AddPlaylistWizardStep
import com.aeriotv.android.feature.settings.AppearanceSettingsScreen
import com.aeriotv.android.feature.settings.DeveloperSettingsScreen
import com.aeriotv.android.feature.settings.DvrSettingsScreen
import com.aeriotv.android.feature.settings.GeneralSettingsScreen
import com.aeriotv.android.feature.settings.LiveTvSettingsScreen
import com.aeriotv.android.feature.settings.MoviesAndTvShowsSettingsScreen
import com.aeriotv.android.feature.settings.PlayerSettingsScreen
import com.aeriotv.android.feature.settings.SettingsRootContent
import com.aeriotv.android.feature.settings.DefaultSettingsPaneSelection
import com.aeriotv.android.feature.settings.SettingsRoute
import com.aeriotv.android.feature.settings.SettingsScreen
import com.aeriotv.android.feature.settings.SettingsSection
import com.aeriotv.android.feature.settings.SettingsSubScreenPlaceholder
import com.aeriotv.android.feature.settings.SettingsViewModel
import com.aeriotv.android.ui.adaptive.LocalTabBarBottomInset
import com.aeriotv.android.ui.adaptive.rememberViewport
import com.aeriotv.android.ui.settings.rememberIsTvDevice
import com.aeriotv.android.feature.settings.SettingsTvRailHost
import com.aeriotv.android.feature.settings.SettingsPaneSplit
import com.aeriotv.android.feature.settings.SettingsTwoPaneHost
import com.aeriotv.android.feature.settings.rememberSettingsNavState
import com.aeriotv.android.feature.settings.rememberSettingsPaneSelection
import com.aeriotv.android.feature.settings.isPaneBaseline
import com.aeriotv.android.feature.settings.settingsDeepLinkPageNeedsPlaylist
import com.aeriotv.android.feature.settings.settingsRouteForDeepLinkPage
import com.aeriotv.android.feature.settings.visibleSettingsSections
import com.aeriotv.android.ui.tv.tvFocusScale

/**
 * App-scoped [FocusRequester] for the Android TV top tab bar's "current"
 * focusable surface (the Row of pills, with [Modifier.focusRestorer] so a
 * re-entry restores the previously-focused pill).
 *
 * Section-level composables (GuideScreen first) read this and attach
 * `Modifier.focusProperties { up = it }` to their top-most focusable so
 * D-pad UP from the top row of the guide jumps focus back to the pills
 * instead of being trapped inside the `focusGroup()` (audit task #57).
 *
 * `null` on phone shell - the CompositionLocal is only filled on TV.
 */
val LocalTvTopNavFocusRequester = staticCompositionLocalOf<FocusRequester?> { null }

/** True while any pill in the Android TV top tab bar holds focus. Tab
 *  content reads it so a launch-focus grab never yanks focus out of the bar
 *  while the user is still walking it (Logan 2026-09-02: Live TV -> Favorites
 *  -> the Favorites guide stole focus mid-walk, every further Right went
 *  into the grid). */
val LocalTvTopNavHasFocus = staticCompositionLocalOf<androidx.compose.runtime.State<Boolean>> {
    androidx.compose.runtime.mutableStateOf(false)
}

/** Where D-pad DOWN from the tab bar should land inside the current tab.
 *  A tab sets it (On Demand: its current sub-tab pill) and clears it on
 *  dispose; null keeps Compose's geometric search. Consulted by the bar's
 *  Down exit, which is honoured where a group's onEnter was not. */
val LocalTvTabEntryFocus = staticCompositionLocalOf<androidx.compose.runtime.MutableState<FocusRequester?>> {
    androidx.compose.runtime.mutableStateOf(null)
}

/** Move focus to the CURRENTLY SELECTED tab's pill, returning whether it
 *  landed. Back from a TV page's content uses it: the first Back parks focus
 *  on the page's own pill (Movies / TV Shows / DVR) and only a second Back,
 *  with the bar focused, reaches the scaffold's "Back goes to the home tab"
 *  rule (Logan 2026-09-11: Back on the hero jumped straight to Live TV).
 *  `null` on the phone shell. */
val LocalTvRequestCurrentTabPill = staticCompositionLocalOf<(() -> Boolean)?> { null }

/**
 * TV chrome-collapse channel. Content screens write `true` while the user is
 * scrolled down a long surface (the On Demand poster grids first) and the top
 * tab bar shrinks out of the way so an extra poster row fits on screen.
 *
 * The bar is never UNMOUNTED for this: its pills are the target of
 * FocusRequester.requestFocus() calls (the content's D-pad UP exit redirect),
 * which throws on a detached node, so an AnimatedVisibility-style hide would
 * crash the first UP press while collapsed. [collapsibleChrome] instead
 * shrinks the bar to a 1px, alpha-0 strip; the pills stay attached and
 * focusable, and focus arriving on the bar expands it back.
 *
 * `null` on the phone shell -- only the TV shell provides a state.
 */
val LocalTvChromeCollapsed =
    staticCompositionLocalOf<androidx.compose.runtime.MutableState<Boolean>?> { null }

/**
 * How far (px) the active TV page has scrolled while its top section is
 * still on screen: the tab bar slides off in step with the page (tvOS: the
 * bar is part of the scroll, Logan 2026-09-10). 0 = fully shown.
 */
val LocalTvChromeScroll =
    staticCompositionLocalOf<androidx.compose.runtime.MutableState<Int>?> { null }

/**
 * TV full-screen overlay slot: a tab sets a composable here to draw ABOVE
 * the whole shell (tab bar included) without a Dialog window. The guide's
 * Jump To sheet uses it so its scrim covers the bar (Logan 2026-09-10).
 */
val LocalTvFullScreenOverlay =
    staticCompositionLocalOf<androidx.compose.runtime.MutableState<(@Composable () -> Unit)?>?> { null }

/**
 * Top-level scaffold once a playlist is loaded. Mirrors iOS MainTabView with the
 * caveat that tabs are CONDITIONAL on content (see [visibleTabs]) - matching
 * iOS, the test-server screenshots show only 4 tabs not 5.
 */
@Composable
fun MainScaffold(
    onChannelClick: (M3UChannel) -> Unit,
    /** Channel flips that already target the cast receiver (cast card
     *  Switch / up/down, Change Cast Device handoff): no play-where prompt. */
    onCastChannel: (M3UChannel) -> Unit = onChannelClick,
    /** Expanding the local mini: always plays here, no prompt. */
    onChannelResumeLocal: (M3UChannel) -> Unit = onChannelClick,
    onMovieClick: (String) -> Unit = {},
    onSeriesClick: (Int) -> Unit = {},
    onEpisodeResume: (String) -> Unit = {},
    onResumeMovie: (String) -> Unit = {},
    /** Media center hero: play a movie directly (resumes from saved progress). */
    onPlayMovie: (String) -> Unit = {},
    /** Media center hero "Play from Beginning": start at 0 and KEEP the
     *  Continue Watching row (tvOS MoviesView:1507-1511). */
    onPlayMovieFromStart: (String) -> Unit = onPlayMovie,
    onEpisodeResumeFromStart: (String) -> Unit = onEpisodeResume,
    /** (playbackUrl, title, dispatcharrRecordingId or -1). */
    onPlayRecording: (String, String, Int) -> Unit = { _, _, _ -> },
    /** Catch-up (task #136): url, title, progStartMillis, progEndMillis, panelTz. */
    onPlayCatchup: (String, String, String, Long, Long, String, String) -> Unit = { _, _, _, _, _, _, _ -> },
    onLaunchMultiview: () -> Unit = {},
    onWatchLive: (String, String, Boolean, Long, Int?) -> Unit = { _, _, _, _, _ -> },
    onWatchFromBeginning: (String, String, Boolean, Long, Int?, Boolean) -> Unit = { _, _, _, _, _, _ -> },
    onOpenSearch: () -> Unit = {},
    viewModel: PlaylistViewModel = hiltViewModel(),
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    // Keep Recent Channels Live: app-bar indicator + dialog live HERE (not
    // in GuideScreen) so the TV circle is part of the nav bar's existing
    // focus row and works from every content tab.
    val retainedVm: com.aeriotv.android.feature.livetv.RetainedChannelsViewModel = hiltViewModel()
    val retainedList by retainedVm.retained.collectAsStateWithLifecycle()
    // KEPT badges (guide rail, channel list) read this set.
    val retainedIds = remember(retainedList) { retainedList.mapTo(HashSet()) { it.channelId } }
    val tuneRetained: (String) -> Unit = { id ->
        state.channels.firstOrNull { it.id == id }?.let(onChannelClick)
    }
    var showRetainedDialog by remember { mutableStateOf(false) }
    if (showRetainedDialog) {
        com.aeriotv.android.feature.livetv.RetainedChannelsDialog(
            viewModel = retainedVm,
            onJumpToChannel = { id ->
                state.channels.firstOrNull { it.id == id }?.let(onChannelClick)
            },
            onDismiss = { showRetainedDialog = false },
        )
    }
    // Multiview staging dock card + sheet (phones and tablets, Logan 2026-10-06).
    val multiviewStore = com.aeriotv.android.feature.multiview.rememberMultiviewStoreHandle()
    // A staged set that holds exactly one live channel plays in the standard
    // single player, not a one-tile Multiview (Logan 2026-10-11): every Play
    // path below (TV banner, dock card, sheet Play Here) reads this wrapper.
    @Suppress("NAME_SHADOWING")
    val onLaunchMultiview: () -> Unit = launch@{
        val staged = multiviewStore.selected.value
        val only = staged.singleOrNull()
        if (only != null && only.kind == com.aeriotv.android.feature.multiview.TileKind.Live) {
            val channel = state.channels.firstOrNull { it.id == only.id }
            if (channel != null) {
                android.util.Log.i("AerioMV", "[MV] staged single ${channel.name}: standard player")
                com.aeriotv.android.feature.multiview.MultiviewBackground.stop()
                multiviewStore.clear()
                multiviewStore.setStaging(false)
                onChannelClick(channel)
                return@launch
            }
        }
        onLaunchMultiview()
    }
    var showMultiviewSheet by remember { mutableStateOf(false) }
    val favoritesVm: FavoritesViewModel = hiltViewModel()
    // null until the DB emits: on the phone, backing out of the player
    // recomposes this scaffold from scratch and an empty INITIAL list read as
    // "no favorites" for a frame, the Favorites tab vanished, and the tabs
    // fallback below bounced a Favorites-first user to Live TV (GH #81
    // follow-up, PsykoRider 2026-09-02).
    val favoritesOrNull by favoritesVm.all.collectAsStateWithLifecycle()
    val favorites = favoritesOrNull ?: emptyList()
    // Show the Favorites tab only when the user has at least one favorite
    // that ALSO exists in the active playlist. The raw DB count would keep
    // the tab pinned to the bottom bar after a playlist switch left stale
    // orphan rows pointing at channel ids that no longer exist - the user
    // would see the tab, tap it, and find an empty "No Favorites" body
    // even though the DB count was non-zero.
    // GH #81: an EMPTY channel list is "still loading" (playlist refresh,
    // return from the player, sync apply), not "no favorites". Dropping the
    // flag there removed the Favorites tab for a frame, and the tabs
    // fallback below bounced the user to Live TV every time. Keep the last
    // verdict until channels are back; an empty favorites list is a real
    // DB emission and still retires the tab.
    var lastRenderableFavorites by rememberSaveable { mutableStateOf(false) }
    val hasRenderableFavorites = remember(favoritesOrNull, state.channels) {
        if (favoritesOrNull == null) return@remember lastRenderableFavorites
        if (favorites.isEmpty()) return@remember false
        if (state.channels.isEmpty()) return@remember lastRenderableFavorites
        val visibleIds = state.channels.asSequence().map { it.id }.toHashSet()
        favorites.any { it.channelId in visibleIds }.also { lastRenderableFavorites = it }
    }
    // Dynamic On Demand + DVR tabs (iOS MainTabView.hasVOD / hasRecordings
    // parity). Both ViewModels are hoisted here so the tabs can appear / vanish
    // based on actual content, NOT just the source type. hiltViewModel() resolves
    // to the SAME instance the tab body uses (shared ViewModelStoreOwner), so this
    // adds no duplicate fetch; it just makes the eager load drive tab visibility.
    val onDemandVm: OnDemandViewModel = hiltViewModel()
    // Collect only the bits the scaffold needs, de-duplicated: the catalog
    // walk emits a new state per page (~100 pages after launch) and collecting
    // the whole state here recomposed the entire scaffold, every tab included,
    // on each one (Streamer 2026-09-03: "every tab redraws" for the first
    // 30-45 s).
    val onDemandState by remember(onDemandVm) {
        onDemandVm.state
            .map { VodPresence.from(it) }
            .distinctUntilChanged()
    }.collectAsStateWithLifecycle(initialValue = VodPresence.from(onDemandVm.state.value))
    // Per-playlist VOD opt-in gate (iOS HomeView.swift:317 servers.filter
    // { $0.supportsVOD && $0.vodEnabled }). Read directly off the active
    // playlist so the tab hides immediately when the user toggles "Fetch On
    // Demand from this playlist" OFF at Add / Edit time, without waiting for
    // the next OnDemandViewModel refresh to flip unsupportedSource. If the
    // playlist hasn't loaded yet the default is true so we don't suppress
    // the tab on a slow cold launch.
    // LIVE active playlist row, not `state.playlist`. The latter is a snapshot
    // frozen when the state was last written, so the AerioCaps capability probe
    // that lands after launch was invisible to every gate below: the Streamer
    // restored 40050 movies, ran the forced sweep, and STILL hid the Movies tab
    // because `moviesDenied` was computed from the pre-probe row and retired the
    // pill on every recomposition (2026-09-15). Falls back to the snapshot only
    // until the first DB emission.
    val livePlaylist by viewModel.activePlaylistLive
        .collectAsStateWithLifecycle(initialValue = null)
    val capsPlaylist = livePlaylist ?: state.playlist
    val activePlaylistVodEnabled = capsPlaylist?.vodEnabled ?: true
    // hasVOD: any movie/series loaded, OR still loading its library. The loading
    // bridge keeps the tab from flickering "absent -> present" on cold launch /
    // source switch; a source that finishes with zero VOD hides the tab entirely.
    val hasVodContent = activePlaylistVodEnabled && !onDemandState.unsupportedSource && (
        onDemandState.hasMovies ||
            onDemandState.hasSeries ||
            onDemandState.isLoading ||
            onDemandState.isLoadingSeries ||
            // XC: the cheap probe found categories but deferred the heavy walk
            // until the tab is opened -- show the tab on the probe result alone.
            onDemandState.hasDeferredXtreamContent
        )
    val dvrVm: DvrViewModel = hiltViewModel()
    val dvrState by dvrVm.state.collectAsStateWithLifecycle()
    // hasRecordings: at least one recording (scheduled / recording / completed,
    // server or local) for the active source. Scheduling from the guide makes the
    // tab appear; deleting the last recording makes it disappear.
    // hasRecordingsHint: persisted last-session verdict so the tab shows from
    // the first frame after launch / playlist switch instead of popping in when
    // the server list arrives; retires as soon as the real list loads.
    // Dispatcharr 0.30 dvr_access "none": server recordings are not
    // listable; only a local recording in progress shows the tab.
    // Capability.CanViewDvr. Denied (dvr_access "none" / level < 1) hides the
    // server list; Unknown keeps it, so an unprobed account is never downgraded.
    // DENIED is a real, user-visible state change (like favorites emptied), so
    // it must also retire an already-shown tab below; the sticky rule must not
    // pin it. Note state.playlist is NULL for the first frames after launch:
    // that reads as Unknown (tab allowed), and the persisted hint would show
    // the tab, so the retire-on-Denied pass below is what actually hides it
    // once the active playlist and its capability snapshot land.
    val dvrDenied = capsPlaylist?.dispatcharrCanViewDvr() == false
    val dvrListable = !dvrDenied
    // Local recordings belong to the DEVICE, not the server: an in-progress
    // capture or any saved local row keeps the tab regardless of dvr_access.
    val hasLocalDvrContent = dvrState.isLocalRecordingActive ||
        dvrState.recordings.any { it.source == DvrViewModel.Source.Local }
    val hasRecordings = (dvrListable && (dvrState.recordings.isNotEmpty() || dvrState.hasRecordingsHint)) ||
        hasLocalDvrContent
    // Sticky tabs (Streamer 2026-09-03, "every tab flashes"): the loaders
    // behind DVR and On Demand briefly report "nothing" while they transition
    // (On Demand dropped out for 0.8 s between its movie and series passes;
    // DVR flickers on its list refresh). When that happens while the user is
    // on that pill, the focused pill is removed, Compose drops focus to the
    // leftmost control, selection follows to Live TV and the tab flashes. A
    // tab that has been shown stays for the rest of the playlist session;
    // only a real user action retires it (favorites emptied, On Demand
    // switched off for the playlist, or an unsupported source).
    // Media center (phone/tablet): Movies and TV Shows tabs, each shown while
    // its library has content or is still loading. TV keeps On Demand.
    // Every form factor now (Android TV joined 2026-09-10 with TvMediaPage).
    val isTvShell = rememberLiveTvFormFactor().isTv
    val splitVod = true
    // Same three-state gate as DVR: Denied retires the tab even once shown,
    // Unknown (including the null playlist on the first frames) keeps it.
    val moviesDenied = capsPlaylist?.dispatcharrCanViewVod() == false
    val seriesDenied = capsPlaylist?.dispatcharrCanViewSeries() == false
    val vodSourceOk = activePlaylistVodEnabled && !onDemandState.unsupportedSource
    val hasMoviesContent = vodSourceOk && !moviesDenied &&
        (onDemandState.hasMovies || onDemandState.isLoading || onDemandState.hasDeferredXtreamContent)
    val hasSeriesContent = vodSourceOk && !seriesDenied &&
        (onDemandState.hasSeries || onDemandState.isLoadingSeries || onDemandState.hasDeferredXtreamContent)
    val stickyTabs = remember(capsPlaylist?.id ?: state.playlist?.id) { mutableSetOf<AppTab>() }
    val tabs = run {
        val live = visibleTabs(
            // Phone/tablet: Favorites is a pinned Live TV group, not a tab (Apple parity).
            // Favorites is the pinned Live TV pill on every form factor (tvOS dropped the tab 2026-09-05).
            hasFavorites = false,
            hasVod = hasVodContent,
            hasRecordings = hasRecordings,
            splitVod = splitVod,
            hasMovies = hasMoviesContent,
            hasSeries = hasSeriesContent,
        )
        stickyTabs += live
        stickyTabs -= AppTab.Favorites
        if (!vodSourceOk) { stickyTabs -= AppTab.OnDemand; stickyTabs -= AppTab.Movies; stickyTabs -= AppTab.TVShows }
        // A DENIED capability verdict is a real state change, not the transient
        // "empty list / still loading" the sticky rule exists to absorb, so it
        // retires the tab even after it has been shown. This is the dvr_access
        // "none" case: the null playlist on the first frames reads as Unknown,
        // the persisted hint paints the DVR pill, and without this the tab was
        // pinned for the session once the verdict arrived. Local recordings
        // still win over a server denial.
        if (dvrDenied && !hasLocalDvrContent) stickyTabs -= AppTab.DVR
        if (moviesDenied) stickyTabs -= AppTab.Movies
        if (seriesDenied) stickyTabs -= AppTab.TVShows
        if (moviesDenied && seriesDenied) stickyTabs -= AppTab.OnDemand
        visibleTabs(
            hasFavorites = AppTab.Favorites in stickyTabs,
            hasVod = AppTab.OnDemand in stickyTabs,
            hasRecordings = AppTab.DVR in stickyTabs,
            splitVod = splitVod,
            hasMovies = AppTab.Movies in stickyTabs,
            hasSeries = AppTab.TVShows in stickyTabs,
        )
    }
    // One line per change of the inputs, so "why is the tab hidden" is provable
    // from logcat instead of from the screen.
    androidx.compose.runtime.LaunchedEffect(
        moviesDenied, seriesDenied, vodSourceOk, hasMoviesContent, hasSeriesContent,
        onDemandState, tabs,
    ) {
        android.util.Log.i(
            "MainScaffold",
            "[VOD-TAB] vodEnabled=$activePlaylistVodEnabled unsupported=${onDemandState.unsupportedSource} " +
                "sourceOk=$vodSourceOk | movies: denied=$moviesDenied has=${onDemandState.hasMovies} " +
                "loading=${onDemandState.isLoading} -> show=$hasMoviesContent | " +
                "series: denied=$seriesDenied has=${onDemandState.hasSeries} " +
                "loading=${onDemandState.isLoadingSeries} -> show=$hasSeriesContent | tabs=$tabs",
        )
    }
    val miniPlayerVm: MiniPlayerViewModel = hiltViewModel()
    val miniPlayerState by miniPlayerVm.state.collectAsStateWithLifecycle()
    val context = androidx.compose.ui.platform.LocalContext.current
    val exoHolder = remember {
        dagger.hilt.android.EntryPointAccessors.fromApplication(
            context.applicationContext,
            MainScaffoldEntryPoint::class.java,
        ).exoPlayerHolder()
    }
    val exoWindowMode by remember {
        dagger.hilt.android.EntryPointAccessors.fromApplication(
            context.applicationContext,
            MainScaffoldEntryPoint::class.java,
        ).exoWindowState().mode
    }.collectAsStateWithLifecycle()
    // GH #33 re-entry: an app-wide "Now Casting" mini controller above the tab
    // bar so the user can re-open the cast remote after leaving the player.
    val castSender = remember {
        dagger.hilt.android.EntryPointAccessors.fromApplication(
            context.applicationContext,
            MainScaffoldEntryPoint::class.java,
        ).castSender()
    }
    val castState by castSender.state.collectAsStateWithLifecycle()
    // Multiview to the TV: only a Cast Connect session into the AerioTV
    // Android TV app can open Multiview; the web receiver cannot.
    // Gated on the receiverInfo "multiview": true flag (Apple sender parity).
    val castTarget by castSender.receiverTarget.collectAsStateWithLifecycle()
    val castMultiview by castSender.receiverMultiview.collectAsStateWithLifecycle()
    val castConnectedName: String? = (castState as? com.aeriotv.android.core.cast.AerioCastSender.State.Connected)
        ?.let { it.deviceName?.takeIf { n -> n.isNotBlank() } ?: "TV" }
    val mvNativeReceiver = castMultiview &&
        castTarget == com.aeriotv.android.core.cast.AerioCastSender.ReceiverTarget.ANDROID_TV_APP
    // Web receiver (Chromecast, Logan 2026-10-06): the phone composites 2 to 4
    // live channels into one stream; more than 4 shows the cast-limit note.
    val multiviewCast = remember {
        dagger.hilt.android.EntryPointAccessors.fromApplication(
            context.applicationContext,
            MainScaffoldEntryPoint::class.java,
        ).multiviewCastController()
    }
    val mvWebReceiver = castTarget == com.aeriotv.android.core.cast.AerioCastSender.ReceiverTarget.WEB_RECEIVER
    // The Live TV "Add to Multiview" labels and tile cap read the store, so
    // it mirrors a running pile (the composite on a receiver, or the tiles
    // playing in the background) while nothing is being staged (Apple
    // e1dcbd2 parity: adds join the running pile). A composite that ends
    // takes its tiles with it, so the mirrored pile ends too; nothing keeps
    // playing hidden.
    val compositeSession by multiviewCast.session.collectAsStateWithLifecycle()
    val backgroundPile by com.aeriotv.android.feature.multiview.MultiviewBackground.state
        .collectAsStateWithLifecycle()
    var mirroredComposite by remember { mutableStateOf(false) }
    var mirroredBackground by remember { mutableStateOf(false) }
    LaunchedEffect(compositeSession, backgroundPile) {
        val cs = compositeSession
        val bg = backgroundPile
        when {
            cs != null -> {
                multiviewStore.setStaging(false)
                multiviewStore.restore(cs.tiles, cs.focused)
                mirroredComposite = true
            }
            bg != null -> {
                if (!multiviewStore.isStaging.value) {
                    multiviewStore.restore(bg.tiles, bg.focus)
                    mirroredBackground = true
                }
            }
            mirroredComposite || mirroredBackground -> {
                val reason = if (mirroredComposite) "composite ended" else "background Multiview ended"
                val returnedToGrid = !mirroredComposite &&
                    com.aeriotv.android.feature.multiview.MultiviewBackground.endedByReturn
                mirroredComposite = false
                mirroredBackground = false
                if (!returnedToGrid && !multiviewStore.isStaging.value) {
                    if (reason == "composite ended") {
                        android.util.Log.i("AerioCast", "[MV-CAST] composite ended: Multiview ended, no tiles left playing")
                    }
                    android.util.Log.i("AerioMV", "[MV] mirror cleared: $reason")
                    multiviewStore.clear()
                }
            }
        }
    }
    val stagedForCast by multiviewStore.selected.collectAsStateWithLifecycle()
    val stagedLiveCount = multiviewCast.castableTiles(stagedForCast).size
    val mvReceiverName: String? = castConnectedName?.takeIf {
        mvNativeReceiver ||
            (mvWebReceiver && com.aeriotv.android.core.cast.multiview.MultiviewCompositeLayout.canCast(stagedLiveCount))
    }
    val mvCastNote: String? = if (
        castConnectedName != null && mvWebReceiver &&
        stagedLiveCount > com.aeriotv.android.core.cast.multiview.MultiviewCompositeLayout.MAX_TILES
    ) com.aeriotv.android.core.cast.multiview.MultiviewCastController.CAST_LIMIT_NOTE else null
    val playStagedHere: () -> Unit = {
        // A fresh grid replaces a Multiview playing in the background.
        com.aeriotv.android.feature.multiview.MultiviewBackground.stop()
        showMultiviewSheet = false
        multiviewStore.setStaging(false)
        onLaunchMultiview()
    }
    val playStagedOnReceiver: () -> Unit = playOnReceiver@{
        showMultiviewSheet = false
        // One staged channel casts as a normal channel, not a one-tile Multiview.
        val single = multiviewStore.selected.value.singleOrNull()
            ?.takeIf { it.kind == com.aeriotv.android.feature.multiview.TileKind.Live }
            ?.let { t -> state.channels.firstOrNull { it.id == t.id } }
        if (single != null) {
            multiviewStore.clear()
            multiviewStore.setStaging(false)
            onCastChannel(single)
            return@playOnReceiver
        }
        com.aeriotv.android.feature.multiview.MultiviewBackground.stop()
        if (!mvNativeReceiver) {
            // Web receiver: the phone composites the grid and casts one stream.
            val started = multiviewCast.start(
                tiles = multiviewStore.selected.value,
                headers = com.aeriotv.android.core.network.PlaybackHeaders.forPlaylist(state.playlist),
                focus = multiviewStore.audioFocusedIndex.value,
            )
            // The store keeps the pile: it mirrors the running composite.
            if (started) multiviewStore.setStaging(false)
            return@playOnReceiver
        }
        val playlistId = state.playlist?.id.orEmpty()
        val refs = multiviewStore.selected.value
            .filter { it.kind == com.aeriotv.android.feature.multiview.TileKind.Live }
            .map { com.aeriotv.android.core.cast.CastControl.MultiviewChannelRef(it.id, playlistId) }
        castSender.sendMultiviewOpen(refs, multiviewStore.audioFocusedIndex.value)
        multiviewStore.clear()
        multiviewStore.setStaging(false)
    }
    // Card Play: Play Here, or the play-where prompt when the TV app can take it.
    val playStagedMultiview: () -> Unit = {
        // One staged channel: the single-player path runs its own play-where prompt.
        if (mvReceiverName == null || multiviewStore.selected.value.size == 1) playStagedHere()
        else PlayWhereRouter.route(castSender, "Multiview", playStagedHere, playStagedOnReceiver)
    }
    if (showMultiviewSheet) {
        val sheetTiles by multiviewStore.selected.collectAsStateWithLifecycle()
        com.aeriotv.android.feature.multiview.MultiviewStagedSheet(
            tiles = sheetTiles,
            receiverName = mvReceiverName,
            onRemove = { id -> multiviewStore.removeTile(id) },
            onReorder = { ids ->
                val current = multiviewStore.selected.value
                val focusedId = current.getOrNull(multiviewStore.audioFocusedIndex.value)?.id
                val reordered = ids.mapNotNull { id -> current.firstOrNull { it.id == id } } +
                    current.filter { it.id !in ids }
                multiviewStore.restore(reordered, reordered.indexOfFirst { it.id == focusedId }.coerceAtLeast(0))
            },
            onClear = {
                showMultiviewSheet = false
                multiviewStore.clear()
                multiviewStore.setStaging(false)
            },
            onPlayHere = playStagedHere,
            onPlayOnReceiver = playStagedOnReceiver,
            onDismiss = { showMultiviewSheet = false },
            castNote = mvCastNote,
        )
    }
    // GH #33 companion remote: same-pattern "Controlling <TV>" indicator card +
    // tap-to-reopen-the-remote, mirroring the Now-Casting card below.
    val companionRemote = remember {
        dagger.hilt.android.EntryPointAccessors.fromApplication(
            context.applicationContext,
            MainScaffoldEntryPoint::class.java,
        ).companionRemote()
    }
    val companionConn by companionRemote.connection.collectAsStateWithLifecycle()
    val companionChannelId by companionRemote.currentChannelId.collectAsStateWithLifecycle()
    // Enrich the companion's channel anchor with name/logo/current programme
    // for the media notification and the card; re-evaluated each minute so
    // the programme rolls over on the hour.
    LaunchedEffect(companionChannelId, state.channels, state.epgByChannel) {
        val id = companionChannelId
        if (id == null) { companionRemote.setNowPlayingDetails(null); return@LaunchedEffect }
        val ch = state.channels.firstOrNull { it.id == id }
        if (ch == null) { companionRemote.setNowPlayingDetails(null); return@LaunchedEffect }
        while (true) {
            val now = state.epgByChannel[ch.guideMatchKey]?.nowPlaying()
            companionRemote.setNowPlayingDetails(
                com.aeriotv.android.core.cast.companion.CompanionRemoteController.NowPlayingDetails(
                    channelId = id,
                    channelName = ch.name,
                    logoUrl = ch.tvgLogo.takeIf { it.isNotBlank() },
                    programmeTitle = now?.title,
                    programmeStartMs = now?.startMillis ?: 0L,
                    programmeEndMs = now?.endMillis ?: 0L,
                ),
            )
            kotlinx.coroutines.delay(60_000L)
        }
    }
    // GH #33: browse for controllable AerioTV TVs at the SCAFFOLD level (phone
    // only; the TV is a host, not a client) so the floating "Control TV" pill
    // can appear without opening a channel first. Refcounted with the in-player
    // chooser's start/stop.
    val companionDiscovery = remember {
        dagger.hilt.android.EntryPointAccessors.fromApplication(
            context.applicationContext,
            MainScaffoldEntryPoint::class.java,
        ).companionDiscovery()
    }
    if (!rememberLiveTvFormFactor().isTv) {
        DisposableEffect(Unit) {
            companionDiscovery.start()
            onDispose { companionDiscovery.stop() }
        }
    }
    val companionDevices by companionDiscovery.devices.collectAsStateWithLifecycle()
    var showCompanionPicker by remember { mutableStateOf(false) }
    // Poll pause state from the held ExoPlayer so the mini-player's
    // Pause/Play icon stays accurate when the notification action /
    // BT button toggles playback elsewhere.
    var miniPaused by remember { mutableStateOf(false) }
    androidx.compose.runtime.LaunchedEffect(miniPlayerState) {
        if (miniPlayerState !is com.aeriotv.android.feature.miniplayer.MiniPlayerSession.State.Active) return@LaunchedEffect
        while (true) {
            miniPaused = exoHolder.isPaused()
            kotlinx.coroutines.delay(500L)
        }
    }

    val settingsVm: SettingsViewModel = hiltViewModel()
    val defaultTabPref by settingsVm.defaultTab.collectAsStateWithLifecycle(initialValue = "")

    var selectedTab by rememberSaveable { mutableStateOf(AppTab.LiveTV) }
    var initialTabApplied by rememberSaveable { mutableStateOf(false) }
    // Which tabs are already composed and alive (see MainTabContent). Hoisted
    // here because the TV tab bar needs it too: switching to a tab that is
    // ALREADY built is free, so it must commit on the same frame as the pill
    // highlight, while a first visit still gets the settle window that keeps a
    // pill walk from cold-building every tab it passes through.
    val visitedTabs = rememberSaveable(saver = androidx.compose.runtime.saveable.listSaver(
        save = { it.map { t -> t.name } },
        restore = { names -> names.mapNotNull { n -> AppTab.entries.firstOrNull { it.name == n } }.toMutableStateList() },
    )) { mutableStateListOf<AppTab>() }

    // Honour the saved defaultTab once its tab is actually available. On Demand /
    // DVR now materialise a beat after launch (their content loads async), so we
    // must NOT latch on the empty initial pref or while the target tab is still
    // missing - otherwise a "default = On Demand" preference would be dropped on
    // the floor before the tab appeared. We latch only when the target is applied;
    // a manual tab tap also latches (see onSelect / NavigationBarItem onClick) so
    // the default never overrides a deliberate user choice. Empty pref = Live TV
    // (already the initial selection), so there's nothing to apply.
    LaunchedEffect(defaultTabPref, tabs) {
        if (initialTabApplied || defaultTabPref.isEmpty()) return@LaunchedEffect
        // A default saved as On Demand opens Movies where the tab was split.
        val target = AppTab.entries.firstOrNull { it.name == defaultTabPref }
            ?.let { if (it == AppTab.OnDemand && splitVod) AppTab.Movies else it }
            ?.let { if (it == AppTab.Favorites && splitVod) AppTab.LiveTV else it }
        when {
            target == null -> initialTabApplied = true
            target in tabs -> {
                selectedTab = target
                initialTabApplied = true
            }
            // else: target tab not present yet (content still loading); keep
            // waiting - this effect re-fires when `tabs` changes.
        }
    }

    // If the currently-selected tab disappears (e.g. user clears playlist, sourceType
    // changes), fall back to Live TV.
    LaunchedEffect(tabs) {
        // Search is never IN `tabs` (it's the floating bar button, not a
        // pill) but is a perfectly valid selection - don't bounce it.
        if (selectedTab !in tabs && selectedTab != AppTab.Search) {
            selectedTab = AppTab.LiveTV
        }
    }

    // EPG-search guide jump (iOS: MainTabView switches to .liveTV +
    // ChannelListView sets showGuideView=true). When a Search EPG result is
    // tapped (warm path) or an aeriotvblue://guide deep link is consumed (cold
    // path re-emits through requestGuideJump), select the Live TV tab.
    // LiveTVTabContent collects the same SharedFlow to force its SESSION view to
    // Guide (so the target cell exists to scroll/focus), and GuideScreen collects
    // it too (replay=1) to do the scroll + focus. This used to write the persisted
    // defaultLiveTVView("guide") here, which both failed to switch when the view
    // was already resolving to Guide and clobbered the Drive-synced default across
    // devices; forcing the session view instead avoids both.
    LaunchedEffect(Unit) {
        viewModel.guideJumpRequests.collect {
            selectedTab = AppTab.LiveTV
            initialTabApplied = true
        }
    }

    // Companion remote X (GH #33). Popping the player back to MAIN is only
    // half of "exit to Live TV": the tab shell keeps whatever tab was selected
    // when playback started, so an X pressed while the shell sat on Movies /
    // TV Shows landed there. Measured on the Streamer 2026-09-12
    // (gtvlogs/session7.txt): "companion stop: playback stopped, exiting to
    // Live TV" at 14:25:23.138 is followed at 14:25:24.016 by
    // "[PROGRESS] target series=277738 -> s=1 e=1 reason=resume row", which is
    // the media page's hero recomputing because THAT is what came back up.
    // Logan: "X did not return the TV to Live TV guide on the first attempt.
    // It worked correctly on the 2nd attempt" -- the second attempt worked
    // because by then Live TV was already the selected tab. Selecting the tab
    // explicitly makes the first X land, from any tab.
    LaunchedEffect(Unit) {
        viewModel.liveTvTabRequests.collect {
            selectedTab = AppTab.LiveTV
            initialTabApplied = true
        }
    }

    // Screenshot deep link (aeriotvblue://settings/<page>). Select the Settings
    // tab so SettingsTabContent composes; that composable then reads the same
    // pending request and applies the route (it cannot be applied from here --
    // the nav stack and pane selection live inside it). The request is a
    // StateFlow, so it is still readable on the frame after this switch and on
    // a cold launch where Settings had never been composed.
    val pendingSettingsPage by viewModel.settingsPageRequest.collectAsStateWithLifecycle()
    LaunchedEffect(pendingSettingsPage) {
        if (pendingSettingsPage != null) {
            selectedTab = AppTab.Settings
            initialTabApplied = true
        }
    }

    // Back from any secondary tab returns to the HOME tab instead of exiting
    // the app. Home is the user's Default Tab when it is set and present
    // (GH #81: a Favorites-first user expects Back to land on Favorites,
    // not Live TV), else Live TV. On the home tab this handler is disabled
    // so Back falls through to the default (mini-player / exit). The
    // Settings sub-screen BackHandler in SettingsTabContent is composed
    // DEEPER and is enabled only while a sub-screen is open, so it takes
    // priority there; this only fires on a tab root.
    val homeTab = AppTab.entries.firstOrNull { it.name == defaultTabPref }
        ?.let { if (it == AppTab.OnDemand && splitVod) AppTab.Movies else it }
        ?.takeIf { it in tabs && it != AppTab.Search } ?: AppTab.LiveTV
    // TV: the leaving tab's content nodes vanish, and Compose's fallback
    // hands focus to the LEFTMOST pill (Live TV) while the home tab is
    // selected (Logan 2026-09-02 screenshot). Ask for the home pill instead;
    // the bar treats a non-UP focus arrival as a fallback, so selection does
    // not follow it.
    // Focus the home pill BEFORE the tab switches (the pill already exists),
    // so the leaving content's nodes vanish with focus already parked there
    // and no fallback flashes the Live TV pill (Logan: "less than a quarter
    // of a second on Live TV before settling on Favorites").
    val focusPill = remember { mutableStateOf<((AppTab) -> Boolean)?>(null) }
    val backFocusScope = androidx.compose.runtime.rememberCoroutineScope()
    androidx.activity.compose.BackHandler(enabled = selectedTab != homeTab) {
        val leaving = selectedTab
        val took = focusPill.value?.invoke(homeTab)
        selectedTab = homeTab
        initialTabApplied = true
        if (took != null) {
            com.aeriotv.android.ui.tv.TvFocusTrace.guide("back-to-home from=$leaving to=$homeTab pillFocus=$took")
            // Back from the Settings rail (Streamer 2026-10-04): the request
            // above did not land while the rail held focus, and once the
            // Settings slot hid, focus fell back onto the Settings pill while
            // Live TV showed as selected (two pills looked active). Ask again
            // after the switch has composed, so the focused pill and the
            // selected pill always agree, as they already did for DVR.
            backFocusScope.launch {
                androidx.compose.runtime.withFrameNanos { }
                androidx.compose.runtime.withFrameNanos { }
                if (selectedTab == homeTab) {
                    val again = focusPill.value?.invoke(homeTab)
                    com.aeriotv.android.ui.tv.TvFocusTrace.guide("back-to-home settle to=$homeTab pillFocus=$again")
                }
            }
        }
    }

    // Background-activity flag. ORs the content-fetch flags so the activity
    // indicators show while the channel list, EPG/guide, or On Demand library
    // is still loading -- an activity light, NOT a cross-device-sync status.
    // It drives the TV bar's spinning Refresh circle and the phone Live TV
    // header's spinning indicator; the old "Syncing | Tap for Info" pill it
    // used to drive was removed (Logan 2026-09-14: it overlapped the sidebar
    // button on both shells).
    val anyBackgroundWork = state.isLoading || state.isEpgLoading ||
        onDemandState.isLoading || onDemandState.isLoadingSeries

    // Pre-warm (Logan 2026-09-11): a FIRST visit to a tab still cost 419-567 ms
    // key to frame on the Streamer, of which ~250 ms was the settle window and
    // 130-280 ms was the tab's own first composition plus layout. Once Live TV
    // has painted and the app is idle, each present tab is composed into its
    // hidden keep-alive slot, one at a time, cheapest first, so the user's
    // first real visit is a warm one. A pre-warmed tab counts as visited, so
    // the settle window never runs for it either. Never pre-warms a tab that
    // is not present, never while the channel or guide load is saturating the
    // main thread, and TV only (the phone keeps one tab at a time).
    val prewarmTabsNow = androidx.compose.runtime.rememberUpdatedState(tabs)
    // Gate on the CHANNEL and GUIDE load only, not on every sync label. The
    // VOD labels ("Loading Movies" / "Loading Series") stay up for tens of
    // seconds and are exactly the work that makes the Movies and TV Shows tabs
    // appear in the first place, so waiting on them starved the sweep and the
    // media tabs were still cold after 45 s (measured 2026-09-11).
    val prewarmBusyNow = androidx.compose.runtime.rememberUpdatedState(
        state.isLoading || state.isEpgLoading,
    )
    val prewarmIsTv = rememberLiveTvFormFactor().isTv
    // Memory gate: a laid-out hidden page is worth about 100 MB across the
    // three media tabs plus Settings (Streamer, 4 GB). That is fine there and
    // NOT on a 2 GB Onn or a 3 GB Shield, so low-RAM and sub-3 GB boxes skip
    // the sweep entirely and keep the old behavior: a tab composes on its
    // first visit. They lose nothing else - hidden slots still measure at the
    // real size once a tab has been visited, so there are no slivers, and the
    // hero's own zero-width guard covers the first pass either way.
    val prewarmAllowed = remember(context) {
        val am = context.getSystemService(android.content.Context.ACTIVITY_SERVICE)
            as? android.app.ActivityManager
        val info = android.app.ActivityManager.MemoryInfo().also { am?.getMemoryInfo(it) }
        val lowRam = am?.isLowRamDevice ?: false
        val totalMem = info.totalMem
        !lowRam && totalMem >= 3L * 1024L * 1024L * 1024L
    }
    // A sweep already under way stops for good the first time the system asks
    // for memory back (TRIM_MEMORY_RUNNING_LOW or worse). The tabs it already
    // built stay: they are the ones the user is most likely to open, and
    // dropping them would put the reload back.
    val prewarmStopped = remember { java.util.concurrent.atomic.AtomicBoolean(false) }
    DisposableEffect(context) {
        val cb = object : android.content.ComponentCallbacks2 {
            override fun onTrimMemory(level: Int) {
                if (level >= android.content.ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW) {
                    prewarmStopped.set(true)
                }
            }
            override fun onConfigurationChanged(newConfig: android.content.res.Configuration) = Unit
            @Deprecated("ComponentCallbacks")
            override fun onLowMemory() { prewarmStopped.set(true) }
        }
        context.registerComponentCallbacks(cb)
        onDispose { context.unregisterComponentCallbacks(cb) }
    }
    LaunchedEffect(prewarmIsTv, prewarmAllowed) {
        if (!prewarmIsTv || !prewarmAllowed) return@LaunchedEffect
        androidx.compose.runtime.withFrameNanos { }
        kotlinx.coroutines.delay(2_000L)
        // Cheapest first (measured cold key-to-frame: Settings and Favorites
        // are plain columns, DVR/Movies/TV Shows are the LazyVerticalGrid
        // media pages, On Demand is the legacy grid).
        val order = listOf(
            AppTab.Settings, AppTab.Favorites, AppTab.DVR,
            AppTab.Movies, AppTab.TVShows, AppTab.OnDemand,
        )
        // Tabs can still materialize a beat after launch (VOD, recordings), so
        // keep sweeping for a while instead of taking one snapshot.
        val deadline = android.os.SystemClock.uptimeMillis() + 180_000L
        while (android.os.SystemClock.uptimeMillis() < deadline) {
            if (prewarmStopped.get()) return@LaunchedEffect
            val next = order.firstOrNull {
                it in prewarmTabsNow.value && it !in visitedTabs
            }
            if (next == null) { kotlinx.coroutines.delay(2_000L); continue }
            if (prewarmBusyNow.value) { kotlinx.coroutines.delay(500L); continue }
            visitedTabs.add(next)
            kotlinx.coroutines.delay(500L)
        }
    }

    // iOS Issue #24: when the app returns to the foreground, refresh the guide
    // if it has gone stale (>30min). Skip the first ON_START (cold launch
    // already loads the EPG) so a normal launch never double-fetches.
    val lifecycleOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current
    var sawFirstStart by remember { mutableStateOf(false) }
    androidx.compose.runtime.DisposableEffect(lifecycleOwner) {
        val observer = androidx.lifecycle.LifecycleEventObserver { _, event ->
            if (event == androidx.lifecycle.Lifecycle.Event.ON_START) {
                // EpgSweepGate.appInForeground follows the process lifecycle
                // (Android#131): this destination's lifecycle reads STOPPED
                // while the full-screen player route is on top. A return here
                // re-checks the sources gate (rate limited in the repository)
                // and repaints a guide a background trim shed.
                viewModel.repaintGuideIfShed("main-start")
                if (sawFirstStart) {
                    viewModel.refreshEpgIfStale()
                    viewModel.checkEpgSourcesForChanges()
                } else {
                    sawFirstStart = true
                }
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    // Periodic foreground gate re-check: every 15 minutes, ask the server
    // whether its EPG sources moved and let the repository sweep the grid in
    // the background if they did. repeatOnLifecycle(STARTED) so the tick does
    // not fire while the app is backgrounded.
    LaunchedEffect(lifecycleOwner) {
        lifecycleOwner.lifecycle.repeatOnLifecycle(
            androidx.lifecycle.Lifecycle.State.STARTED,
        ) {
            while (true) {
                kotlinx.coroutines.delay(15L * 60L * 1000L)
                viewModel.checkEpgSourcesForChanges()
            }
        }
    }

    // Android TV / Google TV: a 10-foot top tab bar instead of the phone
    // bottom NavigationBar. D-pad friendly, overscan-safe, and mirrors the
    // tvOS TabView. Phone / tablet / fold keep the bottom nav below.
    val isTv = rememberLiveTvFormFactor().isTv
    if (isTv) {
        val useQueRail = LocalAppTheme.current == AppTheme.RoyalBlue &&
            LocalIsDarkTheme.current && !LocalTrueBlack.current
        val defaultLiveTvView by settingsVm.defaultLiveTVView.collectAsStateWithLifecycle(initialValue = "")
        val queDefaultLiveTvMode = if (defaultLiveTvView.equals("guide", ignoreCase = true)) {
            LiveTVViewMode.Guide
        } else LiveTVViewMode.List
        val queLiveTvMode = rememberSaveable(queDefaultLiveTvMode) { mutableStateOf(queDefaultLiveTvMode) }
        val quePageHasOwnHeader = useQueRail && selectedTab in
            setOf(AppTab.Movies, AppTab.TVShows, AppTab.DVR, AppTab.Settings)
        // tvOS layout parity (Archie 2026-05-28 reference shot): when the
        // mini-player is active, the top chrome (centered nav tabs +
        // sync pill on the left + group filter pills below) does NOT
        // shift down. The mini-player sits at the top-right in the empty
        // space alongside the centered nav tabs. They coexist because the
        // nav pill row is centered (Live TV / On Demand / Settings ~250dp
        // wide) and the mini is 210dp wide aligned to the right edge -- on
        // a 960dp-wide canvas there's ~250dp of empty space between them.
        // An earlier revision shoved everything down 184dp; that was wrong.
        // Audit #57: a single FocusRequester bound to the tab-bar Row. The
        // Row uses focusRestorer() so re-entry from a section restores the
        // pill the user last focused (typically the currently-selected one).
        // Section composables read it via LocalTvTopNavFocusRequester and
        // route D-pad UP from their topmost focusable here.
        val topNavRequester = remember { FocusRequester() }
        // Timestamp of the last D-pad UP press, read by TvTopTabBar to tell a
        // DELIBERATE bar entry (user pressed UP from the content; selection
        // should follow the focused pill immediately) from an involuntary
        // focus FALLBACK (a sub-screen transition removed the focused node and
        // Compose handed focus to the leftmost pill; selecting there would
        // yank the user to Live TV). Fallbacks are never preceded by UP.
        val lastUpKeyMs = remember { longArrayOf(0L) }
        // One FocusRequester per pill, shared between the bar (which binds
        // them) and the content's exit redirect below (which targets the
        // SELECTED pill directly, not the bar, so no entry heuristics apply).
        // + Search: not a pill, but the floating bar button needs a requester
        // for the same entry/exit focus redirects the pills use.
        val basePillRequesters = remember(tabs) {
            (tabs + AppTab.Search).associateWith { FocusRequester() }
        }
        val guidePillRequester = remember { FocusRequester() }
        val queRefreshRequester = remember { FocusRequester() }
        // Existing page return contracts target whichever Live TV presentation is active.
        val pillRequesters = if (useQueRail && queLiveTvMode.value == LiveTVViewMode.Guide) {
            basePillRequesters + (AppTab.LiveTV to guidePillRequester)
        } else basePillRequesters
        androidx.compose.runtime.SideEffect {
            focusPill.value = { tab -> runCatching { pillRequesters[tab]?.requestFocus() ?: false }.getOrDefault(false) }
        }
        // The same requesters, as a "focus MY tab's pill" call for TV page
        // content (Back out of a page lands on the bar, not on Live TV).
        // One stable lambda: a new one each recomposition would invalidate
        // every reader of this static CompositionLocal.
        val pillRequestersRef = androidx.compose.runtime.rememberUpdatedState(pillRequesters)
        val requestCurrentTabPill: () -> Boolean = remember {
            {
                val r = pillRequestersRef.value[selectedTab]
                r != null && runCatching { r.requestFocus() }.getOrDefault(false)
            }
        }
        // Chrome-collapse channel: long content surfaces (the On Demand grids)
        // set this true while scrolled down so the tab bar shrinks away. See
        // LocalTvChromeCollapsed for why the bar collapses instead of unmounting.
        val chromeCollapsed = remember { mutableStateOf(false) }
        val chromeScroll = remember { mutableStateOf(0) }
        val fullScreenOverlay = remember { mutableStateOf<(@Composable () -> Unit)?>(null) }
        val topNavHasFocusState: androidx.compose.runtime.MutableState<Boolean> = remember { mutableStateOf(false) }
        val tabEntryFocus: androidx.compose.runtime.MutableState<FocusRequester?> = remember { mutableStateOf(null) }
        CompositionLocalProvider(
            LocalTvTopNavFocusRequester provides topNavRequester,
            LocalTvTopNavHasFocus provides topNavHasFocusState,
            LocalTvTabEntryFocus provides tabEntryFocus,
            LocalTvRequestCurrentTabPill provides requestCurrentTabPill,
            LocalTvChromeCollapsed provides chromeCollapsed,
            LocalTvChromeScroll provides chromeScroll,
            LocalTvFullScreenOverlay provides fullScreenOverlay,
            LocalLiveTvSessionMode provides if (useQueRail) queLiveTvMode else null,
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
            // TV chrome is an OVERLAY, not a sibling above the content
            // (2026-09-11). The bar used to live in a Column with the tab
            // content and collapsibleChrome animated its HEIGHT, so the
            // content's viewport grew over 250 ms while the bar hid and
            // snapped back the instant it re-expanded: the grid shifted
            // under a focus scroll that was already running, which is the
            // "notchy" signature in the device trace. tvOS gives the page a
            // FIXED top spacer (MoviesView.swift:1397) and slides the system
            // bar over it. So: content fills the screen and takes a constant
            // top inset, and the bar animates its own offset and alpha on
            // top of it. Nothing the bar does resizes the content.
            var barHeightPx by remember { mutableIntStateOf(0) }
            var barDrawnBottomPx by remember { androidx.compose.runtime.mutableFloatStateOf(0f) }
            val chromeDensity = LocalDensity.current
            // 62dp is the bar's designed height (16 top + 34 capsule + 12
            // bottom); it only ever seeds the very first frame, after which
            // the measured height governs.
            val barInset = if (quePageHasOwnHeader) {
                0.dp
            } else if (barHeightPx > 0) {
                with(chromeDensity) { barHeightPx.toDp() }
            } else {
                if (useQueRail) 52.dp else 62.dp
            }
            // The corner mini player is mounted at the ACTIVITY root, outside
            // this composition, so it cannot read a CompositionLocal from
            // here. Publish the measured bar height through the app-scoped
            // window state instead; PersistentExoWindow takes its top inset
            // from it (tvOS pins the mini 87pt from the physical screen top,
            // deliberately clear of the tab bar: mini report D1).
            val barDrawnBottom = if (quePageHasOwnHeader) {
                0.dp
            } else if (barDrawnBottomPx > 0f) {
                with(chromeDensity) { barDrawnBottomPx.toDp() }
            } else {
                barInset - 12.dp
            }
            androidx.compose.runtime.LaunchedEffect(barDrawnBottom) {
                com.aeriotv.android.feature.player.MiniPlayerChrome
                    .topInsetDp.value = if (quePageHasOwnHeader) 56f else barDrawnBottom.value + 4f
            }
            // Stash the corner mini at the trailing edge while Settings is
            // the selected tab; cleared when the scaffold leaves composition
            // so a player / search route never inherits a stashed mini.
            androidx.compose.runtime.LaunchedEffect(selectedTab) {
                com.aeriotv.android.feature.player.MiniPlayerChrome
                    .settingsStashed.value = selectedTab == AppTab.Settings
            }
            androidx.compose.runtime.DisposableEffect(Unit) {
                onDispose {
                    com.aeriotv.android.feature.player.MiniPlayerChrome
                        .settingsStashed.value = false
                }
            }
            // Collapse the bar only while the content reports a scrolled
            // state AND no pill holds focus: the UP-from-content redirect
            // (focusProperties onExit below) lands focus on the selected
            // pill, which flips barHasFocus and brings the bar back so the
            // user can see what they're navigating.
            var barHasFocus by remember { mutableStateOf(false) }
            var toolbarHasFocus by remember { mutableStateOf(false) }
            androidx.compose.runtime.SideEffect {
                topNavHasFocusState.value = barHasFocus || (toolbarHasFocus && !quePageHasOwnHeader)
            }
            // Collapse slides up and fades over 250 ms; the bar comes back
            // INSTANTLY (tvOS shows it at once on the way up).
            val barTarget = if (!useQueRail && chromeCollapsed.value && !barHasFocus) 0f else 1f
            val barCollapse by animateFloatAsState(
                targetValue = barTarget,
                animationSpec = if (barTarget == 1f) androidx.compose.animation.core.snap() else tween(durationMillis = 250),
                label = "tvTopBarCollapse",
            )
            // Nothing proportional: tvOS keeps the bar fully present until
            // the page passes the hide threshold and then hides it, so the
            // collapse tween is the only channel (Movies spec D10, DVR D9).
            // The page owns the threshold (TvMediaPage.barHideThreshold).
            val barFraction = barCollapse
            // Remote hint strip inputs. The copy is generated from the
            // EFFECTIVE remote map plus the live app state (below), so a user
            // who remaps a button in Settings > Remote Control sees their own
            // button named; the whole strip is gated on the "Show remote
            // hints" toggle in that same screen.
            val hintSettingsVm: com.aeriotv.android.feature.settings.SettingsViewModel =
                hiltViewModel()
            val hintsEnabled by hintSettingsVm.showRemoteHints
                .collectAsStateWithLifecycle(initialValue = true)
            val hintMap by hintSettingsVm.remoteControlMap.collectAsStateWithLifecycle(
                initialValue = com.aeriotv.android.core.remote.RemoteControlMap.DEFAULT,
            )
            val hintGroupSelector by hintSettingsVm.guideGroupSelector
                .collectAsStateWithLifecycle(initialValue = "pills")
            // Reserve a band below the nav bar for the remote hint STRIP.
            // The mini player used to push all tab content down 78dp; it no
            // longer does (tvOS parity, mini report D5): the mini now sits
            // clear of the bar in the top-right corner and the Channel
            // Preview banner reserves its column instead, so nothing moves
            // when a channel starts playing in the corner.
            //  - Live TV: a 16dp band under the bar holds the one-line strip.
            //  - Other tabs / fullscreen (Pending): none (no strip shown).
            val miniActive = miniPlayerState is MiniPlayerSession.State.Active
            val showHintStrip = !useQueRail && hintsEnabled &&
                selectedTab == AppTab.LiveTV &&
                miniPlayerState !is MiniPlayerSession.State.Pending
            val topHintGap = when {
                !useQueRail && selectedTab == AppTab.LiveTV &&
                    miniPlayerState !is MiniPlayerSession.State.Pending ->
                    16.dp
                else -> 0.dp
            }
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .appBackground()
                    .onPreviewKeyEvent { ev ->
                        if (ev.type == KeyEventType.KeyDown && ev.key == Key.DirectionUp) {
                            lastUpKeyMs[0] = android.os.SystemClock.uptimeMillis()
                        }
                        false
                    },
            ) {
                // Declared FIRST so traversal order (and the cold-start
                // initial focus it decides) is exactly what it was when the
                // bar was the Column's first child; zIndex keeps it painted
                // above the content it now overlaps.
                Box(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .then(
                            if (useQueRail) {
                                Modifier.width(QueTvRailWidth).fillMaxHeight()
                            } else {
                                Modifier.fillMaxWidth()
                                    .onSizeChanged { barHeightPx = it.height }
                                    .graphicsLayer {
                                        alpha = barFraction
                                        translationY = -(1f - barFraction) * barHeightPx.toFloat()
                                    }
                            },
                        )
                        .zIndex(1f)
                        .onFocusChanged {
                            barHasFocus = it.hasFocus
                            topNavHasFocusState.value = it.hasFocus || (toolbarHasFocus && !quePageHasOwnHeader)
                        },
                ) {
                    TvTopTabBar(
                        retainedCount = retainedList.size,
                        onRetainedClick = { showRetainedDialog = true },
                        onRefresh = { viewModel.refreshPlaylist() },
                        // Spins only while the bar can be seen: collapsed under
                        // a scrolled media page it holds a still glyph (perf
                        // 2026-10-03, the spinner ran the frame clock for the
                        // whole On Demand refill).
                        refreshing = anyBackgroundWork,
                        refreshAnimates = barTarget == 1f,
                        tabs = tabs,
                        selected = selectedTab,
                        onSelect = { selectedTab = it; initialTabApplied = true },
                        focusRequester = topNavRequester,
                        tabEntryFocus = tabEntryFocus,
                        lastUpKeyMs = lastUpKeyMs,
                        pillRequesters = pillRequesters,
                        isTabWarm = { it in visitedTabs },
                        onDrawnBottomChanged = { if (!useQueRail) barDrawnBottomPx = it },
                        useQueRail = useQueRail,
                        liveTvMode = queLiveTvMode.value,
                        onLiveTvModeSelect = { queLiveTvMode.value = it; initialTabApplied = true },
                        liveTvListFocusRequester = basePillRequesters[AppTab.LiveTV],
                        guideFocusRequester = guidePillRequester,
                        toolbarFocusRequester = when {
                            quePageHasOwnHeader -> null
                            selectedTab == AppTab.LiveTV && queLiveTvMode.value == LiveTVViewMode.Guide -> queRefreshRequester
                            else -> basePillRequesters[AppTab.Search]
                        },
                    )
                }
                if (useQueRail && !quePageHasOwnHeader) {
                    QueTvToolbar(
                        selected = selectedTab,
                        liveTvMode = queLiveTvMode.value,
                        onSearch = { selectedTab = AppTab.Search; initialTabApplied = true },
                        searchFocusRequester = pillRequesters[AppTab.Search],
                        refreshFocusRequester = queRefreshRequester,
                        railFocusRequester = (selectedTab.takeIf { it in tabs } ?: tabs.firstOrNull())
                            ?.let { pillRequesters[it] },
                        tabEntryFocus = tabEntryFocus,
                        onRefresh = { viewModel.refreshPlaylist() },
                        refreshing = anyBackgroundWork,
                        retainedCount = retainedList.size,
                        onRetainedClick = { showRetainedDialog = true },
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(start = QueTvRailWidth)
                            .fillMaxWidth()
                            .zIndex(1f)
                            .onSizeChanged { barHeightPx = it.height }
                            .onGloballyPositioned { barDrawnBottomPx = it.boundsInRoot().bottom }
                            .onFocusChanged {
                                toolbarHasFocus = it.hasFocus
                                topNavHasFocusState.value = barHasFocus || it.hasFocus
                            },
                    )
                }
                androidx.compose.runtime.CompositionLocalProvider(
                    com.aeriotv.android.feature.livetv.LocalRetainedChannelIds provides retainedIds,
                ) {
                MainTabContent(
                    selectedTab = selectedTab,
                    tabs = tabs,
                    onChannelClick = onChannelClick,
                    onMovieClick = onMovieClick,
                    onSeriesClick = onSeriesClick,
                    onEpisodeResume = onEpisodeResume,
                    onResumeMovie = onResumeMovie,
                    onPlayMovie = onPlayMovie,
                    onPlayMovieFromStart = onPlayMovieFromStart,
                    onEpisodeResumeFromStart = onEpisodeResumeFromStart,
                    onPlayRecording = onPlayRecording,
                    onPlayCatchup = onPlayCatchup,
                    onLaunchMultiview = onLaunchMultiview,
                    onWatchLive = onWatchLive,
                    onWatchFromBeginning = onWatchFromBeginning,
                    onOpenSearch = onOpenSearch,
                    onSelectTab = { selectedTab = it; initialTabApplied = true },
                    viewModel = viewModel,
                    visited = visitedTabs,
                    modifier = Modifier
                        .fillMaxSize()
                        // The FIXED inset every tab used to get from the bar's
                        // measured height plus the hint band. It never changes
                        // while the bar collapses, so no tab (guide, Settings,
                        // media pages) sees its viewport resize mid-scroll.
                        .padding(
                            start = if (useQueRail) QueTvRailWidth else 0.dp,
                            top = barInset + topHintGap,
                        )
                        // UP leaving the tab content must land on the SELECTED
                        // tab's pill. Geometric 2D search used to hit whichever
                        // pill sat above the focused column (On Demand over the
                        // centered Settings form) and selection-follows-focus
                        // switched tabs (user report). The bar's own onEnter
                        // does not intercept a direct child hit, so the
                        // redirect lives on the content group's exit instead.
                        .focusProperties {
                            onExit = {
                                if (requestedFocusDirection == androidx.compose.ui.focus.FocusDirection.Up ||
                                    (useQueRail && requestedFocusDirection == androidx.compose.ui.focus.FocusDirection.Left)
                                ) {
                                    val target = if (useQueRail &&
                                        requestedFocusDirection == androidx.compose.ui.focus.FocusDirection.Left
                                    ) selectedTab.takeIf { it in tabs } ?: tabs.firstOrNull() else selectedTab
                                    val moved = target?.let { pillRequesters[it]?.requestFocus() } == true
                                    if (useQueRail && moved) cancelFocusChange()
                                }
                            }
                        }
                        .focusGroup(),
                )
                }
            }
            // No "Syncing" pill on TV: the top bar's Refresh circle already
            // spins while background work runs (refreshing = anyBackgroundWork).
            // Remote hint strip (Logan's design, approved 2026-09-11). ONE
            // line, horizontally CENTERED, in the band between the tab bar and
            // the Channel Preview banner. Rendered at the Home level -- NOT
            // inside the guide -- so the band is measured off the SAME bar
            // height the content inset uses and the strip can never land on
            // the bar or its nav circles (the old chip stack sat at a
            // hard-coded top=18dp, which became the bar's own band once the
            // bar turned into an overlay). If the reserved band is shorter
            // than the text the strip is dropped entirely rather than drawn
            // over something.
            if (showHintStrip) {
                // Center the strip in the VISIBLE band: from the tab bar's
                // DRAWN bottom (measured, so the bar's own 12 dp bottom
                // padding is not mistaken for occupied space) down to the
                // Channel Preview banner's top edge, which is where the tab
                // content inset ends (barInset + topHintGap). The old band
                // started at barInset + 2 dp, i.e. 14 dp BELOW the drawn bar,
                // which pushed the strip against the banner's first text line
                // (Logan, Google TV Streamer 2026-09-11). tvOS centers it the
                // same way (ChannelListView.swift:1041 carries the banner's
                // old -28 pull so the strip sits midway in that band).
                val stripHeight = com.aeriotv.android.ui.tv.remoteHintStripHeight
                val bandTop = barDrawnBottom
                // The banner does NOT start at the content inset: GuideScreen
                // lifts it GuidePreviewBanner.tvLift UP into the reserved band
                // (tvOS's -28 pt, halved), so the old barInset + 2 dp band sat
                // INSIDE the banner, on top of the title (Streamer screenshot
                // 2026-09-11: bar bottom 53.5 dp, banner top 73.5 dp, strip
                // text centered at 78.5 dp). Subtracting the lift puts the
                // band back where it is drawn. The content inset itself is
                // untouched, so the banner/guide do not move.
                val bannerTop = barInset + topHintGap -
                    com.aeriotv.android.feature.livetv.grid.GuidePreviewBanner.tvLift
                val bannerFirstText = bannerTop +
                    com.aeriotv.android.feature.livetv.grid.GuidePreviewBanner.firstTextInset
                // At least 6 dp of clear space above that first text line;
                // when the band is tight this shrinks the strip's own top
                // offset toward the bar, never the gap to the banner.
                val minBannerClear = 6.dp
                // Fixed 8 dp below the drawn bar rather than centered: dead
                // center read too close to the nav circles (Logan 2026-09-11).
                val centeredTop = bandTop + 8.dp
                val maxTop = bannerFirstText - minBannerClear - stripHeight
                val stripBandTop = centeredTop.coerceIn(bandTop, maxTop.coerceAtLeast(bandTop))
                if (maxTop >= bandTop) {
                    // Stay centered even next to the mini: cap the width at
                    // twice the gap between screen center and the mini's left
                    // edge (205dp wide, 20dp from the end) so a long strip
                    // truncates with an ellipsis instead of shifting.
                    val screenW = androidx.compose.ui.platform.LocalConfiguration
                        .current.screenWidthDp.dp
                    val contentW = screenW - if (useQueRail) QueTvRailWidth else 0.dp
                    val stripMaxWidth = if (miniActive) {
                        (contentW - 450.dp).coerceAtLeast(160.dp)
                    } else {
                        (contentW - 48.dp).coerceAtLeast(160.dp)
                    }
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .fillMaxWidth()
                            .padding(start = if (useQueRail) QueTvRailWidth else 0.dp, top = stripBandTop)
                            .height(stripHeight),
                        contentAlignment = Alignment.Center,
                    ) {
                        com.aeriotv.android.ui.tv.TvRemoteHintStrip(
                            hints = com.aeriotv.android.core.remote.RemoteControlHints
                                .guideStripHints(
                                    map = hintMap,
                                    sidebarGroups = hintGroupSelector == "sidebar",
                                    miniActive = miniActive,
                                    radioActive = com.aeriotv.android.feature.player.RadioMode.state
                                        .collectAsStateWithLifecycle().value != null,
                                ),
                            modifier = Modifier.widthIn(max = stripMaxWidth),
                        )
                    }
                }
            }
                        fullScreenOverlay.value?.invoke()
            }
        }
        return
    }

    // GH #20: auto-hide the floating tab pill while scrolling down, reveal on
    // scroll up. A NestedScrollConnection on the content host sees every
    // tab's Lazy*/ScrollView deltas without hoisting any per-tab scroll
    // state; it only OBSERVES (returns Offset.Zero) so list scrolling is
    // untouched, and only reads vertical deltas so the guide's horizontal
    // timeline can't toggle the bar. Hide needs a deliberate ~48dp downward
    // pull; reveal is eager (~12dp up) plus any tab switch. Only the pill
    // slides away -- the floating MiniPlayerRow card above it stays put,
    // since hiding an actively playing stream's controls would orphan it.
    var bottomBarVisible by remember { mutableStateOf(true) }
    val density = LocalDensity.current
    // Tablets (sw >= 600 dp) keep a static bottom pill like the iPad: no
    // collapse into the mini pill on scroll. Phones keep collapsing.
    val staticTabletBar = androidx.compose.ui.platform.LocalConfiguration.current
        .smallestScreenWidthDp >= 600
    LaunchedEffect(staticTabletBar) { if (staticTabletBar) bottomBarVisible = true }
    // Tablets: stash the corner mini at the trailing edge while Settings is
    // selected (iPad parity, HomeView.swift MiniPlayerSettingsStash). Every
    // tab change drops a sliver peek, as the iPad resets settingsMiniPeek.
    // Cleared on dispose so a player / search route never inherits it.
    LaunchedEffect(selectedTab, staticTabletBar) {
        com.aeriotv.android.feature.player.PhoneMiniChrome.settingsPeek.value = false
        com.aeriotv.android.feature.player.MiniPlayerChrome
            .settingsStashed.value = staticTabletBar && selectedTab == AppTab.Settings
    }
    androidx.compose.runtime.DisposableEffect(Unit) {
        onDispose {
            com.aeriotv.android.feature.player.MiniPlayerChrome.settingsStashed.value = false
            com.aeriotv.android.feature.player.PhoneMiniChrome.settingsPeek.value = false
        }
    }
    val bottomBarScrollConnection = remember(density, staticTabletBar) {
        val hidePx = with(density) { 48.dp.toPx() }
        val showPx = with(density) { 12.dp.toPx() }
        object : NestedScrollConnection {
            // Distance accumulated in the current direction; direction flips
            // reset the opposite counter so slow jittery drags near a
            // threshold can't oscillate the bar.
            private var downDistance = 0f
            private var upDistance = 0f
            override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                val dy = available.y
                if (staticTabletBar) return Offset.Zero
                if (dy < -0.5f) {
                    downDistance += -dy
                    upDistance = 0f
                    if (downDistance > hidePx) bottomBarVisible = false
                } else if (dy > 0.5f) {
                    upDistance += dy
                    downDistance = 0f
                    if (upDistance > showPx) bottomBarVisible = true
                }
                return Offset.Zero
            }
        }
    }
    // Switching tabs must always reveal the bar: the new tab may be short
    // enough that no upward scroll is possible to bring it back.
    LaunchedEffect(selectedTab) { bottomBarVisible = true }

    // Every non-TV form factor (phone, tablet, foldable, either orientation)
    // uses the floating bottom bar below (Logan 2026-10-04, iPad parity with
    // Apple da4904e). Tablets keep their two-pane Settings and grid columns;
    // only the bar placement is shared with the phone.

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = Color.Transparent,
        contentColor = MaterialTheme.colorScheme.onBackground,
        // Each tab owns its own TopAppBar with its own status-bar inset. Without
        // overriding here, Scaffold would also add a status-bar top inset to the
        // content padding, producing a ~30dp empty gap above every TopAppBar.
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        // iOS 26 parity: no Scaffold bottomBar. The tab bar is a floating pill
        // OVERLAYING the content (below), so every tab keeps the full screen
        // height and content scrolls behind the pill, exactly like the iPhone
        // app's Liquid-Glass bar. Tab screens already reserve ~104dp of bottom
        // content padding, so their last rows scroll clear of the pill.
    ) { padding ->
      // The floating pill lays itself out ABOVE the system navigation inset
      // (navigationBarsPadding + 10dp below), so a flat 96dp reserve left the
      // last rows of a scrolling screen sitting under the pill on phones with
      // a gesture bar or 3-button nav. Add that same system inset here so the
      // reserve matches where the pill actually is.
      val navBarInset = WindowInsets.navigationBars.asPaddingValues()
          .calculateBottomPadding()
      // Height of the whole bottom overlay (cast card, Kept Live row, mini
      // row, tab pill, system inset), measured below. While a card or the
      // Kept Live row shows it outgrows the flat reserve, and the reserve
      // follows it so every tab's last row scrolls clear (Logan 2026-10-05,
      // iPad parity). Bar alone stays at the flat reserve.
      var bottomOverlayHeightPx by remember { mutableStateOf(0) }
      val bottomOverlayHeight = with(LocalDensity.current) { bottomOverlayHeightPx.toDp() }
      androidx.compose.runtime.CompositionLocalProvider(
          LocalTabBarBottomInset provides maxOf(96.dp + navBarInset, bottomOverlayHeight + 12.dp),
      ) {
      androidx.compose.foundation.layout.Column(modifier = Modifier.fillMaxSize()) {
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(padding)
                // GH #20: observe every tab's scroll for the bottom-bar hide.
                .nestedScroll(bottomBarScrollConnection),
        ) {
            androidx.compose.runtime.CompositionLocalProvider(
                com.aeriotv.android.feature.livetv.LocalRetainedChannelIds provides retainedIds,
            ) {
            MainTabContent(
                selectedTab = selectedTab,
                tabs = tabs,
                onChannelClick = onChannelClick,
                onMovieClick = onMovieClick,
                onSeriesClick = onSeriesClick,
                onEpisodeResume = onEpisodeResume,
                onResumeMovie = onResumeMovie,
                onPlayMovie = onPlayMovie,
                onPlayMovieFromStart = onPlayMovieFromStart,
                onEpisodeResumeFromStart = onEpisodeResumeFromStart,
                onPlayRecording = onPlayRecording,
                onPlayCatchup = onPlayCatchup,
                onLaunchMultiview = onLaunchMultiview,
                onWatchLive = onWatchLive,
                onWatchFromBeginning = onWatchFromBeginning,
                onOpenSearch = onOpenSearch,
                onSelectTab = { selectedTab = it; initialTabApplied = true },
                viewModel = viewModel,
                visited = visitedTabs,
                modifier = Modifier.fillMaxSize(),
            )
            }
            // No "Syncing" pill on phone: it sat on top of the Live TV
            // header's sidebar button, and the tab already shows a spinner.
            // Bottom overlay: floating mini-player card above the floating tab
            // pill. The mini stays put while the pill slides away on scroll
            // (GH #20) so an active stream's controls are never hidden.
            // Phone floating mini (PhoneMiniPlayer.kt) is mounted at the
            // activity root, so publish this overlay's measured top: the mini's
            // bottom corners rest above the cast card, button and tab bar.
            androidx.compose.runtime.DisposableEffect(Unit) {
                onDispose {
                    com.aeriotv.android.feature.player.PhoneMiniChrome
                        .bottomChromeTopPx.floatValue = 0f
                }
            }
            androidx.compose.foundation.layout.Column(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .onGloballyPositioned {
                        com.aeriotv.android.feature.player.PhoneMiniChrome
                            .bottomChromeTopPx.floatValue = it.boundsInRoot().top
                        if (it.size.height != bottomOverlayHeightPx) {
                            bottomOverlayHeightPx = it.size.height
                        }
                    }
                    .navigationBarsPadding()
                    .padding(bottom = 10.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                // THE cast card (Logan 2026-09-12): ONE card above the tab bar
                // for whichever transport this phone is driving (Google Cast or
                // the AerioTV Remote companion link). It appears the moment a
                // session connects -- even with nothing playing yet -- and a tap
                // opens the remote controls as a sheet over the current page,
                // never a full-screen takeover. The local mini-player is
                // suppressed while casting, so the cards never stack.
                val casting = castState is com.aeriotv.android.core.cast.AerioCastSender.State.Connected
                // Change Cast Device handoff: collected here because this shell
                // stays composed across the receiver switch, unlike the card.
                // Cast through onChannelClick, the same path a channel tap uses.
                // Latest channels / click handler, not the first composition's.
                val handoffChannels by androidx.compose.runtime.rememberUpdatedState(state.channels)
                val handoffCast by androidx.compose.runtime.rememberUpdatedState(onCastChannel)
                androidx.compose.runtime.LaunchedEffect(castSender) {
                    castSender.handoffSeed.collect { id ->
                        castSender.consumeHandoffSeed()
                        val bare = id.substringAfter(':', id)
                        val ch = handoffChannels.firstOrNull { it.id == id }
                            ?: handoffChannels.firstOrNull { it.id.substringAfter(':', it.id) == bare }
                            ?: handoffChannels.firstOrNull { it.name == id }
                        if (ch == null) {
                            android.util.Log.w("AerioCast", "[Cast] handoff seed $id: no matching channel")
                        } else {
                            handoffCast(ch)
                        }
                    }
                }
                val companionTv = companionConn
                    as? com.aeriotv.android.core.cast.companion.CompanionRemoteController.Conn.Connected
                // Tablets (sw >= 600 dp) and the measured width of the
                // tablet's wrap-content tab capsule (set by the pill below).
                val tabletNav = androidx.compose.ui.platform.LocalConfiguration.current
                    .smallestScreenWidthDp >= 600
                var navBarWidthPx by remember { mutableStateOf(0) }
                // Every card above the nav bar takes exactly the bar's measured
                // frame (Logan 2026-10-05, all platforms). Tablets: the floating
                // pill's measured width, centered (screen width minus 32 dp, at
                // most 620 dp, only until the pill has been measured).
                val tabletCardWidth = if (tabletNav) {
                    if (navBarWidthPx > 0) {
                        with(LocalDensity.current) { navBarWidthPx.toDp() }
                    } else {
                        val screenW = androidx.compose.ui.platform.LocalConfiguration.current.screenWidthDp.dp
                        minOf(620.dp, (screenW - 32.dp).coerceAtLeast(0.dp))
                    }
                } else null
                // GH #33: round floating "Control a TV" button above the right
                // end of the tab bar -- appears when a controllable AerioTV TV
                // is discovered on the LAN OR a Google Cast route exists, so the
                // phone can be a remote / start a cast without opening a channel
                // first (task #255). Hidden while already controlling / casting
                // (their cards take over).
                val showControlFab = (companionDevices.isNotEmpty() ||
                        castState !is com.aeriotv.android.core.cast.AerioCastSender.State.Unavailable) &&
                    companionConn !is com.aeriotv.android.core.cast.companion
                        .CompanionRemoteController.Conn.Connected &&
                    !casting && !isTv
                // Tablets (sw >= 600 dp): the button sits static at the
                // trailing edge on the pill row (below) and never moves with
                // the collapse (Logan 2026-10-04). Phones keep the above-the-bar
                // spot that drops level with the minimized pill.
                val phoneFab = showControlFab && bottomBarVisible && !tabletNav
                // Keep Recent Channels Live pill (Apple parity, Logan
                // 2026-10-04): one compact line sharing the Control a TV
                // button's row, pill leading and filling the width, button
                // trailing. Two or more kept: tapping the text opens the Kept
                // Live list (the same dialog the TV circle uses). This scaffold
                // is not composed under the fullscreen player; there the
                // Options menu carries the Kept Live rows instead.
                // A channel being cast is not listed (Logan 2026-10-05); it
                // comes back when casting stops if it is still kept.
                val castContentNow by castSender.content.collectAsStateWithLifecycle()
                val castChannelId = if (casting) castContentNow?.mediaId else null
                val keptRowList = remember(retainedList, castChannelId) {
                    if (castChannelId == null) retainedList else {
                        val bare = castChannelId.substringAfter(':', castChannelId)
                        retainedList.filter {
                            it.channelId != castChannelId &&
                                it.channelId.substringAfter(':', it.channelId) != bare
                        }
                    }
                }
                val showKept = keptRowList.isNotEmpty() && !isTv
                // Multiview staging dock card (Logan 2026-10-06): same capsule
                // and frame as the cast and Kept Live cards, stacked above Kept
                // Live. Beside the Control a TV button only when it is the
                // last card in the stack (no Kept Live card below it).
                val mvStaging by multiviewStore.isStaging.collectAsStateWithLifecycle()
                val mvTiles by multiviewStore.selected.collectAsStateWithLifecycle()
                val showMv = mvStaging && mvTiles.isNotEmpty() && !isTv
                val mvRowFrame = if (tabletCardWidth != null) {
                    Modifier.width(tabletCardWidth)
                } else {
                    Modifier.widthIn(max = 600.dp).fillMaxWidth().padding(horizontal = 20.dp)
                }
                // Multiview playing in the background (round 2, 2026-10-07):
                // the cast card's shape, stacked with the other dock cards.
                val mvBg by com.aeriotv.android.feature.multiview.MultiviewBackground.state
                    .collectAsStateWithLifecycle()
                val mvBgState = mvBg
                // Dock stack (Apple parity, HomeView.swift dock VStack). Every
                // card takes the nav bar's measured frame.
                // Phones, top to bottom: cast card, background Multiview,
                // staging Multiview, Kept Live directly above the tab bar. The
                // Control a TV button rides the LOWEST card row at that card's
                // height (the card narrows), or its own row with no cards.
                // Tablets, top to bottom: staging Multiview, background
                // Multiview, Kept Live, cast card at the bottom; no circle
                // beside them (the tablet button lives on the pill row).
                val showMvBg = mvBgState != null && !isTv
                val radioOnDock = com.aeriotv.android.feature.player.RadioMode.state
                    .collectAsStateWithLifecycle().value != null && !isTv && !casting
                val fabRow = when {
                    !phoneFab -> 0
                    showKept -> 1
                    showMv -> 2
                    showMvBg -> 3
                    // Radio Mode card row (Apple parity, Logan 2026-10-15):
                    // the card narrows and the button sits at its trailing
                    // edge, like Kept Live. The button hides while casting,
                    // so the cast card never shares the row.
                    radioOnDock -> 5
                    else -> 4
                }
                @Composable
                fun DockFab() {
                    Spacer(Modifier.width(12.dp))
                    CompanionControlFab(
                        onClick = { showCompanionPicker = true },
                        diameter = com.aeriotv.android.feature.livetv.RetainedCardHeight,
                    )
                }
                fun gapAfter(row: Int) = if (tabletNav) 12.dp else if (fabRow == row) 10.dp else 8.dp
                @Composable
                fun DockKept() {
                    if (showKept) {
                        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                            Row(mvRowFrame, verticalAlignment = Alignment.CenterVertically) {
                                com.aeriotv.android.feature.livetv.RetainedChannelsPill(
                                    retained = keptRowList,
                                    onTune = tuneRetained,
                                    onOpenList = { showRetainedDialog = true },
                                    onStop = retainedVm::stop,
                                    onStopAll = retainedVm::stopAll,
                                    capsule = tabletNav,
                                    modifier = Modifier.weight(1f),
                                )
                                if (fabRow == 1) DockFab()
                            }
                        }
                        Spacer(Modifier.height(gapAfter(1)))
                    }
                }
                @Composable
                fun DockMvStaging() {
                    if (showMv) {
                        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                            Row(mvRowFrame, verticalAlignment = Alignment.CenterVertically) {
                                com.aeriotv.android.feature.multiview.MultiviewDockCard(
                                    tiles = mvTiles,
                                    tablet = tabletNav,
                                    onOpen = { showMultiviewSheet = true },
                                    onPlay = playStagedMultiview,
                                    modifier = Modifier.weight(1f),
                                )
                                if (fabRow == 2) DockFab()
                            }
                        }
                        Spacer(Modifier.height(gapAfter(2)))
                    }
                }
                @Composable
                fun DockMvBg() {
                    if (showMvBg && mvBgState != null) {
                        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                            Row(mvRowFrame, verticalAlignment = Alignment.CenterVertically) {
                                com.aeriotv.android.feature.multiview.MultiviewDockCard(
                                    tiles = mvBgState.tiles,
                                    tablet = tabletNav,
                                    title = com.aeriotv.android.feature.multiview.multiviewBackgroundTitle(mvBgState.tiles.size),
                                    actionLabel = "Stop",
                                    onOpen = onLaunchMultiview,
                                    onPlay = {
                                        com.aeriotv.android.feature.multiview.MultiviewBackground.stop()
                                        // The mirrored pile ends with the tiles.
                                        if (!multiviewStore.isStaging.value) multiviewStore.clear()
                                    },
                                    modifier = Modifier.weight(1f),
                                )
                                if (fabRow == 3) DockFab()
                            }
                        }
                        Spacer(Modifier.height(gapAfter(3)))
                    }
                }
                @Composable
                fun DockFabOnly() {
                    if (fabRow == 4) {
                        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                            Row(mvRowFrame, horizontalArrangement = Arrangement.End) {
                                CompanionControlFab(onClick = { showCompanionPicker = true })
                            }
                        }
                        Spacer(Modifier.height(gapAfter(4)))
                    }
                }
                @Composable
                fun DockCast() {
                    if ((casting || companionTv != null) && !isTv) {
                        // Switch Stream gate: LocalIsDispatcharrAdmin is only
                        // provided inside the player route, so out here (the cast
                        // card and sheet, composite tile menu) it read its false
                        // default (device pass cc2c37c7: tile menu had no Switch
                        // Stream on a switch=allowed account). Provide it from the
                        // live active playlist row, the same row the player uses.
                        androidx.compose.runtime.CompositionLocalProvider(
                            com.aeriotv.android.ui.LocalIsDispatcharrAdmin provides
                                (capsPlaylist?.canSwitchStream() ?: false),
                        ) {
                        com.aeriotv.android.feature.cast.CastTransportCard(
                            tabletWidth = tabletCardWidth,
                            multiviewCast = multiviewCast,
                            compositeHeaders = if (mvWebReceiver) ({
                                com.aeriotv.android.core.network.PlaybackHeaders.forPlaylist(state.playlist)
                            }) else null,
                            castSender = castSender,
                            companionRemote = companionRemote,
                            channels = state.channels,
                            nowProgramme = { ch ->
                                state.epgByChannel[ch.guideMatchKey]?.nowPlaying()
                            },
                            onCastChannel = onCastChannel,
                            loadChannelStreams = { channelIntPk ->
                                val m3uNames = viewModel.loadM3uAccountNames()
                                viewModel.loadChannelStreams(channelIntPk).map { st ->
                                    com.aeriotv.android.feature.player.StreamOption(
                                        id = st.id,
                                        name = st.name.orEmpty(),
                                        resolution = st.resolution,
                                        fps = st.sourceFps,
                                        bitrateKbps = st.outputBitrateKbps,
                                        videoCodec = st.videoCodec,
                                        audioCodec = st.audioCodec,
                                        sourceName = st.m3uAccount?.let { m3uNames[it] },
                                    )
                                }
                            },
                            loadCurrentStreamId = { uuid -> viewModel.loadCurrentStreamId(uuid) },
                            switchChannelStream = { uuid, streamId ->
                                viewModel.switchChannelStream(uuid, streamId).getOrThrow()
                            },
                            recheckSwitchStreamAllowed = { trigger ->
                                viewModel.recheckSwitchStreamAllowed(trigger)
                            },
                        )
                        }
                        // 12 dp above the pill on tablets (iPad parity).
                        Spacer(Modifier.height(if (tabletNav) 12.dp else 8.dp))
                    }
                }
                // Radio Mode (Android#127): the cast card's place and style.
                val radio by com.aeriotv.android.feature.player.RadioMode.state
                    .collectAsStateWithLifecycle()
                @Composable
                fun DockRadio() {
                    if (radio != null && !isTv && !casting) {
                        val radioRow = fabRow == 5 && tabletCardWidth == null
                        var radioCardPx by remember { mutableStateOf(0) }
                        val density = LocalDensity.current
                        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                        Row(if (radioRow) mvRowFrame else Modifier, verticalAlignment = Alignment.CenterVertically) {
                        com.aeriotv.android.feature.player.RadioTransportCard(
                            modifier = if (radioRow) Modifier.weight(1f).onSizeChanged { radioCardPx = it.height } else Modifier,
                            inRow = radioRow,
                            tabletWidth = tabletCardWidth,
                            nowProgramme = { ch -> state.epgByChannel[ch.guideMatchKey]?.nowPlaying() },
                            loadChannelStreams = { channelIntPk ->
                                val m3uNames = viewModel.loadM3uAccountNames()
                                viewModel.loadChannelStreams(channelIntPk).map { st ->
                                    com.aeriotv.android.feature.player.StreamOption(
                                        id = st.id,
                                        name = st.name.orEmpty(),
                                        resolution = st.resolution,
                                        fps = st.sourceFps,
                                        bitrateKbps = st.outputBitrateKbps,
                                        videoCodec = st.videoCodec,
                                        audioCodec = st.audioCodec,
                                        sourceName = st.m3uAccount?.let { m3uNames[it] },
                                    )
                                }
                            },
                            loadCurrentStreamId = { uuid -> viewModel.loadCurrentStreamId(uuid) },
                            switchChannelStream = { uuid, streamId ->
                                viewModel.switchChannelStream(uuid, streamId).getOrThrow()
                            },
                            recheckSwitchStreamAllowed = { trigger -> viewModel.recheckSwitchStreamAllowed(trigger) },
                            isDispatcharrAdmin = capsPlaylist?.canSwitchStream() ?: false,
                        )
                        if (radioRow) {
                            Spacer(Modifier.width(12.dp))
                            CompanionControlFab(
                                onClick = { showCompanionPicker = true },
                                diameter = if (radioCardPx > 0) with(density) { radioCardPx.toDp() }
                                    else com.aeriotv.android.feature.livetv.RetainedCardHeight,
                            )
                        }
                        }
                        }
                        Spacer(Modifier.height(if (tabletNav) 12.dp else if (radioRow) 10.dp else 8.dp))
                    }
                }
                if (tabletNav) {
                    DockMvStaging(); DockMvBg(); DockKept(); DockFabOnly(); DockRadio(); DockCast()
                } else {
                    DockRadio(); DockCast(); DockMvBg(); DockMvStaging(); DockKept(); DockFabOnly()
                }
                val miniState = miniPlayerState
                // Phase 139 / audit #22: on TV the mini-player is a top-right
                // video window (TvMiniPlayerOverlay, mounted at NavHost root).
                // Suppress the phone-style card so we don't double-render the
                // same session. GH #33: also suppress it while casting so it can
                // never stack under the Now-Casting card (a local mini session
                // that was Active before the cast started would otherwise show).
                // The row is now only the fallback for an Active session whose
                // video window is NOT the floating mini (phone Back and the
                // top-strip swipe minimize into that window instead).
                if (miniState is MiniPlayerSession.State.Active && !isTv && !casting &&
                    exoWindowMode != com.aeriotv.android.feature.player.ExoWindowState.Mode.Mini
                ) {
                    val channel = miniState.channel
                    val nowProgramme = state.epgByChannel[channel.guideMatchKey]?.nowPlaying()
                    // The nav bar's frame, like every card above it.
                    Box(
                        modifier = (if (tabletCardWidth != null) Modifier.width(tabletCardWidth)
                            else Modifier.widthIn(max = 600.dp).fillMaxWidth().padding(horizontal = 20.dp))
                            .clip(RoundedCornerShape(20.dp))
                            .border(
                                1.dp,
                                MaterialTheme.colorScheme.primary.copy(alpha = 0.10f),
                                RoundedCornerShape(20.dp),
                            ),
                    ) {
                        MiniPlayerRow(
                            channel = channel,
                            nowProgramme = nowProgramme,
                            isPaused = miniPaused,
                            onResume = {
                                val resumed = miniPlayerVm.resumeChannel()
                                if (resumed != null) onChannelResumeLocal(resumed)
                            },
                            onTogglePause = {
                                exoHolder.setPaused(!exoHolder.isPaused())
                                miniPaused = exoHolder.isPaused()
                            },
                            onDismiss = {
                                miniPlayerVm.dismiss()
                                exoHolder.destroy()
                                com.aeriotv.android.core.playback.AerioMediaPlaybackService
                                    .stop(context)
                            },
                        )
                    }
                    Spacer(Modifier.height(8.dp))
                }
                run {
                    // iOS 26 parity (Logan 2026-09-09): scrolling down does not
                    // hide the bar, it MINIMIZES it to a small pill in the
                    // bottom-left corner showing the active tab's icon. Tapping
                    // the pill or scrolling up brings the full bar back.
                    // Right-to-left collapse INTO the mini pill (Logan
                    // 2026-09-09, both platforms): the bar scales toward the
                    // pill's centre and fades over the last stretch while the
                    // pill grows in; restore plays it back.
                    val collapse by animateFloatAsState(
                        targetValue = if (bottomBarVisible) 0f else 1f,
                        // A touch slower than the iPhone's 320 ms so the
                        // collapse reads (Logan 2026-09-09).
                        animationSpec = tween(420),
                        label = "tabBarCollapse",
                    )
                    val density = LocalDensity.current
                    var barSize by remember { mutableStateOf(androidx.compose.ui.unit.IntSize.Zero) }
                    Box(Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
                        if (collapse < 0.999f) {
                            val pillW = with(density) { 64.dp.toPx() }
                            val pillH = with(density) { 52.dp.toPx() }
                            // The bar's left edge sits 20 dp in; the pill's centre
                            // is 32 dp further along.
                            val pivotX = with(density) { 32.dp.toPx() } / barSize.width.coerceAtLeast(1)
                            FloatingTabBar(
                                tabs = tabs,
                                selected = selectedTab,
                                // Re-tap of the selected tab (see TabReselect):
                                // pop to that tab's root, else scroll it to the
                                // top. Either way the bar comes back out of its
                                // scroll-collapsed state, so the gesture never
                                // leaves the user looking at a hidden bar.
                                onSelect = {
                                    if (it == selectedTab) {
                                        bottomBarVisible = true
                                        TabReselect.emit(it)
                                    } else {
                                        selectedTab = it
                                        initialTabApplied = true
                                    }
                                },
                                tablet = tabletNav,
                                modifier = Modifier
                                    .onSizeChanged { barSize = it; navBarWidthPx = it.width }
                                    .graphicsLayer {
                                        transformOrigin = androidx.compose.ui.graphics.TransformOrigin(pivotX.coerceIn(0f, 1f), 0.5f)
                                        val sx = 1f - collapse * (1f - pillW / barSize.width.coerceAtLeast(1))
                                        val sy = 1f - collapse * (1f - pillH / barSize.height.coerceAtLeast(1))
                                        scaleX = sx; scaleY = sy
                                        alpha = 1f - ((collapse - 0.5f) / 0.45f).coerceIn(0f, 1f)
                                    },
                            )
                        }
                        if (collapse > 0.001f) {
                            val reveal = ((collapse - 0.35f) / 0.65f).coerceIn(0f, 1f)
                            MinimizedTabPill(
                                tab = selectedTab,
                                onClick = { bottomBarVisible = true },
                                modifier = Modifier
                                    .align(Alignment.CenterStart)
                                    .padding(start = 20.dp)
                                    .graphicsLayer { alpha = reveal; scaleX = 0.6f + 0.4f * reveal; scaleY = 0.6f + 0.4f * reveal },
                            )
                            if (showControlFab && !tabletNav) {
                                Box(
                                    Modifier.align(Alignment.CenterEnd).padding(end = 16.dp)
                                        .graphicsLayer { alpha = reveal },
                                ) {
                                    CompanionControlFab(onClick = { showCompanionPicker = true })
                                }
                            }
                        }
                        if (showControlFab && tabletNav) {
                            Box(Modifier.align(Alignment.CenterEnd).padding(end = 16.dp)) {
                                CompanionControlFab(onClick = { showCompanionPicker = true }, tablet = true)
                            }
                        }
                    }
                }
            }
        }
      }
      }
    }

    // Task #255: the floating "Control TV" pill opens the SAME unified picker
    // as the player's cast button (Google Cast routes + AerioTV companion TVs
    // with inline pairing), replacing the old companion-only dialog that made
    // cast targets invisible outside the player.
    if (showCompanionPicker) {
        // Force a fresh query sweep the moment the picker opens: the Fold's
        // WiFi misses mid-browse announcements, so a long-running browse can
        // be stale-by-omission (a TV that came up after the browse started).
        LaunchedEffect(Unit) { companionDiscovery.refresh() }
        com.aeriotv.android.feature.cast.CastRouteChooserDialog(
            sender = castSender,
            companionRemote = companionRemote,
            companionDiscovery = companionDiscovery,
            onDismiss = {
                // Abandon an in-flight/unpaired companion attempt so it
                // doesn't linger.
                if (companionConn !is com.aeriotv.android.core.cast.companion
                        .CompanionRemoteController.Conn.Connected &&
                    companionConn !is com.aeriotv.android.core.cast.companion
                        .CompanionRemoteController.Conn.Idle
                ) {
                    companionRemote.disconnect()
                }
                showCompanionPicker = false
            },
        )
    }
    // A fresh connection made from the picker -> close it; the Controlling card
    // + player remote take over.
    LaunchedEffect(companionConn) {
        if (companionConn is com.aeriotv.android.core.cast.companion
                .CompanionRemoteController.Conn.Connected) {
            showCompanionPicker = false
        }
    }
}

/** Floating bottom-nav chrome shared by the tab bar pill, the minimized pill
 *  and the Control a TV button so they read as one layer over busy content
 *  (guide grid, posters): solid card surface at 92 percent, a 1 dp on-surface
 *  hairline at 12 percent and a soft black drop shadow. Material styling, no
 *  translucent glass (Logan 2026-10-04, same recipe as the iPad). */
@Composable
internal fun Modifier.floatingNavChrome(shape: androidx.compose.ui.graphics.Shape): Modifier {
    val cs = MaterialTheme.colorScheme
    return this
        .dropShadow(
            shape,
            androidx.compose.ui.graphics.shadow.Shadow(
                radius = 18.dp,
                color = Color.Black.copy(alpha = 0.35f),
                offset = androidx.compose.ui.unit.DpOffset(0.dp, 6.dp),
            ),
        )
        .clip(shape)
        .background(cs.surface.copy(alpha = 0.92f))
        .border(1.dp, cs.onSurface.copy(alpha = 0.12f), shape)
}

/**
 * GH #33: round floating button above the right end of the tab bar -- entry
 * to control a discovered TV. Matches the card chrome (surface + faint
 * primary border) rather than a filled pill, mirroring the iOS glass FAB.
 */
@Composable
private fun CompanionControlFab(
    onClick: () -> Unit,
    tablet: Boolean = false,
    /** Beside the Kept Live card: a circle of this diameter. */
    diameter: androidx.compose.ui.unit.Dp? = null,
) {
    // Same shape and chrome as MinimizedTabPill, which it sits opposite
    // once the bar minimizes (Logan 2026-09-09).
    Box(
        modifier = Modifier
            // Tablets: a 56 dp circle level with the 56 dp tab capsule.
            .then(
                if (diameter != null) Modifier.size(diameter)
                else Modifier.size(width = if (tablet) 56.dp else 64.dp, height = if (tablet) 56.dp else 52.dp),
            )
            .floatingNavChrome(if (tablet || diameter != null) CircleShape else RoundedCornerShape(26.dp))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            // Google's Cast glyph (Logan 2026-09-09): the Tv glyph doubled
            // as the TV Shows tab icon.
            imageVector = Icons.Filled.Cast,
            contentDescription = "Control a TV",
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(22.dp),
        )
    }
}

/**
 * iOS 26 parity: the phone tab bar as a centered, floating, rounded pill
 * (the iPhone app's Liquid-Glass bar) instead of a full-width Material
 * NavigationBar. Wrap-content width, surface fill with the shared accent
 * hairline, selected tab gets a soft accent capsule behind icon + label.
 */

@Composable
private fun FloatingTabBar(
    tabs: List<AppTab>,
    selected: AppTab,
    onSelect: (AppTab) -> Unit,
    modifier: Modifier = Modifier,
    tablet: Boolean = false,
) {
    if (tablet) {
        TabletTabBar(tabs, selected, onSelect, modifier)
        return
    }
    // 2026-07-12 (user report: mistapping channels behind the pill when
    // changing tabs): sized up to the iPhone bar's proportions - the pill
    // now spans the width minus side margins with evenly distributed,
    // taller tab targets instead of a compact wrap-content cluster.
    // Phone-sized pill on every window: on a foldable's inner display or a
    // landscape phone it centres at 600 dp instead of spanning the width
    // (Logan 2026-09-08: "WAY too big").
    androidx.compose.foundation.layout.Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
    Row(
        modifier = modifier
            .widthIn(max = 600.dp)
            .fillMaxWidth()
            .padding(horizontal = 20.dp)
            .floatingNavChrome(RoundedCornerShape(36.dp))
            // iPhone bar height (~53 pt): the Android pill measured ~69 dp
            // (Logan 2026-09-09). Outer 6 + item 5 + icon 22 + label 12 + 5 + 6.
            .padding(horizontal = 12.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        tabs.forEach { tab ->
            val isSel = tab == selected
            androidx.compose.foundation.layout.Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(20.dp))
                    .background(
                        if (isSel) MaterialTheme.colorScheme.primary.copy(alpha = 0.14f)
                        else Color.Transparent,
                    )
                    .clickable { onSelect(tab) }
                    .padding(vertical = 5.dp),
            ) {
                Icon(
                    imageVector = if (isSel) tab.iconSelected else tab.iconUnselected,
                    contentDescription = tab.label,
                    tint = if (isSel) MaterialTheme.colorScheme.primary
                    else MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(22.dp),
                )
                Text(
                    text = tab.label,
                    fontSize = 10.sp,
                    lineHeight = 12.sp,
                    // One line at every Text Size: the bar grows taller with
                    // the text, a long label ellipsizes instead of wrapping.
                    maxLines = 1,
                    overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                    fontWeight = FontWeight.Medium,
                    color = if (isSel) MaterialTheme.colorScheme.textAccent
                    else MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
    }
}

/** Tablet tab bar, iPad parity (Logan 2026-10-04): a centered wrap-content
 *  capsule 56 dp tall, each tab laid out icon then title, 28 dp between tab
 *  contents and 24 dp from the capsule edges. The selected tab gets its own
 *  accent capsule (22 percent) with accent icon and title; the rest use the
 *  primary text color. Same floating chrome as the phone bar. */
@Composable
private fun TabletTabBar(
    tabs: List<AppTab>,
    selected: AppTab,
    onSelect: (AppTab) -> Unit,
    modifier: Modifier = Modifier,
) {
    val cs = MaterialTheme.colorScheme
    androidx.compose.foundation.layout.Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        Row(
            modifier = modifier
                .height(56.dp)
                .floatingNavChrome(RoundedCornerShape(28.dp))
                // 10 dp outer + 14 dp item padding = 24 dp to the edge;
                // 14 + 14 between neighbours = 28 dp between tab contents.
                .padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            tabs.forEach { tab ->
                val isSel = tab == selected
                val tint = if (isSel) cs.primary else cs.onSurface
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxHeight()
                        .clip(RoundedCornerShape(22.dp))
                        .background(if (isSel) cs.primary.copy(alpha = 0.22f) else Color.Transparent)
                        .clickable { onSelect(tab) }
                        .padding(horizontal = 14.dp),
                ) {
                    Icon(
                        imageVector = if (isSel) tab.iconSelected else tab.iconUnselected,
                        contentDescription = null,
                        tint = tint,
                        modifier = Modifier.size(22.dp),
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = tab.label,
                        fontSize = 17.sp,
                        maxLines = 1,
                        fontWeight = FontWeight.Medium,
                        color = if (isSel) cs.textAccent else cs.onSurface,
                    )
                }
            }
        }
    }
}

/** The minimized tab bar: one capsule in the bottom-left corner carrying the
 *  active tab's icon, the way the iOS 26 bar collapses when the content
 *  scrolls down. Same height as the full pill so nothing shifts. */
@Composable
private fun MinimizedTabPill(
    tab: AppTab,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    androidx.compose.foundation.layout.Box(modifier = Modifier.fillMaxWidth()) {
        androidx.compose.foundation.layout.Box(
            contentAlignment = Alignment.Center,
            modifier = modifier
                .size(width = 64.dp, height = 52.dp)
                .floatingNavChrome(RoundedCornerShape(26.dp))
                .clickable(onClick = onClick),
        ) {
            Icon(
                imageVector = tab.iconSelected,
                contentDescription = "Show tab bar, ${tab.label}",
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(22.dp),
            )
        }
    }
}


/**
 * Shared body for both the phone (bottom-nav Scaffold) and TV (top-tab) shells.
 * [modifier] carries the per-shell insets: Scaffold content padding on phone,
 * a weight + fill on TV.
 */
@Composable
private fun MainTabContent(
    selectedTab: AppTab,
    /** Tabs currently present; only these are kept alive. */
    tabs: List<AppTab>,
    onChannelClick: (M3UChannel) -> Unit,
    onMovieClick: (String) -> Unit,
    onSeriesClick: (Int) -> Unit,
    onEpisodeResume: (String) -> Unit,
    onResumeMovie: (String) -> Unit,
    onPlayMovie: (String) -> Unit = {},
    /** See MainScaffold: start-at-zero siblings that keep the progress row. */
    onPlayMovieFromStart: (String) -> Unit = onPlayMovie,
    onEpisodeResumeFromStart: (String) -> Unit = onEpisodeResume,
    onPlayRecording: (String, String, Int) -> Unit,
    onPlayCatchup: (String, String, String, Long, Long, String, String) -> Unit,
    onLaunchMultiview: () -> Unit,
    onWatchLive: (String, String, Boolean, Long, Int?) -> Unit,
    onWatchFromBeginning: (String, String, Boolean, Long, Int?, Boolean) -> Unit,
    onOpenSearch: () -> Unit = {},
    // Lets a tab's own content change the selected tab (the TV Search tab's
    // Back returns to Live TV). Latches initialTabApplied at the call sites,
    // same as a manual pill press.
    onSelectTab: (AppTab) -> Unit = {},
    // The PLAYLIST_GRAPH-scoped PlaylistViewModel, threaded down so no tab
    // self-resolves a bare hiltViewModel() against the MAIN entry's store.
    // That default silently minted a SECOND PlaylistViewModel whose init ran
    // the whole channel+EPG bootstrap again (2026-07-12 Streamer report:
    // doubled Room reads, two 24k-row EPG maps, GC storm + jank for the
    // first minute of every cold launch, and the guide running on a
    // different state timeline than the scaffold).
    viewModel: PlaylistViewModel,
    /** Hoisted in MainScaffold; the TV tab bar reads it to skip its settle
     *  window for tabs that are already composed. */
    visited: androidx.compose.runtime.snapshots.SnapshotStateList<AppTab>,
    modifier: Modifier = Modifier,
) {
    // Keep visited tabs alive (Logan 2026-09-03: "why does every tab have to
    // reload?"): every tab present in [tabs] that has been shown once stays
    // composed; the inactive ones are measured at zero size and never placed,
    // so they neither draw nor take focus, and their Back handlers and focus
    // pulls are gated on [LocalTabIsActive]. A tab absent from [tabs] (no
    // favorites, VOD or recordings) is not composed at all. Search is the
    // floating screen and is never kept.
    if (selectedTab != AppTab.Search && selectedTab !in visited) visited.add(selectedTab)
    val keepAliveTabs = tabs.filter { it in visited }
    Box(modifier = modifier) {
        val render: @Composable (AppTab) -> Unit = { tab -> when (tab) {
            AppTab.LiveTV -> {
    LiveTVTabContent(
                    onChannelClick = onChannelClick,
                    onLaunchMultiview = onLaunchMultiview,
                    onOpenSearch = onOpenSearch,
                    // Catch-up (task #133/#136): a resolved timeshift URL plays
                    // through the recording-player route with programme window +
                    // panel tz for the scrubbable timeline.
                    onPlayCatchup = onPlayCatchup,
                    viewModel = viewModel,
                )
            }
            AppTab.Favorites -> {
    FavoritesTabContent(onChannelClick = onChannelClick, onPlayCatchup = onPlayCatchup)
            }
            AppTab.DVR -> {
                // Media center on every form factor (TV joined 2026-09-10).
                com.aeriotv.android.feature.dvr.DvrMediaTabContent(
                    onPlayRecording = onPlayRecording,
                    onWatchLive = onWatchLive,
                    onWatchFromBeginning = onWatchFromBeginning,
                )
            }
            AppTab.Movies -> {
    com.aeriotv.android.feature.movies.MediaTabContent(
                    kind = com.aeriotv.android.feature.movies.MediaKind.Movies,
                    onMovieClick = { uuid -> onMovieClick(uuid) },
                    onSeriesClick = { id -> onSeriesClick(id) },
                    onEpisodeResume = onEpisodeResume,
                    onResumeMovie = onResumeMovie,
                    onPlayMovie = onPlayMovie,
                    onPlayMovieFromStart = onPlayMovieFromStart,
                    onEpisodeResumeFromStart = onEpisodeResumeFromStart,
                )
            }
            AppTab.TVShows -> {
    com.aeriotv.android.feature.movies.MediaTabContent(
                    kind = com.aeriotv.android.feature.movies.MediaKind.TVShows,
                    onMovieClick = { uuid -> onMovieClick(uuid) },
                    onSeriesClick = { id -> onSeriesClick(id) },
                    onEpisodeResume = onEpisodeResume,
                    onResumeMovie = onResumeMovie,
                    onPlayMovie = onPlayMovie,
                    onPlayMovieFromStart = onPlayMovieFromStart,
                    onEpisodeResumeFromStart = onEpisodeResumeFromStart,
                )
            }
            AppTab.OnDemand -> {
    OnDemandTabContent(
                    onMovieClick = { movie -> onMovieClick(movie.uuid) },
                    onSeriesClick = { series -> onSeriesClick(series.id) },
                    onEpisodeResume = onEpisodeResume,
                    onResumeMovie = onResumeMovie,
                    onOpenSearch = onOpenSearch,
                )
            }
            AppTab.Settings -> {
    SettingsTabContent(playlistViewModel = viewModel)
                // TV-only tab (Logan 2026-08-06): the same global Search screen the
                // phone reaches via the app-bar globe, hosted in place. EPG results
                // go through requestGuideJump, whose scaffold collector already
                // switches to Live TV and jumps the guide; movie/series results use
                // the same detail routes as On Demand. No back arrow (the pushed
                // route keeps its own) and no field auto-focus - with
                // selection-follows-focus on the nav bar, a focus grab here would
                // yank the user out of the bar the moment the pill highlights.
            }
            AppTab.Search -> {
    com.aeriotv.android.feature.search.SearchScreen(
                    onBack = { onSelectTab(AppTab.LiveTV) },
                    onEpgResult = { channelKey, startMillis ->
                        viewModel.requestGuideJump(channelKey, startMillis)
                    },
                    onMovieClick = onMovieClick,
                    onSeriesClick = onSeriesClick,
                    showBackButton = false,
                    autoFocusField = false,
                )
            }
            else -> Unit
        } }
        if (selectedTab == AppTab.Search) {
            render(AppTab.Search)
        }
        // Each kept tab lives in ONE slot (keyed by tab, fixed order) and only
        // its modifier flips between hidden and shown: moving a tab between
        // two different parents would dispose and rebuild it, which is the
        // reload this exists to avoid. BackHandlers inside are gated on
        // LocalTabIsActive, so composition order does not matter for Back.
        keepAliveTabs.forEach { tab ->
            val active = tab == selectedTab
            androidx.compose.runtime.key(tab) {
                CompositionLocalProvider(LocalTabIsActive provides active) {
                    Box(if (active) Modifier.fillMaxSize() else Modifier.keepAliveHidden()) { render(tab) }
                }
            }
        }
    }
}

/**
 * 10-foot top navigation for Android TV. A horizontal, D-pad-traversable row of
 * pill tabs with overscan-safe margins. Selection follows focus (tvOS TabView
 * behaviour): landing on a tab switches to it; pressing DOWN drops into content.
 *
 * Audit task #57: [focusRequester] is attached to the pill Row and combined
 * with [Modifier.focusRestorer]. When a section calls `focusRequester
 * .requestFocus()` (via the D-pad UP route from the guide), focus lands on
 * the previously-focused pill rather than the first one - so the user comes
 * back exactly where they left.
 */
@Composable
private fun TvTopTabBar(
    tabs: List<AppTab>,
    selected: AppTab,
    onSelect: (AppTab) -> Unit,
    focusRequester: FocusRequester,
    tabEntryFocus: androidx.compose.runtime.State<FocusRequester?>? = null,
    lastUpKeyMs: LongArray = longArrayOf(0L),
    pillRequesters: Map<AppTab, FocusRequester> = emptyMap(),
    /** True when the tab is already composed and alive, so selecting it is a
     *  placement rather than a cold build and can commit immediately. */
    isTabWarm: (AppTab) -> Boolean = { false },
    /** Refresh circle (Logan 2026-08-06): TV's stand-in for pull-to-refresh.
     *  Re-fetches channels + EPG so Dispatcharr-side group/channel edits show
     *  up without a trip through Settings > playlist. */
    onRefresh: () -> Unit = {},
    refreshing: Boolean = false,
    refreshAnimates: Boolean = true,
    /** Reports the leftmost pixel the bar actually occupies (the action
     *  circles when shown, otherwise the centered capsule) so the top-left
     *  gesture hints can size themselves to the real gutter instead of a
     *  hard-coded guess. Logan 2026-08-10: the hint pill grew into the bar. */
    onLeftEdgeChanged: (Int) -> Unit = {},
    /** Keep Recent Channels Live: count of flipped-away channels still
     *  buffering. > 0 shows the indicator circle beside Refresh/Search -
     *  the one spot that is focus-reachable on every content tab (the
     *  guide's pill-row placement is skipped in sidebar group mode, and
     *  a standalone strip was not reachable by D-pad; field 2026-08-31). */
    retainedCount: Int = 0,
    onRetainedClick: () -> Unit = {},
    /** Bottom of the bar's DRAWN content (capsule / circles) in root px. The
     *  outer Box is 16 dp taller above and 12 dp below, so its measured height
     *  is not where the bar visually ends; the corner mini needs the real one. */
    onDrawnBottomChanged: (Float) -> Unit = {},
    /** Que Blue keeps the same focus/selection lifecycle in a fixed left rail. */
    useQueRail: Boolean = false,
    liveTvMode: LiveTVViewMode = LiveTVViewMode.Guide,
    onLiveTvModeSelect: (LiveTVViewMode) -> Unit = {},
    liveTvListFocusRequester: FocusRequester? = null,
    guideFocusRequester: FocusRequester? = null,
    toolbarFocusRequester: FocusRequester? = null,
) {
    // Selection-follows-focus, but committed ONLY for focus moves BETWEEN pills
    // (real D-pad traversal of the bar), never for focus ENTERING the bar from
    // outside. That entry case is exactly how the focus fallback used to bounce
    // the user to Live TV: drilling into a Settings sub-screen removes the
    // focused row, Compose hands focus to the first focusable in the tree (the
    // leftmost Live TV pill), and a straight onFocus -> onSelect switched the
    // tab, unmounting the sub-screen. We "arm" on the first pill focus after the
    // bar gains focus and only commit on subsequent in-bar moves; the
    // post-composition requestFocus that pulls focus back into the content can't
    // win that race on its own, so the guard lives here where it is deterministic.
    var navHasFocus by remember { mutableStateOf(false) }
    var focusedTab by remember { mutableStateOf<AppTab?>(null) }
    var armed by remember { mutableStateOf(false) }
    // Arm one frame AFTER the bar gains focus, so the focus that ENTERS the bar
    // (the same-frame pill focus, including the involuntary fallback) is never
    // treated as a deliberate selection. Deferring a frame makes this order
    // independent of whether the Row's or the pill's onFocusChanged fires first.
    LaunchedEffect(navHasFocus) {
        if (navHasFocus) {
            androidx.compose.runtime.withFrameNanos { }
            armed = true
        } else {
            armed = false
        }
    }
    LaunchedEffect(focusedTab) {
        val cur = focusedTab ?: return@LaunchedEffect
        // Deliberate bar ENTRY (a fresh D-pad UP) selects immediately too, so
        // highlighting a pill is always enough; the armed gate alone made the
        // first-focused pill need an extra move or OK (user report).
        val deliberateEntry =
            android.os.SystemClock.uptimeMillis() - lastUpKeyMs[0] < 400L
        if ((armed || deliberateEntry) && cur != selected) {
            // E-5 (perf campaign 2026-08-19): SETTLE before committing. Only
            // one tab branch is composed at a time, so each intermediate
            // commit while walking the pill row serially cold-builds and
            // disposes an entire tab (guide, On Demand grid, DVR) on the
            // Streamer's single big core. 250ms is under the "did it react"
            // threshold for a resting selection but longer than a pill-walk
            // step, so pass-through pills never build. This LaunchedEffect is
            // keyed on focusedTab: moving to the next pill cancels the
            // pending commit with the coroutine.
            //
            // 2026-09-11 (Streamer, measured): with the keep-alive slots that
            // landed in 4c800955 a tab that has been visited once is already
            // composed, so committing costs one placement (25-105 ms to the
            // first placed frame) and there is nothing to protect against.
            // The flat 250 ms was the WHOLE perceived delay Logan reported:
            // key to placed frame was 324-386 ms warm, of which ~280 ms was
            // this sleep. Cold tabs keep the settle window.
            if (!isTabWarm(cur)) kotlinx.coroutines.delay(250L)
            onSelect(cur)
        }
    }

    // Focus entering the bar by ANY route (the guide's routed UP, or plain
    // geometric 2D search from tabs that don't wire the requester) must land
    // on the SELECTED tab's pill. Geometric entry used to land on whichever
    // pill sat above the content column (On Demand over the centered Settings
    // form), and with selection-follows-focus that instantly switched tabs
    // (user report). The per-pill requesters + the group's entry redirect
    // replace focusRestorer: with selection following focus, the selected
    // pill IS the last-focused pill in every normal flow.
    // tvOS-style floating nav: the tabs are grouped into one centered, rounded
    // "segmented" capsule over the app background (no full-width surface toolbar
    // strip), so the bar reads as a polished pill group rather than a heavy bar.
    // The action circles hide on Settings (Logan 2026-08-06: they belong to
    // the content tabs - Live TV / DVR / On Demand). They stay while the
    // Search screen itself is up so its circle can show the selected fill.
    val showActionCircles = selected != AppTab.Settings
    // Cold start: TV initial focus falls on the LEFTMOST focusable, which is
    // now the Refresh circle - pull it onto the selected pill (the
    // pre-circle behavior, and an accidental OK there refreshed instead of
    // doing nothing). The system grants initial focus when the WINDOW gains
    // focus, which lands after composition - a plain one-frame LaunchedEffect
    // lost that race (Streamer 2026-08-06) - so key the one-shot pull on the
    // window-focus edge and run it a frame later.
    //
    // rememberSaveable, not remember: the full-screen player is its own nav
    // route, so the MAIN destination (and this bar) leaves composition while
    // it plays. With plain remember the flag came back false on return, the
    // pull fired a second time ~300 ms after the guide had refocused the
    // playing channel's cell, and Back from playback landed on the Live TV
    // pill (Streamer 2026-10-03, stack traced to this requestFocus). The
    // saveable state lives with the nav entry, so the pull stays one-shot
    // per Activity, which is what the cold-start case needs.
    var initialPillFocusPulled by androidx.compose.runtime.saveable.rememberSaveable { mutableStateOf(false) }
    // The cold-start pull's tab and time, until the landing tab is applied.
    var coldPull by remember { mutableStateOf<Pair<AppTab, Long>?>(null) }
    val windowFocused = androidx.compose.ui.platform.LocalWindowInfo.current.isWindowFocused
    LaunchedEffect(windowFocused) {
        if (windowFocused && !initialPillFocusPulled) {
            initialPillFocusPulled = true
            androidx.compose.runtime.withFrameNanos { }
            runCatching { pillRequesters[selected]?.requestFocus() }
            coldPull = selected to android.os.SystemClock.uptimeMillis()
            com.aeriotv.android.ui.tv.TvFocusTrace.guide("cold-start pull tab=$selected")
            com.aeriotv.android.ui.tv.TvColdStartFocus.pending = false
        } else if (initialPillFocusPulled) {
            com.aeriotv.android.ui.tv.TvColdStartFocus.pending = false
        }
    }
    // The saved Default Landing Tab is applied a beat AFTER the pull (the
    // preference loads async), so on a DVR / Movies / TV Shows landing the
    // pull focused the Live TV pill while the landing tab was shown
    // (Streamer 2026-10-04). Follow the landing tab once, only while focus
    // still sits on the pulled pill untouched and within a few seconds.
    LaunchedEffect(selected) {
        val (pulledTab, pulledAt) = coldPull ?: return@LaunchedEffect
        if (selected == pulledTab) return@LaunchedEffect
        coldPull = null
        if (!navHasFocus || focusedTab != pulledTab) return@LaunchedEffect
        if (android.os.SystemClock.uptimeMillis() - pulledAt > 5_000L) return@LaunchedEffect
        runCatching { pillRequesters[selected]?.requestFocus() }
        com.aeriotv.android.ui.tv.TvFocusTrace.guide("cold-start pull follows landing tab=$selected")
    }
    if (useQueRail) {
        QueTvRail(
            tabs = tabs,
            selected = selected,
            onSelect = onSelect,
            focusRequester = focusRequester,
            pillRequesters = pillRequesters,
            tabEntryFocus = tabEntryFocus,
            liveTvMode = liveTvMode,
            liveTvListFocusRequester = liveTvListFocusRequester,
            guideFocusRequester = guideFocusRequester,
            toolbarFocusRequester = toolbarFocusRequester,
            onLiveTvModeSelect = onLiveTvModeSelect,
            onLiveTvModeFocused = { mode ->
                if (armed || android.os.SystemClock.uptimeMillis() - lastUpKeyMs[0] < 400L) {
                    onLiveTvModeSelect(mode)
                }
            },
            onNavigationFocusChanged = { navHasFocus = it },
            onTabFocused = { tab ->
                com.aeriotv.android.ui.tv.TvFocusTrace.focus("tab:" + tab.name)
                focusedTab = tab
                if (tab != selected && isTabWarm(tab) &&
                    (armed || android.os.SystemClock.uptimeMillis() - lastUpKeyMs[0] < 400L)
                ) {
                    onSelect(tab)
                }
            },
        )
        return
    }
    // Custom layout so the PILL CAPSULE is centered on the SCREEN (Logan
    // 2026-08-06: adding the circles to a shared centered row shoved the
    // pills off-center) and the circles hang off its left edge without
    // affecting its position.
    //
    // The circles live OUTSIDE the capsule's focus group, on purpose. Bar
    // entry arrives as a direct requestFocus on the capsule row, which
    // IGNORES enter/onEnter redirects and lands on the group's first
    // focusable - with a circle inside the group, entry never reached the
    // selected pill and the armed gate (correctly) refused to treat entry
    // focus as a selection, so Search could never open (Streamer
    // 2026-08-06). Out here the capsule's focus contract is exactly the
    // pre-circle one, and each circle is a plain focusable CLICK target
    // that D-pad Left reaches geometrically.
    androidx.compose.ui.layout.Layout(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 16.dp, bottom = 12.dp)
            // AFTER the padding, so these bounds are the drawn content's.
            .onGloballyPositioned { onDrawnBottomChanged(it.boundsInRoot().bottom) },
        content = {
            Row(
                modifier = Modifier
                    .focusRequester(focusRequester)
                    // focusProperties describes the focus target BELOW it in
                    // the chain, so it must precede focusGroup() to apply to
                    // the group (after it, the enter/exit callbacks never ran).
                    .focusProperties {
                        onEnter = {
                            pillRequesters[selected]?.requestFocus()
                        }
                        // Down into the tab: land where the tab asked to
                        // (On Demand's current sub-tab pill), else default.
                        onExit = {
                            if (requestedFocusDirection == androidx.compose.ui.focus.FocusDirection.Down) {
                                val target = tabEntryFocus?.value
                                val took = target != null && runCatching { target.requestFocus() }.getOrDefault(false)
                                com.aeriotv.android.ui.tv.TvFocusTrace.guide("tab-exit down target=${target != null} took=$took")
                                if (took) {
                                    // The default geometric move would run
                                    // after this and land elsewhere.
                                    cancelFocusChange()
                                }
                            }
                        }
                    }
                    .focusGroup()
                    // Row-level hasFocus stays true while focus moves between pills
                    // and only flips false when focus leaves the bar entirely, so it
                    // is the reliable "is the user in the bar" signal for [armed].
                    .onFocusChanged { navHasFocus = it.hasFocus }
                    // tvOS system tab bar, halved: a 68 pt capsule holding
                    // 44 pt pills (Logan 2026-09-10, Streamer vs Apple TV).
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.55f))
                    .padding(horizontal = 6.dp, vertical = 6.dp),
                // 6dp still leaves headroom for the focused pill's 1.04x paint-only
                // grow (graphicsLayer does not relayout); at 3dp the widest pill
                // visually collided. Trimmed from 8dp to narrow the bar.
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                tabs.forEach { tab ->
                    TvTab(
                        tab = tab,
                        selected = tab == selected,
                        onFocused = {
                            com.aeriotv.android.ui.tv.TvFocusTrace.focus("tab:" + tab.name)
                            focusedTab = tab
                            // Warm tabs commit on the SAME frame as the pill
                            // highlight (tvOS TabView behavior). Going through
                            // the LaunchedEffect below cost another 22-38 ms
                            // of coroutine scheduling for nothing. The cold
                            // path still runs there, with its settle window.
                            if (tab != selected && isTabWarm(tab) &&
                                (armed || android.os.SystemClock.uptimeMillis() - lastUpKeyMs[0] < 400L)
                            ) {
                                onSelect(tab)
                            }
                        },
                        modifier = pillRequesters[tab]?.let { Modifier.focusRequester(it) } ?: Modifier,
                    )
                }
            }
            if (showActionCircles) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    // Refresh (TV's pull-to-refresh stand-in), then Search -
                    // the most-used action sits closest to the pills, one
                    // Left press away.
                    TvBarCircleButton(
                        icon = Icons.Filled.Refresh,
                        contentDescription = "Refresh channels and guide",
                        onClick = onRefresh,
                        spinning = refreshing,
                        spinAnimates = refreshAnimates,
                    )
                    if (retainedCount > 0) {
                        TvBarCircleButton(
                            icon = Icons.Filled.FiberSmartRecord,
                            contentDescription = "$retainedCount channels kept live",
                            onClick = onRetainedClick,
                        )
                    }
                    TvBarCircleButton(
                        icon = AppTab.Search.iconSelected,
                        contentDescription = AppTab.Search.label,
                        selected = selected == AppTab.Search,
                        onClick = { onSelect(AppTab.Search) },
                        modifier = pillRequesters[AppTab.Search]
                            ?.let { Modifier.focusRequester(it) } ?: Modifier,
                    )
                }
            }
        },
    ) { measurables, constraints ->
        val loose = constraints.copy(minWidth = 0, minHeight = 0)
        val capsule = measurables[0].measure(loose)
        val circles = measurables.getOrNull(1)?.measure(loose)
        val width = constraints.maxWidth
        val height = maxOf(capsule.height, circles?.height ?: 0)
        layout(width, height) {
            val capsuleX = (width - capsule.width) / 2
            capsule.placeRelative(capsuleX, (height - capsule.height) / 2)
            val circlesX = capsuleX - 10.dp.roundToPx() - (circles?.width ?: 0)
            circles?.placeRelative(circlesX, (height - circles.height) / 2)
            // Publish the real left edge for the hint chips. Writing snapshot
            // state here is safe: it feeds a SIBLING overlay, never this bar,
            // so it cannot drive a layout loop, and an equal write is a no-op.
            onLeftEdgeChanged(if (circles != null) circlesX else capsuleX)
        }
    }
}

/**
 * A floating action circle beside the pill capsule (Search, Refresh). Unlike
 * the pills these are plain BUTTONS: focus highlights (white ring, app
 * convention) and OK acts. They deliberately do NOT select on focus - they
 * sit outside the capsule's focus group and its armed machinery, so
 * focus-driven action here would fire on every accidental Left past the
 * bar's edge. [selected] paints solid primary while the button's content is
 * the one on screen (Search); [spinning] rotates the glyph while its action
 * is in flight (Refresh).
 */
@Composable
private fun TvBarCircleButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    contentDescription: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    selected: Boolean = false,
    spinning: Boolean = false,
    spinAnimates: Boolean = true,
) {
    // TV chrome canon (ui/tv/TvChrome.kt, tvOS TVNavCircleButtonStyle):
    // quiet translucent circle at rest, white platter with a dark glyph
    // while focused, accent fill while its screen (Search) is up. Sized to
    // the tab capsule beside it so the row centres cleanly.
    com.aeriotv.android.ui.tv.TvActionCircle(
        icon = icon,
        contentDescription = contentDescription,
        onClick = onClick,
        modifier = modifier,
        selected = selected,
        spinning = spinning,
        spinAnimates = spinAnimates,
        size = com.aeriotv.android.ui.tv.TvChrome.circleSize,
    )
}

@Composable
private fun TvTab(
    tab: AppTab,
    selected: Boolean,
    onFocused: () -> Unit,
    modifier: Modifier = Modifier,
) {
    var focused by remember { mutableStateOf(false) }
    // SELECTED owns the solid fill; FOCUS is the white ring (the app-wide
    // guide-pill convention). The old scheme gave focused-not-selected a
    // solid fill brighter than the selected tab, so re-entering the bar lit
    // two pills as "active" at once.
    // tvOS system tab bar look (TV chrome canon, ui/tv/TvChrome.kt): the
    // FOCUSED pill is a white platter with dark ink, the SELECTED pill keeps
    // the accent fill, everything else is bare text. No ring: the platter
    // is the focus visual, exactly as on the Apple TV.
    // Both tweens run the SAME 150 ms EaseInOut as tvFocusScale (the tvOS pill
    // grow). The default color spring took 145-210 ms to settle and landed the
    // highlight ~200-260 ms after the key press, which is AFTER the content
    // swap now arrives (51-199 ms warm): the tab read as loading ahead of the
    // bar (Logan 2026-09-11). tvOS changes the pill and the content together,
    // so the bar is sped up to meet the content rather than the content
    // delayed to meet the bar.
    val pillTween = androidx.compose.animation.core.tween<Color>(
        durationMillis = 150,
        easing = androidx.compose.animation.core.EaseInOut,
    )
    val background by animateColorAsState(
        targetValue = when {
            focused -> MaterialTheme.colorScheme.onSurface
            selected -> MaterialTheme.colorScheme.primary
            else -> Color.Transparent
        },
        animationSpec = pillTween,
        label = "tvTabBackground",
    )
    val foreground by animateColorAsState(
        targetValue = when {
            focused -> com.aeriotv.android.ui.theme.readableOn(MaterialTheme.colorScheme.onSurface)
            selected -> MaterialTheme.colorScheme.onPrimary
            else -> MaterialTheme.colorScheme.onSurfaceVariant
        },
        animationSpec = pillTween,
        label = "tvTabForeground",
    )
    Row(
        modifier = modifier
            .onFocusChanged {
                focused = it.isFocused
                if (it.isFocused) onFocused()
            }
            // 1.04x (not the 1.08x default): the pills sit 8dp apart and the
            // paint-only grow must stay inside that gap.
            .tvFocusScale(focused, focusedScale = 1.04f)
            .clip(CircleShape)
            .background(background)
            .focusable()
            // Trimmed (13->10 h / 20->18 icon) to narrow the whole centered nav
            // bar so its right edge clears the enlarged corner mini-player.
            // Vertical 8 = the old 6 plus the 2dp ring the platter replaced.
            // tvOS system tab bar pill: 44 pt tall, ~20 pt sides, 26 pt
            // glyph, 28 pt semibold label, halved.
            .padding(horizontal = 10.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(5.dp),
    ) {
        Icon(
            imageVector = if (selected) tab.iconSelected else tab.iconUnselected,
            contentDescription = null,
            tint = foreground,
            modifier = Modifier.size(14.dp),
        )
        Text(
            text = tab.label,
            color = foreground,
            fontSize = 14.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
        )
    }
}

/**
 * Collapses a TV chrome strip (the top tab bar here, the On Demand segment
 * pills on their tab) to [visibleFraction] of its measured height, fading the
 * pixels in step. The strip stays MOUNTED throughout: its children are
 * FocusRequester targets and requestFocus() on a detached node throws, so the
 * hide must be geometric, not compositional. Height is floored at 1px so the
 * strip also stays reachable by plain D-pad UP focus search when fully
 * collapsed; focus arriving is the signal the callers use to expand it again.
 *
 * Internal (not private) because the On Demand tab applies the same treatment
 * to its Movies/Series pills; the behavior must stay identical in both spots.
 * Also drives the phone bottom NavigationBar's scroll auto-hide (GH #20),
 * where the height collapse is what lets Scaffold hand the space to content.
 */
internal fun Modifier.collapsibleChrome(visibleFraction: Float): Modifier = this
    .graphicsLayer { alpha = visibleFraction }
    .clipToBounds()
    .layout { measurable, constraints ->
        val placeable = measurable.measure(constraints)
        val collapsedHeight =
            (placeable.height * visibleFraction).toInt().coerceAtLeast(1)
        layout(placeable.width, collapsedHeight) {
            placeable.placeRelative(0, 0)
        }
    }

/**
 * Routes that replace the WHOLE Settings host rather than rendering in a pane
 * (plan B2's TV takeover set). Shared so the focus contract and the rail host
 * cannot disagree about what counts as a takeover.
 */
private fun isSettingsTakeover(route: SettingsRoute): Boolean =
    route is SettingsRoute.LogViewer ||
        route is SettingsRoute.Licenses ||
        route is SettingsRoute.EditPlaylist ||
        route is SettingsRoute.AddPlaylist ||
        route is SettingsRoute.AddMoreCategories

@Composable
private fun SettingsTabContent(
    // The PLAYLIST_GRAPH-scoped instance, threaded from MainTabContent. A
    // bare hiltViewModel() here resolved against the MAIN entry's store and
    // minted a second PlaylistViewModel (full bootstrap re-run) the moment
    // Settings opened - same leak as LiveTVTabContent's old default.
    playlistViewModel: PlaylistViewModel,
) {
    // Phase B2: one saveable back stack replaces the six independent booleans
    // plus `section`. "Innermost" is now literal (stack order) instead of being
    // encoded implicitly in the ORDER of the BackHandler and content `when`
    // branches, which had to be kept in agreement by hand. rememberSaveable
    // also means rotation, fold posture changes, and process death restore the
    // position, which plain `remember` could not.
    val nav = rememberSettingsNavState()
    val route = nav.current
    // Phase B3: the tablet list-detail host. Expanded width alone is not the
    // gate -- a landscape phone is "expanded" but far too short -- and TV keeps
    // the stacked layout until B4 lands the rail with its focus contract.
    val isTvDevice = rememberIsTvDevice()
    val viewport = rememberViewport()
    // Settings phase 2: the gate is MEDIUM width and up, so an unfolded
    // foldable gets the sidebar. `settingsTwoPane` is Settings' own flag; the
    // window-wide `isTwoPaneEligible` (and the tab-bar placement built on it)
    // is deliberately unchanged.
    val paneEligible = viewport.settingsTwoPane
    // Same eligibility, two hosts: touch tablets get the tap sidebar (B3), TV
    // gets the 10-foot rail with its focus contract (B4).
    val tabletTwoPane = paneEligible && !isTvDevice
    val tvRail = paneEligible && isTvDevice
    val twoPane = tabletTwoPane || tvRail
    var selection by rememberSettingsPaneSelection(nav = nav, twoPane = twoPane, initial = if (tvRail) SettingsRoute.Root else DefaultSettingsPaneSelection)
    // True for the route the pane is BASELINED on; pushes above it render as
    // ordinary screens and keep their own back affordance.
    val inPane = twoPane && route == null
    val updaterEnabled = hiltViewModel<com.aeriotv.android.feature.update.UpdateViewModel>()
        .isEnabled
    // Sidebar / rail Sync row reads On or Off rather than a description.
    val syncEnabled by hiltViewModel<com.aeriotv.android.feature.settings.SettingsViewModel>()
        .syncMasterEnabled
        .collectAsStateWithLifecycle(initialValue = false)
    val addPlaylistStep: AddPlaylistStep = when (val r = route) {
        is SettingsRoute.AddPlaylist -> when (val st = r.step) {
            is AddPlaylistWizardStep.ChooseType -> AddPlaylistStep.ChooseType
            is AddPlaylistWizardStep.Configure -> AddPlaylistStep.Configure(st.sourceType)
        }
        else -> AddPlaylistStep.None
    }
    val playlistVm = playlistViewModel
    val playlistState by playlistVm.state.collectAsStateWithLifecycle()

    // Screenshot deep link (aeriotvblue://settings/<page>). MainScaffold has already
    // selected the Settings tab, which is what composed us; translate the page
    // into this host's own terms. In a two-pane host a pane-baseline page is the
    // SELECTION and everything else is a push above Playlists, matching what the
    // user would have produced by hand; the stacked phone layout just pushes.
    // The playlist pages wait for an active playlist, which is why the request
    // is a StateFlow and this effect is keyed on the playlist id as well.
    val pendingSettingsPage by playlistVm.settingsPageRequest.collectAsStateWithLifecycle()
    // Bumped when a deep link changes the rail's selection: the rail only pulls
    // focus into the pane on a PUSH, so a plain selection change would leave
    // focus wherever it was (the tab pill on a cold launch).
    var deepLinkPaneFocus by remember { mutableIntStateOf(0) }
    LaunchedEffect(pendingSettingsPage, twoPane, tvRail, playlistState.playlist?.id) {
        val page = pendingSettingsPage?.page ?: return@LaunchedEffect
        val activeId = playlistState.playlist?.id
        // No playlist yet: leave the request pending and retry when one lands.
        if (activeId == null && settingsDeepLinkPageNeedsPlaylist(page)) return@LaunchedEffect
        val target = settingsRouteForDeepLinkPage(page, activeId)
        nav.popToRoot()
        if (twoPane) {
            when {
                target == null ->
                    selection = if (tvRail) SettingsRoute.Root else DefaultSettingsPaneSelection
                target.isPaneBaseline -> selection = target
                else -> {
                    // Playlist detail / edit are pushes; baseline them on the
                    // Playlists pane so Back walks out the way it normally would.
                    selection = SettingsRoute.Playlists
                    nav.push(target)
                }
            }
            deepLinkPaneFocus++
        } else if (target != null) {
            nav.push(target)
        }
        playlistVm.consumeSettingsPage()
    }
    // Watch for a playlist id flip while we're inside the Add Playlist flow;
    // that means the user's onboarding Save succeeded and the new row was
    // promoted active. Close the embedded flow.
    val startId = remember(addPlaylistStep) {
        if (addPlaylistStep != AddPlaylistStep.None) playlistState.playlist?.id else null
    }
    LaunchedEffect(playlistState.playlist?.id) {
        if (addPlaylistStep != AddPlaylistStep.None &&
            startId != null &&
            playlistState.playlist?.id != startId
        ) {
            nav.pop()
        }
    }
    val traceBackTv = rememberLiveTvFormFactor().isTv
    androidx.activity.compose.BackHandler(enabled = nav.canPop) {
        val cur = nav.current
        if (traceBackTv) {
            com.aeriotv.android.ui.tv.TvFocusTrace.settingsBack("settings-nav pop ${cur?.let { com.aeriotv.android.feature.settings.encodeSettingsRoute(it) }}")
        }
        // The wizard's stages advance IN PLACE rather than nesting, so Back
        // from Configure returns to ChooseType instead of leaving the flow.
        if (cur is SettingsRoute.AddPlaylist && cur.step is AddPlaylistWizardStep.Configure) {
            nav.replaceTop(SettingsRoute.AddPlaylist(AddPlaylistWizardStep.ChooseType))
        } else {
            nav.pop()
        }
    }
    // TV focus retention. The top nav uses selection-follows-focus (focusing
    // the Live TV pill switches to the guide). When the user clicks a settings
    // row, the sub-screen replaces the list and the focused row is removed --
    // Compose then falls focus back to the first focusable in the tree, the
    // nav pill row, whose Live TV pill grabs focus and bounces the user to the
    // guide (the "clicking any setting goes back to the guide" bug). Fix: pull
    // focus INTO the settings content whenever a sub-screen appears so it never
    // lands on the nav. Keyed on the visible sub-screen; the root list (key
    // null) is left alone so the pill -> DOWN -> list traversal is unchanged.
    val settingsContentFocus = remember { FocusRequester() }
    // Plan B2: "fire it only for full-screen takeovers entering or exiting".
    // In a two-pane host a push renders INSIDE the pane with the rail still up,
    // so pulling focus to this outer group would land it on the rail's first
    // row and orphan the push (traced on the Streamer 2026-08-05). The rail
    // host moves focus into the pane itself for those; this stays responsible
    // for the stacked layouts and for takeovers.
    val subScreenKey: String? = when {
        !twoPane -> nav.focusKey
        route != null && isSettingsTakeover(route) -> nav.focusKey
        else -> null
    }
    var prevSubScreenKey by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(subScreenKey) {
        // Pull focus into the content both when a sub-screen OPENS and when it
        // CLOSES back to the root list, so focus never lingers on a nav pill
        // (where the involuntary fallback parks it). Skip the very first
        // composition (prev == cur == null) so switching INTO Settings still
        // lands on the Settings pill, preserving the pill -> DOWN -> list flow.
        val entering = subScreenKey != null
        val exitingToRoot = subScreenKey == null && prevSubScreenKey != null
        if (entering || exitingToRoot) runCatching { settingsContentFocus.requestFocus() }
        prevSubScreenKey = subScreenKey
    }
    // Settings tab re-tap (TabReselect): pop whatever is pushed back to the
    // Settings root first -- including a picker / sub-toggle page, which lives
    // inside the sub-screen being popped -- and once already at the root,
    // scroll that root list to the top. The two-pane host keeps its selection:
    // only the pushes ABOVE the pane baseline are popped, which is what Back
    // would have done one press at a time.
    val settingsRootListState = androidx.compose.foundation.lazy.rememberLazyListState()
    OnTabReselect(AppTab.Settings) {
        if (nav.canPop) nav.popToRoot() else settingsRootListState.animateScrollToItem(0)
    }
    // Phase B3: one renderer for a route, used by BOTH the stacked phone layout
    // and the tablet host's detail pane, so the two can never diverge.
    val renderRoute: @Composable (SettingsRoute?) -> Unit = { r ->
    when (r) {
        null -> SettingsScreen(
            listState = settingsRootListState,
            onSectionClick = { nav.push(SettingsRoute.Section(it)) },
            onOpenPlaylistDetail = { id -> nav.push(SettingsRoute.PlaylistDetail(id)) },
            onOpenPlaylists = { nav.push(SettingsRoute.Playlists) },
            onEditPlaylist = { id -> nav.push(SettingsRoute.EditPlaylist(id)) },
            onAddPlaylist = {
                nav.push(SettingsRoute.AddPlaylist(AddPlaylistWizardStep.ChooseType))
            },
            onOpenLicenses = { nav.push(SettingsRoute.Licenses) },
            viewModel = playlistVm,
        )
        is SettingsRoute.About -> SettingsScreen(
            onSectionClick = { nav.push(SettingsRoute.Section(it)) },
            onBack = { nav.pop() },
            onOpenLicenses = { nav.push(SettingsRoute.Licenses) },
            viewModel = playlistVm,
            content = SettingsRootContent.AboutOnly,
        )
        is SettingsRoute.Root -> SettingsScreen(
            listState = settingsRootListState,
            onSectionClick = { nav.push(SettingsRoute.Section(it)) },
            onOpenPlaylistDetail = { id -> nav.push(SettingsRoute.PlaylistDetail(id)) },
            onOpenPlaylists = { nav.push(SettingsRoute.Playlists) },
            onEditPlaylist = { id -> nav.push(SettingsRoute.EditPlaylist(id)) },
            onAddPlaylist = {
                nav.push(SettingsRoute.AddPlaylist(AddPlaylistWizardStep.ChooseType))
            },
            onOpenLicenses = { nav.push(SettingsRoute.Licenses) },
            viewModel = playlistVm,
        )
        is SettingsRoute.AddPlaylist -> when (val st = r.step) {
            is AddPlaylistWizardStep.Configure -> ConfigureSourceScreen(
                sourceType = st.sourceType,
                onBack = {
                    nav.replaceTop(SettingsRoute.AddPlaylist(AddPlaylistWizardStep.ChooseType))
                },
                viewModel = playlistVm,
            )
            is AddPlaylistWizardStep.ChooseType -> ChooseSourceTypeScreen(
                onBack = { nav.pop() },
                onChoose = { type ->
                    // Start a FRESH draft so the add creates a NEW row and can't
                    // carry over the active server's bootstrap-prefilled API key
                    // (which would win over typed user/pass and re-add the active
                    // server's account). Mirrors the onboarding CHOOSE_TYPE path.
                    playlistVm.startNewSource(type)
                    nav.replaceTop(
                        SettingsRoute.AddPlaylist(AddPlaylistWizardStep.Configure(type)),
                    )
                },
            )
        }
        is SettingsRoute.Playlists ->
            if (inPane) {
                // As a PANE this is the sidebar's Playlists item, so it shows
                // the root's playlist block (switch / open / Add / Manage);
                // Manage Playlists then pushes the reorder page above it.
                SettingsScreen(
                    onSectionClick = { nav.push(SettingsRoute.Section(it)) },
                    onOpenPlaylistDetail = { id ->
                        nav.push(SettingsRoute.PlaylistDetail(id))
                    },
                    onOpenPlaylists = { nav.push(SettingsRoute.Playlists) },
                    onEditPlaylist = { id -> nav.push(SettingsRoute.EditPlaylist(id)) },
                    onAddPlaylist = {
                        nav.push(SettingsRoute.AddPlaylist(AddPlaylistWizardStep.ChooseType))
                    },
                    viewModel = playlistVm,
                    content = SettingsRootContent.PlaylistsOnly,
                )
            } else {
                com.aeriotv.android.feature.settings.PlaylistsScreen(
                    onBack = { nav.pop() },
                    onAddPlaylist = {
                        nav.push(SettingsRoute.AddPlaylist(AddPlaylistWizardStep.ChooseType))
                    },
                    onOpenPlaylistDetail = { id ->
                        nav.push(SettingsRoute.PlaylistDetail(id))
                    },
                    viewModel = playlistVm,
                )
            }
        is SettingsRoute.EditPlaylist -> com.aeriotv.android.feature.settings.EditPlaylistScreen(
            onBack = { nav.pop() },
            playlistId = r.playlistId,
            viewModel = playlistVm,
        )
        is SettingsRoute.PlaylistDetail ->
            com.aeriotv.android.feature.settings.PlaylistDetailScreen(
                onBack = { nav.pop() },
                onEdit = { nav.push(SettingsRoute.EditPlaylist(r.playlistId)) },
                playlistId = r.playlistId,
                viewModel = playlistVm,
            )
        is SettingsRoute.AddMoreCategories -> AddMoreCategoriesScreen(onBack = { nav.pop() })
        is SettingsRoute.SyncCategories ->
            com.aeriotv.android.feature.settings.SyncCategoriesScreen(onBack = { nav.pop() })
        is SettingsRoute.LogViewer -> com.aeriotv.android.feature.settings.LogViewerScreen(
            onBack = { nav.pop() },
        )
        is SettingsRoute.Licenses -> com.aeriotv.android.feature.settings.LicensesScreen(
            onBack = { nav.pop() },
        )
        is SettingsRoute.Section -> when (r.section) {
            SettingsSection.LiveTV -> LiveTvSettingsScreen(
                onBack = { nav.pop() },
                onOpenAddMoreCategories = { nav.push(SettingsRoute.AddMoreCategories) },
            )
            SettingsSection.Player -> PlayerSettingsScreen(onBack = { nav.pop() })
            SettingsSection.MoviesAndTvShows ->
                MoviesAndTvShowsSettingsScreen(onBack = { nav.pop() })
            SettingsSection.Appearance -> AppearanceSettingsScreen(onBack = { nav.pop() })
            SettingsSection.General -> GeneralSettingsScreen(onBack = { nav.pop() })
            SettingsSection.RemoteControl ->
                com.aeriotv.android.feature.settings.RemoteControlSettingsScreen(
                    onBack = { nav.pop() },
                )
            SettingsSection.AppUpdates ->
                com.aeriotv.android.feature.settings.AppUpdatesScreen(onBack = { nav.pop() })
            SettingsSection.Sync -> com.aeriotv.android.feature.settings.SyncSettingsScreen(
                onBack = { nav.pop() },
                onOpenSyncCategories = { nav.push(SettingsRoute.SyncCategories) },
            )
            SettingsSection.DvrSettings -> DvrSettingsScreen(onBack = { nav.pop() })
            SettingsSection.Developer -> DeveloperSettingsScreen(
                onBack = { nav.pop() },
                onOpenLogViewer = { nav.push(SettingsRoute.LogViewer) },
            )
            // The About page is the root's About block rendered on its own,
            // so the copy cannot drift from what the pane hosts already show.
            SettingsSection.About -> SettingsScreen(
                onSectionClick = { nav.push(SettingsRoute.Section(it)) },
                onBack = { nav.pop() },
                onOpenLicenses = { nav.push(SettingsRoute.Licenses) },
                viewModel = playlistVm,
                content = SettingsRootContent.AboutOnly,
            )
        }
    }
    }

    // Fold awareness. Every geometry comes from the OS-reported FoldingFeature,
    // and the boundary always lands ON the crease so no pane is bent:
    //
    //  - VERTICAL crease: the window splits left/right, so the existing
    //    side-by-side layout just moves its boundary to the hinge.
    //  - HORIZONTAL crease, ANY state: Settings keeps the full display side by
    //    side (Logan's call), so the split is the ordinary fixed one; only an
    //    OCCLUDING hinge changes anything, by taking the hairline away.
    //
    // The host's Row/Column starts at the window's leading/top edge, which is
    // the same origin the feature bounds use. Recomposing on a new FoldInfo
    // re-lays-out only; `selection` and the nav stack live above this and are
    // untouched, and `twoPane` does not flip, so no posture mapping runs.
    val fold = com.aeriotv.android.ui.adaptive.rememberFoldInfo()
    val settingsSplit = when {
        fold != null &&
            fold.axis == com.aeriotv.android.ui.adaptive.FoldAxis.VERTICAL &&
            fold.start > 0.dp ->
            SettingsPaneSplit(
                sidebarExtent = fold.start,
                gap = fold.gap,
                drawDivider = !fold.needsBlankGap,
            )
        else ->
            SettingsPaneSplit(
                sidebarExtent = viewport.settingsSidebarWidth,
                drawDivider = fold?.isOccluding != true,
            )
    }

    Box(modifier = Modifier.focusRequester(settingsContentFocus).focusGroup()) {
        if (tvRail) {
            SettingsTvRailHost(
                focusPaneSignal = deepLinkPaneFocus,
                selection = selection,
                onSelect = { picked ->
                    nav.popToRoot()
                    selection = picked
                },
                pushed = route,
                sections = visibleSettingsSections(
                    isTv = true,
                    updaterEnabled = updaterEnabled,
                ),
                activePlaylistName = playlistState.playlist?.name,
                syncEnabled = syncEnabled,
                // Plan B2: the TV takeover set. These keep the whole screen so
                // their keyboard / IME plumbing is untouched.
                takeover = ::isSettingsTakeover,
                detail = { renderRoute(it) },
            )
        } else if (tabletTwoPane) {
            // Rev 2: sidebar browsing mutates `selection` and never pushes, so
            // Back can only unwind real pushes.
            SettingsTwoPaneHost(
                selection = selection,
                onSelect = { picked ->
                    // Leaving a pane abandons anything pushed above it; the new
                    // pane starts at its own baseline (Apple rail behavior).
                    nav.popToRoot()
                    selection = picked
                },
                pushed = route,
                sections = visibleSettingsSections(
                    isTv = isTvDevice,
                    updaterEnabled = updaterEnabled,
                ),
                activePlaylistName = playlistState.playlist?.name,
                syncEnabled = syncEnabled,
                // Log lines and license texts want the whole width, and the
                // Add Playlist wizard is a modal flow of its own; everything
                // else (playlist detail, Edit Playlist, Add More Categories,
                // section sub-pages) renders in the pane with the sidebar up.
                takeover = {
                    it is SettingsRoute.LogViewer ||
                        it is SettingsRoute.Licenses ||
                        it is SettingsRoute.AddPlaylist
                },
                split = settingsSplit,
                detail = { renderRoute(it) },
            )
        } else {
            // Dispatch on the stack's top route. Ordering that used to be
            // implicit in branch position (the log viewer had to sit ABOVE
            // Developer to win) is now just push order.
            renderRoute(route)
        }
    }
}

/**
 * Mirror of iOS MainTabView's dynamic tab-visibility rule (HomeView.swift
 * hasFavorites / hasRecordings / hasVOD). Always-on tabs: Live TV, Settings.
 * Conditional tabs appear ONLY when there is real content to show, NOT merely
 * because the source type could in theory serve it:
 *  - Favorites: the user has favorited at least one channel in the active playlist.
 *  - DVR: at least one recording exists (scheduled / recording / completed,
 *    server or local) for the active source.
 *  - On Demand: the active source has advertised any VOD (movies or series), or
 *    is still loading its VOD library (loading bridge prevents cold-start flicker).
 *
 * A bare live-TV M3U, or a Dispatcharr/Xtream source with no VOD and no
 * recordings, surfaces only Live TV + Settings - empty tabs never appear.
 */
internal fun visibleTabs(
    hasFavorites: Boolean = false,
    hasVod: Boolean = false,
    hasRecordings: Boolean = false,
    /** Phone/tablet media center: Movies + TV Shows instead of On Demand. */
    splitVod: Boolean = false,
    hasMovies: Boolean = hasVod,
    hasSeries: Boolean = hasVod,
): List<AppTab> = buildList {
    add(AppTab.LiveTV)
    if (hasFavorites) add(AppTab.Favorites)
    if (hasRecordings) add(AppTab.DVR)
    if (splitVod) {
        if (hasMovies) add(AppTab.Movies)
        if (hasSeries) add(AppTab.TVShows)
    } else if (hasVod) add(AppTab.OnDemand)
    add(AppTab.Settings)
    // AppTab.Search is deliberately NOT a pill: on TV it renders as the
    // floating circle LEFT of Live TV inside TvTopTabBar (Logan 2026-08-06:
    // frequent searchers shouldn't traverse the whole bar), and phones keep
    // their app-bar search entry points instead of a bottom-bar tab.
}

/** EntryPoint accessor so MainScaffold can drive pause/destroy on the held
 * MPV instance without routing through a ViewModel. */
@dagger.hilt.EntryPoint
@dagger.hilt.InstallIn(dagger.hilt.components.SingletonComponent::class)
interface MainScaffoldEntryPoint {
    fun exoPlayerHolder(): AerioExoPlayerHolder
    fun exoWindowState(): com.aeriotv.android.feature.player.ExoWindowState
    fun castSender(): com.aeriotv.android.core.cast.AerioCastSender
    fun companionRemote(): com.aeriotv.android.core.cast.companion.CompanionRemoteController
    fun companionDiscovery(): com.aeriotv.android.core.cast.companion.CompanionDiscovery
    fun multiviewCastController(): com.aeriotv.android.core.cast.multiview.MultiviewCastController
    fun watchProgressDao(): com.aeriotv.android.core.data.db.dao.WatchProgressDao
    fun timeshiftController(): com.aeriotv.android.core.timeshift.TimeshiftController
}

/** Two-step Add Playlist flow embedded in the Settings tab. None = closed. */
private sealed interface AddPlaylistStep {
    data object None : AddPlaylistStep
    data object ChooseType : AddPlaylistStep
    data class Configure(val sourceType: com.aeriotv.android.core.data.SourceType) : AddPlaylistStep
}

/** Scaffold-level view of On Demand state: presence flags only, so page
 *  emissions from the catalog walk do not recompose the scaffold. */
private data class VodPresence(
    val unsupportedSource: Boolean,
    val hasMovies: Boolean,
    val hasSeries: Boolean,
    val isLoading: Boolean,
    val isLoadingSeries: Boolean,
    val hasDeferredXtreamContent: Boolean,
) {
    companion object {
        fun from(s: com.aeriotv.android.feature.ondemand.OnDemandViewModel.UiState) = VodPresence(
            unsupportedSource = s.unsupportedSource,
            // Stored catalog counts (GH #109: the lists are no longer in memory).
            hasMovies = s.totalCount > 0,
            hasSeries = s.seriesTotalCount > 0,
            isLoading = s.isLoading,
            isLoadingSeries = s.isLoadingSeries,
            hasDeferredXtreamContent = s.hasDeferredXtreamContent,
        )
    }
}

/** True inside the tab the user is on; false inside a tab kept alive but
 *  hidden. Tab content gates focus pulls and BackHandlers on it. */
val LocalTabIsActive = androidx.compose.runtime.compositionLocalOf { true }

/** Measured at the REAL slot size and never placed: no draw, no focus
 *  geometry, no semantics, but the composition (and its state, scroll
 *  positions, loaded data) survives.
 *
 *  It used to measure at ZERO. That made showing a tab a full relayout, and a
 *  pre-warmed tab was laid out at 0 width, so its first placed frame was the
 *  0-width one: the hero carousel (which measures its own width) rendered its
 *  pages as slivers for a beat (Logan 2026-09-11). Measuring at the real size
 *  means the hidden tab is laid out exactly as it will be shown and its first
 *  placed frame is final; the parent still reports 0 x 0 and never places it,
 *  so it draws nothing, and canFocus/invisibleToUser below still keep it out
 *  of focus search and accessibility. */
private fun Modifier.keepAliveHidden(): Modifier = this
    .then(KeepAliveHiddenElement)
    .focusProperties { canFocus = false }
    .semantics { invisibleToUser() }

/* HOLD THE SLOT (perf 2026-10-03). Measuring the hidden tab at full size on
 * EVERY pass meant any change inside it (the TMDB art pass bumps every ~2 s)
 * re-measured its whole poster grid while nobody could see it, 115 to 160 ms
 * a time. The node now measures at the full constraints once (and again only
 * if those constraints change, e.g. rotation), which is all the 2026-09-11
 * fix needs: the content's last layout is the real size, so showing it never
 * starts from a 0-width frame. Later invalidations stay pending and are
 * measured in the frame the tab is shown, before it is placed. */
private object KeepAliveHiddenElement : androidx.compose.ui.node.ModifierNodeElement<KeepAliveHiddenNode>() {
    override fun create() = KeepAliveHiddenNode()
    override fun update(node: KeepAliveHiddenNode) = Unit
    override fun hashCode(): Int = 0x6b41
    override fun equals(other: Any?): Boolean = other === this
}

private class KeepAliveHiddenNode : Modifier.Node(), androidx.compose.ui.node.LayoutModifierNode {
    private var measuredFor: androidx.compose.ui.unit.Constraints? = null

    override fun androidx.compose.ui.layout.MeasureScope.measure(
        measurable: androidx.compose.ui.layout.Measurable,
        constraints: androidx.compose.ui.unit.Constraints,
    ): androidx.compose.ui.layout.MeasureResult {
        // Same constraints the ACTIVE slot's fillMaxSize() resolves to.
        val full = constraints.copy(
            minWidth = constraints.maxWidth.takeIf { it != androidx.compose.ui.unit.Constraints.Infinity } ?: constraints.minWidth,
            minHeight = constraints.maxHeight.takeIf { it != androidx.compose.ui.unit.Constraints.Infinity } ?: constraints.minHeight,
        )
        if (measuredFor != full) {
            measurable.measure(full)
            measuredFor = full
        }
        return layout(0, 0) { /* deliberately not placed */ }
    }
}
